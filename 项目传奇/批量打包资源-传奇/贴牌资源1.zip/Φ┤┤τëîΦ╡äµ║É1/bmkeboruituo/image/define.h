//
//  define.h
//  jfpal
//
//  Created by Chunhui Luo on 3/25/13.
//
//

#ifndef jfpal_define_h
#define jfpal_define_h



#define IOS_VERSION ([[[UIDevice currentDevice] systemVersion] floatValue])
#define IS_WIDESCREEN (fabs((double)[[UIScreen mainScreen]bounds].size.height - (double)568) < DBL_EPSILON)

#define IS_IPHONE ([[[UIDevice currentDevice]model] rangeOfString:@"iPhone" options:NSCaseInsensitiveSearch].location != NSNotFound)
#define IS_IPOD   ([[[UIDevice currentDevice]model] isEqualToString:@"iPod touch"])
    
#define IS_IPHONE_5 (IS_IPHONE && IS_WIDESCREEN)

#define APP_ID  @"12312323" //@"576285913"

#define CDV_ENABLE_EXEC_LOGGING 1

#define OBJ_LOADING @"obj_loading"
//
#define kNotifyNotification @"kNotifyNotification"





#define PASSWORD_AES_KEY @"qiZB1s52O164BH"

#define CARD_READER_PRICE 39800

#define relase 0
#ifdef relase

#define DEBUG_LOG(fmt, args...)
#define CLIENTVERSION @“1.4.3”
#define API_URL @"https://app2.imobpay.com/unifiedAction.do"
//#define API_URL @"http://58.247.51.74:8002/unifiedAction.do"
#define API_SIGN_KEY @"1sml1e47mdq3m6l8bci5rm0f1m3tkuuo"
#define XML_ROOT @"QtPay"
#define APPUSER @"bmkeboruituo"



#else

#endif

#define GLOBAL_HELPINFO_LIST @"HelpInfoList"
#define GLOBAL_HELPINFO_LIST_VERSION @"HelpInfoListVersion"
#define GLOBAL_HELPINFO_LIST_PHONE @"HelpInfoListPhone"

#define GLOBAL_BANK_LIST @"BankList"
#define GLOBAL_BANK_LIST_VERSION @"BankListVersion"

#define GLOBAL_CITY_LIST @"CityList"
#define GLOBAL_CITY_LIST_VERSION @"CityListVersion"


#define BANK_LIST @"0102,工商银行,工行;0103,农业银行,农行;0104,中国银行,中行;0105,建设银行,建行;0100,邮政储汇局,邮储;0301,交通银行,交行;0302,中信银行,中信;0303,光大银行,光大;0304,华夏银行,华夏;0305,广发银行,广发;0306,平安银行,平安;0308,招商银行,招行;0309,兴业银行,兴业;0310,浦发银行,浦发"

#endif
