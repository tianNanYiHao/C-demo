//
//  BleFori21ViewController.m
//  StaticLibSDKDemo
//
//  Created by My MacPro on 15/1/20.
//
//

#import "BleFori21ViewController.h"

@interface BleFori21ViewController ()<UITableViewDataSource,UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextViewDelegate>
{
    UITableView * myTable;
    NSMutableArray *deviceArr;
    NSArray * cmdArr;
    char *myRandom;
    int  myRandomLen;
    
}
@end


char bout0[5096];
int  boutlen0;
char* HexToBin0(char* hin)
{
    int i;
    char highbyte,lowbyte;
    int len= (int)strlen(hin);
    for (i=0;i<len/2;i++)
    {
        if (hin[i*2]>='0'&&hin[i*2]<='9')
            highbyte=hin[i*2]-'0';
        if (hin[i*2]>='A'&&hin[i*2]<='F')
            highbyte=hin[i*2]-'A'+10;
        if (hin[i*2]>='a'&&hin[i*2]<='f')
            highbyte=hin[i*2]-'a'+10;
        
        if (hin[i*2+1]>='0'&&hin[i*2+1]<='9')
            lowbyte=hin[i*2+1]-'0';
        if (hin[i*2+1]>='A'&&hin[i*2+1]<='F')
            lowbyte=hin[i*2+1]-'A'+10;
        if (hin[i*2+1]>='a'&&hin[i*2+1]<='f')
            lowbyte=hin[i*2+1]-'a'+10;
        
        bout0[i]=(highbyte<<4)|(lowbyte);
    }
    boutlen0=len/2;
    return bout0;
}
char hout0[5096];
char* BinToHex0(char* bin,int off,int len)
{
    int i;
    //	hout=(char*)hout;
    for (i=0;i<len;i++)
    {
        sprintf((char*)hout0+i*2,"%02x",*(unsigned char*)((char*)bin+i+off));
    }
    hout0[len*2]=0;
    return hout0;
}

@implementation BleFori21ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"i21蓝牙测试";
        self.view.backgroundColor = [UIColor lightGrayColor];
        deviceArr = [[NSMutableArray alloc] initWithCapacity:0];
        myRandom = "12345678";
        myRandomLen = 0;
    }
    return self;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [cmManager closeDevice];
    
    
    
}
- (NSString*)HexValue:(char*)bin Len:(int)binlen{
    char *hs;
    hs = BinToHex0(bin,0,binlen);//, <#int off#>, <#int len#>)
    hs[binlen*2]=0;
    NSString* str =[[NSString alloc] initWithFormat:@"%s",hs];
    //NSLog(@"str=%@,len=%d,buf=%c",str,buflen,buf[0]);
    return str;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _devecieTable.dataSource = self;
    _devecieTable.delegate = self;
    _cmdSelectView.dataSource = self;
    _cmdSelectView.delegate = self;
    
    cmdArr = [[NSArray alloc] initWithObjects:@"获取ksn", @"ic卡刷卡", @"获取设备类型", @"参数下载", @"ic卡回写",@"更新工作秘钥",@"计算mac",@"更新主秘钥", @"更新主秘钥3",nil];
    cmManager = [ItronCommunicationManagerBase getInstance];
    [cmManager setDeviceKind:6];
    [cmManager setDebug:1];
    NSLog(@"Ver_SDK= %@", [cmManager GetSDKVerson]);
    cmManager.communication = self;
    _displayTextView.font = [UIFont systemFontOfSize:14];
    
}
//这个方法返回蓝牙对象
- (void)discoverOneDevice:(CBPeripheral *)peripheral
{
    NSLog(@"name is %@",peripheral.name);
}
//这个方法返回uuid和名字
- (void)discoverBLeDevice:(NSDictionary *)uuidAndName
{
    NSLog(@"device is %@", uuidAndName);
    [deviceArr addObject:uuidAndName];
    [_devecieTable reloadData];
}
- (void)discoverComplete
{
    NSLog(@"-----------------搜索结束-----------------");
    
}
- (void)dealloc {
    [_displayLab release];
    [_displayTextView release];
    [_devecieTable release];
    [_cmdSelectView release];
    [_BleStateLab release];
    [super dealloc];
}
int pageNum1 = 0;

- (IBAction)sendCMDBtn:(UIButton *)sender {
    
    NSInteger icount = [_cmdSelectView selectedRowInComponent:0];
    //     cmdArr = [[NSArray alloc] initWithObjects:@"获取ksn", @"ic卡刷卡", @"获取设备类型", @"参数下载", @"ic卡回写",@"" nil];
    switch (icount) {
        case 0://获取ksn
            [cmManager Request_GetKsn];
            break;
        case 1://ic卡刷卡
        {
            _displayTextView.text = @"ic卡刷";
            //ic卡刷卡命令
            NSString *str = @"123456";
            char *temp = HexToBin0((char *)[str UTF8String]);
            char rom[100];
            memcpy(rom, temp, [str length]/2);//一定要拷贝否则会占用通一块内存
            // 交易金额
            NSString *cash = @"100";
            int cashLen = (int)[cash length];
            char cData[100];
            cData[0] = 0;
            strcpy(cData,((char*)[cash UTF8String]));
            
            Transactioninfo *tranInfo = [[Transactioninfo alloc] init];
            NSString *ctrm = @"83010000";
            char *temp2 = HexToBin0((char*)[ctrm UTF8String]);
            char ctr[4];
            memcpy(ctr, temp2, [ctrm length]/2);
            //            [cmManager setCustomer:36];//麦枫标志。
            [cmManager stat_EmvSwiper:0 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:ctr ParameterRandom:"123" ParameterRandomLen:3 cash:cData cashLen:cashLen appendData:"" appendDataLen:0 time:30 Transactioninfo:tranInfo];
            
        }
            break;
        case 2://获取设备类型
            _displayTextView.text = @"获取设备类型";
            [cmManager getTerminalType];
            break;
        case 3://参数下载
        {
            _displayTextView.text = @"参数下载";
            //    公钥下载
            NSString *str = @"319F0605A0000000049F220106DF05083230323331323331DF060101DF070101DF0281F8CB26FC830B43785B2BCE37C81ED334622F9622F4C89AAE641046B2353433883F307FB7C974162DA72F7A4EC75D9D657336865B8D3023D3D645667625C9A07A6B7A137CF0C64198AE38FC238006FB2603F41F4F3BB9DA1347270F2F5D8C606E420958C5F7D50A71DE30142F70DE468889B5E3A08695B938A50FC980393A9CBCE44AD2D64F630BB33AD3F5F5FD495D31F37818C1D94071342E07F1BEC2194F6035BA5DED3936500EB82DFDA6E8AFB655B1EF3D0D7EBF86B66DD9F29F6B1D324FE8B26CE38AB2013DD13F611E7A594D675C4432350EA244CC34F3873";
            
            NSString *str1 = @"319F0608A000000333010102DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
            char * temp=HexToBin0((char *)[str UTF8String]);
            int datalen = (int)[str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            [cmManager UpdateTerminalParameters:0 pageNum:pageNum1++ data:data dataLen:datalen time:6];
        }
            break;
        case 4://ic卡回写
        {
            _displayTextView.text = @"IC卡脚本回写";
            NSString *str =@"319F2608BEC5FDD8569CED7C9F2701809F101307020103A02002010A010000000000424E87069F37044C24C2199F360200149505000004E8009A031409189C01009F02060000000060005F2A02015682027C009F1A0201569F03060000000000009F3303E0E1C89F34034203009F3501229F1E0830303030303030318408A0000003330101029F090200209F4104000000029F631030313035303030300000000000000000";
            
            char * temp=HexToBin0((char *)[str UTF8String]);
            int datalen = [[str length]/2 intValue];
            char data[datalen];
            memcpy(data, temp, datalen);
            
            NSString *resCode = @"00";
            char * temp1=(char *)[resCode UTF8String];
            int datalen1 = [[resCode length] intValue];
            char resData[datalen1];
            memcpy(resData, temp1, datalen1);
            [cmManager secondIssuance:resData data:data dataLength:datalen+datalen1 time:60];
            
        }
            break;
        case 5://更新工作秘钥
        {
            //            1d8e5f2c9d6e88a61d8e5f2c9d6e88a6
            //
            NSString *workKey = @"7bab8b2a6acc67de7bab8b2a6acc67de82e13665";
            
            NSString *pinKey = workKey;
            NSString *macKey = workKey;
            NSString *desKey = workKey;
            char pin[100],mac[100],des[100];
            pin[0]=0;
            mac[0]=0;
            des[0]=0;
            char *tempPin = HexToBin0((char*)[pinKey UTF8String]);
            memcpy(pin, tempPin, [pinKey length]/2);//一定要拷贝否则会占用通一块内存
            int len =(int)[pinKey length]/2;
            char *tempMac = HexToBin0((char*)[macKey UTF8String]);
            memcpy(mac, tempMac, [macKey length]/2);//一定要拷贝否则会占用通一块内存
            char *tempDes = HexToBin0((char*)[macKey UTF8String]);
            memcpy(des, tempDes, [desKey length]/2);//一定要拷贝否则会占用通一块内存
            [cmManager Request_ReNewKey:0 PinKey:pin PinKeyLen:len
                                 MacKey:mac MacKeyLen:len
                                 DesKey:des DesKeyLen:len];
        }
            break;
        case 6://Mac计算
        {
            NSString *str = @"1990050000000000100000011719241217313233343531323334353834";
            char * temp=HexToBin0((char *)[str UTF8String]);
            int datalen = (int)[str length]/2;
            NSLog(@"数据长度%i",datalen);
            char data[datalen];
            memcpy(data, temp, datalen);
            [cmManager Request_GetMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen];
        }
            ;
            break;
        case 7://更新TMK
        {
            //
            NSString *str = @"c39f9ad96498f3edc39f9ad96498f3ed82e13665b4624df5";
            char *tempStr = HexToBin0((char *)[str UTF8String]);
            int mLen = (int)[str length]/2;
            char data[mLen];
            memcpy(data, tempStr, mLen);
            [cmManager Request_ReNewTMK:data MainKeyLen:mLen time:10];
            
            
        }
            break;
        case 8://-(void) Request_ReNewTMK3:(char *)data dataLen:(int )datalen time:(int)_timeOut
            
        {
            //
            NSString *str = @"11111111111111111111111111111111";
            char *tempStr = HexToBin0((char *)[str UTF8String]);
            int mLen = (int)[str length]/2;
            char data[mLen];
            memcpy(data, tempStr, mLen);
            [cmManager Request_ReNewTMK3:data dataLen:mLen time:10];
            
            //主密钥明文：5c302c69169a74835c302c69169a7483，工作秘钥密文：7bab8b2a6acc67de7bab8b2a6acc67de,校验位：82e13665
            
            
        }
            break;
        default:
            break;
    }
    
    
}

- (IBAction)searchDevice:(UIButton *)sender {
    [deviceArr removeAllObjects];
    [cmManager searchDevices:self timeout:5*1000];
    
}
//deleget
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([deviceArr count]== 0) {
        return 1;
    }else
        return [deviceArr count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *oneCell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (oneCell == nil) {
        oneCell  = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"] autorelease];
        
    }
    
    if ([deviceArr count] != 0) {
        NSDictionary * dic = [deviceArr objectAtIndex:indexPath.row];
        NSString *name = [dic objectForKey:[dic objectForKey:@"mainKey"]];
        NSLog(@"deviecName is %@", name);
        oneCell.textLabel.font = [UIFont systemFontOfSize:12];
        oneCell.textLabel.text = name; ;
    }
    
    return oneCell;
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *uuidString = [[deviceArr objectAtIndex:indexPath.row] objectForKey:@"mainKey"];
    //    int res = [cmManager openDevice:uuidString cbDelegate:self timeout:15*1000];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //        [self setNewStatus:SwipeCardStatusConnectDevice];
        int res = [cmManager openDevice:uuidString cbDelegate:self timeout:15*1000];
        if (res == 0) {
            NSLog(@" %d" , [cmManager isConnected]);
            _BleStateLab.text = @"蓝牙连接成功";
            UIButton *btnn = [[UIButton alloc] initWithFrame:CGRectMake(_BleStateLab.frame.origin.x, _BleStateLab.frame.origin.y + _BleStateLab.frame.size.height +4, _BleStateLab.frame.size.width, _BleStateLab.frame.size.height)];
            [btnn setTitle:@"断开连接" forState:UIControlStateNormal];
            [btnn addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];
            [btnn addTarget:cmManager action:@selector(closeDevice) forControlEvents:UIControlEventTouchUpInside];
            [btnn setBackgroundColor:[UIColor colorWithRed:135/250.0f green:156/255.0f blue:208/255.0f alpha:1.0f]];
            
            btnn.layer.cornerRadius = 4;
            btnn.layer.borderWidth = 0.5;
            btnn.tag = 120;
            [btnn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
            [self.view addSubview:btnn];
            [btnn release];
            
            
        }
        else{
            _BleStateLab.text = @"蓝牙连接失败";
        }
    });
    
}
- (void)touchDown:(UIButton *)btn
{
    btn.alpha = 0.6;
}

#pragma mark pickerView delegate method
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [cmdArr count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [cmdArr objectAtIndex:row];
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    _displayLab.text = [cmdArr objectAtIndex:row];
}
- (void)closeOk
{
    NSLog(@" closeOK ");
}

- (void)onWaitingForCardSwipe
{
    NSLog(@"请刷卡");
    [self performSelectorOnMainThread:@selector(updateTxt:) withObject:@"请刷卡" waitUntilDone:YES];
}
#pragma mark dataReturn Delegate
//通知监听器控制器CSwiperController的操作被中断
-(void)onInterrupted
{
    
}
- (void)dataArrive:(vcom_Result *)vs Status:(int)_status
{
    if(_status==-3){
        //设备没有响应
        NSLog(@"通信超时");
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"通行超时" waitUntilDone:NO];
        return;
    }else if(_status == -2){
        //耳机没有插入
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"耳机没有插入" waitUntilDone:NO];
        return;
    }else if(_status==-1){
        //接收数据的格式错误
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"接收数据的格式错误" waitUntilDone:NO];
        
    }else {
        //操作指令正确
        if(vs->res==0){
            
            if(vs->rescode[0] == 0x09 && vs->rescode[1]== 0x37)
            {
                
            }
            
            
            //设备有成功返回指令
            NSString *succStr = @"";
            NSMutableString *strTemp = [[NSMutableString alloc] initWithCapacity:0];
            //获取psam卡号
            if (vs->psamnoLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n psamNum:%@", succStr,[self HexValue:vs->psamno  Len:vs->psamnoLen]]];
            }
            //获取mac
            if (vs->maclen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,mac:%@" , succStr,[self HexValue:vs->mac Len:vs->maclen]]];
                
            }
            //校验mac
            bool rs = vs->macVerifyResult;
            if (rs == 1) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,校验mac结果: %d", succStr,rs]];
            }
            //打印
            
            //刷卡连续操作
            if(vs->pinEncryptionLen > 0)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n pinEncryption：%@", [self HexValue:vs->pinEncryption Len:vs->pinEncryptionLen]]];
            }
            ////磁道
            if (vs->trackPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackPlaintext:%@",[self HexValue:vs->trackPlaintext Len:vs->trackPlaintextLen]]];
                
            }
            if (vs->trackEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackEncryption:%@",[self HexValue:vs->trackEncryption Len:vs->trackEncryptionLen]]];
                
            }
            if (vs->cardPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardPlaintext:%@", [self HexValue:vs->cardPlaintext Len:vs->cardPlaintextLen]]];
                
            }
            if (vs->cardEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardEncryption:%@", [self HexValue:vs->cardEncryption Len:vs->cardEncryptionLen]]];
                
            }
            if (vs->panLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n pan码:%@",[self HexValue:vs->pan Len:vs->panLen] ]];
            }
            if (vs->hardSerialNoLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n hardNo:%@",[self HexValue:vs->hardSerialNo Len:vs->hardSerialNoLen] ]];
            }
            if (vs->traderNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n shnoInPsam:%@",[self HexValue:vs->traderNoInPsam Len:vs->traderNoInPsamLen] ]];
                
            }
            if (vs->termialNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n zdnoInPsam:%@",[self HexValue:vs->termialNoInPsam Len:vs->termialNoInPsamLen] ]];
                
            }
            if (vs->userInputLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n userInput:%@",[self HexValue:vs->userInput Len:vs->userInputLen] ]];
            }
            
            if (vs->cdnolen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cdno:%s",vs->cdno]];
                NSString *str1=[NSString stringWithCString:vs->cdno  encoding:NSUTF8StringEncoding];
                NSLog(@"str1 is %@", str1);
                
            }
            if (vs->deviceLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n deviceKind:%@",[self HexValue:vs->deviceKind Len:1] ]];
                
            }
            if (vs->data55Len>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n data55:%@",[self HexValue:vs->data55 Len:vs->data55Len] ]];
                
            }
            if (vs->cvmLen >0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cvm:%@",[self HexValue:vs->cvmData Len:vs->cvmLen] ]];
            }
            if (vs->ICReturnDataLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ICReturnData:%@",[self HexValue:vs->ICReturnData Len:vs->ICReturnDataLen] ]];
                
            }
            if (vs->loadLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n loadData:%@",[self HexValue:vs->loadData Len:vs->loadLen] ]];
                
            }
            if (vs->xulieDataLen)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n xulieData:%@",[self HexValue:vs->xulieData Len:vs->xulieDataLen] ]];
                
            }
            /////
            if (![strTemp isEqualToString:@""]) {
                [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:strTemp waitUntilDone:NO];
            }
        }else {
            NSLog(@"cmd exec error:%d\n",vs->res);
            return;
            switch (vs->res) {
                case 1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"通信超时" waitUntilDone:NO];
                    break;
                case 2:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"PSAM卡认证失败" waitUntilDone:NO];
                    break;
                case 3:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"Psam卡上电失败或者不存在" waitUntilDone:NO];
                    break;
                case 4:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotSupportCmdFormPosToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 10:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"用户退出" waitUntilDone:NO];
                    break;
                case 11:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"MAC校验失败" waitUntilDone:NO];
                    break;
                case 12:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端加密失败" waitUntilDone:NO];
                    break;
                case 14:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"用户按了取消健" waitUntilDone:NO];
                    break;
                case 15:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"Psam卡状态异常" waitUntilDone:NO];
                    break;
                case 0x20:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不匹配的主命令码" waitUntilDone:NO];
                    break;
                case 0x21:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不匹配的子命令码" waitUntilDone:NO];
                    break;
                case 0x42:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"没有打印机" waitUntilDone:NO];
                    break;
                case 0x50:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"获取电池电量失败" waitUntilDone:NO];
                    break;
                case 0x80:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"数据接收正确" waitUntilDone:NO];
                    break;
                    
                case 0x40:
                    [self performSelectorOnMainThread:@selector(refreshStatusNoPaperInPrinterToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xe0:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"重传数据无效" waitUntilDone:NO];
                    break;
                case 0xe1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端设置待机信息失败" waitUntilDone:NO];
                    break;
                case 0xf0:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不识别的包头" waitUntilDone:NO];
                    break;
                case 0xf1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不识别的主命令码" waitUntilDone:NO];
                    break;
                    
                case 0xf2://242
                    [self performSelectorOnMainThread:@selector(refreshStatusNotVerifySubCmdToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf3:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"该版本不支持此指令" waitUntilDone:NO];
                    break;
                    
                case 0xf4:
                    [self performSelectorOnMainThread:@selector(refreshStatusRandomLengthErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf5:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不支持的部件" waitUntilDone:NO];
                    break;
                case 0xf6:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不支持的模式" waitUntilDone:NO];
                    break;
                case 0xf7:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataLengthErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                    
                case 0xfc:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataConentErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xfd:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端ID错误" waitUntilDone:NO];
                    break;
                case 0xfe:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"MAC_TK校验失败" waitUntilDone:NO];
                    break;
                case 0xff:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"校验和错误" waitUntilDone:NO];
                    break;
                default:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:[NSString stringWithFormat:@"cmd exec error:%d\n",vs->res] waitUntilDone:NO];
                    break;
            }
        }
    }
    
}

- (void)onGetKsnCompleted:(NSString *)ksn
{
    NSString* string =[[NSString alloc] initWithFormat:@"ksn:%@ ",ksn];
    _displayTextView.text = string;
    [string release];
    
}
- (void)onGetKsnAndVersionCompleted:(NSArray *)ksnAndVerson
{
    NSLog(@"ksn is %@", [ksnAndVerson objectAtIndex:0]);
    NSLog(@"version is %@", [ksnAndVerson objectAtIndex:1]);
    
    NSString *ksn = [ksnAndVerson objectAtIndex:0];
    NSString *version = [ksnAndVerson objectAtIndex:1];
    _displayTextView.text = [NSString stringWithFormat:@"ksn=%@\n version=%@",ksn, version];
    
    
}


//IC卡回写脚本执行返回结果
- (void)onICResponse:(int)result resScript:(NSString *)resuiltScript data:(NSString *)data
{
    NSLog(@"result = %d ,resScript = %@, data = %@", result, resuiltScript, data);
    NSString *string = [NSString stringWithFormat:@"IC卡回写脚本执行返回结果:%d,脚本：%@，数据：%@",result, resuiltScript, data];
    [self performSelectorOnMainThread:@selector(updateTxt:) withObject:string waitUntilDone:NO];
    
}
//设备类型回调
- (void)onDeviceKind:(int) result
{
    NSLog(@"设备类型 ： %d", result);
    [self performSelectorOnMainThread:@selector(updateTxt:) withObject:[NSString stringWithFormat:@"设备类型：%d",result] waitUntilDone:NO];
    
}
- (void)updateTxt:(NSString *)str
{
    _displayTextView.text = str;
}
// 中间状态
- (void)EmvOperationWaitiing
{
    NSString *string = @"插入了IC卡，不要拔出IC卡";
    [self performSelectorOnMainThread:@selector(updateTxt:) withObject:string waitUntilDone:NO];
    NSLog(@"EmvOperationWaitiing");
}

//参数下载回调
- (void)onLoadParam:(NSString *)param
{
    NSLog(@"参数下载：%@",param);
    //    [self performSelectorInBackground:@selector(sendParm) withObject:nil];
}

- (void)sendParm
{
    if(pageNum1 == 4)
    {
        return;
    }
    NSString *str = nil;
    NSString *str1 = nil;
    if(pageNum1 ==1){
        str = @"319f0605a0000003339f220104df050420241231df060101df070101df0281f8bc853e6b5365e89e7ee9317c94b02d0abb0dbd91c05a224a2554aa29ed9fcb9d86eb9ccbb322a57811f86188aac7351c72bd9ef196c5a01acef7a4eb0d2ad63d9e6ac2e7836547cb1595c68bcbafd0f6728760f3a7ca7b97301b7e0220184efc4f653008d93ce098c0d93b45201096d1adff4cf1f9fc02af759da27cd6dfd6d789b099f16f378b6100334e63f3d35f3251a5ec78693731f5233519cdb380f5ab8c0f02728e91d469abd0eae0d93b1cc66ce127b29c7d77441a49d09fca5d6d9762fc74c31bb506c8bae3c79ad6c2578775b95956b5370d1d0519e37906b384736233251e8f09ad79dfbe2c6abfadac8e4d8624318c27daf1df040103df0314f527081cf371dd7e1fd4fa414a665036e0f5e6e5";
        str1 = @"319F0608A000000333010103DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
    }
    if(pageNum1==2){
        str = @"319F0605A0000003339F220102DF050420211231DF060101DF070101DF028190A3767ABD1B6AA69D7F3FBF28C092DE9ED1E658BA5F0909AF7A1CCD907373B7210FDEB16287BA8E78E1529F443976FD27F991EC67D95E5F4E96B127CAB2396A94D6E45CDA44CA4C4867570D6B07542F8D4BF9FF97975DB9891515E66F525D2B3CBEB6D662BFB6C3F338E93B02142BFC44173A3764C56AADD202075B26DC2F9F7D7AE74BD7D00FD05EE430032663D27A57DF040103DF031403BB335A8549A03B87AB089D006F60852E4B8060";
        str1 = @"319F0608A000000333010101DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
        
    }
    if (pageNum1 == 3) {
        str1 = @"319F0608A000000333010106DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160120DF170110DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
        str = @"319F0605A0000003339F220102DF050420211231DF060101DF070101DF028190A3767ABD1B6AA69D7F3FBF28C092DE9ED1E658BA5F0909AF7A1CCD907373B7210FDEB16287BA8E78E1529F443976FD27F991EC67D95E5F4E96B127CAB2396A94D6E45CDA44CA4C4867570D6B07542F8D4BF9FF97975DB9891515E66F525D2B3CBEB6D662BFB6C3F338E93B02142BFC44173A3764C56AADD202075B26DC2F9F7D7AE74BD7D00FD05EE430032663D27A57DF040103DF031403BB335A8549A03B87AB089D006F60852E4B8060";
    }
    
    char * temp=HexToBin0((char *)[str UTF8String]);
    int datalen = (int)[str1 length]/2;
    char data[datalen];
    memcpy(data, temp, datalen);
    
    [cmManager UpdateTerminalParameters:0 pageNum:pageNum1++ data:data dataLen:datalen time:6];
}

- (void)onError:(NSInteger) code msg:(NSString*) msg
{
    NSLog(@"%d", [cmManager isConnected]);
    NSLog(@"onError:%d mesage:%@", (int)code, msg);
}
- (void)onTimeout
{
    NSLog(@"-----------------通信超时--------------------");
}
//通知监听器刷卡器插入手机
-(void) onDevicePlugged
{
    NSString *string =@"耳机插入";
    NSLog(@"耳机插入");
    [self performSelectorOnMainThread:@selector(updateTxt:) withObject:string waitUntilDone:NO];
}
//通知监听器刷卡器已从手机拔出
-(void) onDeviceUnPlugged
{
    _displayTextView.text=@"耳机拔出";
    NSLog(@"耳机拔出");
}
- (void)onError:(int)errorCode ErrorMessage:(NSString *)errorMessage;
{
    if (errorCode == -3) {
        NSLog(@"获取ksn失败");
        [self performSelectorOnMainThread:@selector(updateTxt:) withObject:@"获取ksn失败" waitUntilDone:YES];
    }
    else{
        [self performSelectorOnMainThread:@selector(updateTxt:) withObject:errorMessage waitUntilDone:YES];
    }
}
//ic卡刷卡器回调。
-(void)onDecodeCompleted:(NSString*) formatID
                  andKsn:(NSString*) ksn
            andencTracks:(NSString*) encTracks
         andTrack1Length:(int) track1Length
         andTrack2Length:(int) track2Length
         andTrack3Length:(int) track3Length
         andRandomNumber:(NSString*) randomNumber
           andCardNumber:(NSString *)maskedPAN
                  andPAN:(NSString*) pan
           andExpiryDate:(NSString*) expiryDate
       andCardHolderName:(NSString*) cardHolderName
                  andMac:(NSString *)mac
        andQTPlayReadBuf:(NSString*) readBuf
                cardType:(int)type
              cardserial:(NSString *)serialNum
             emvDataInfo:(NSString *)data55
                 cvmData:(NSString *)cvm
                   mLen2:(int)mlen2
                   mLen3:(int)mlen3
                   wLen2:(int)wlen2
                   wLen3:(int)wlen3
{
    NSLog(@"mLen2 == %d,mLen3 == %d", mlen2, mlen3);
    NSLog(@"wLen3 == %d,wLen3 == %d", wlen2, wlen3);
    NSLog(@"ksn %@" ,ksn);
    NSLog(@"encTracks %@" ,encTracks);
    NSLog(@"track1Length %i",track1Length);
    NSLog(@"track2Length %i",track2Length);
    NSLog(@"track3Length %i",track3Length);
    NSLog(@"randomNumber %@",randomNumber);
    NSLog(@"maskedPAN %@",maskedPAN);
    NSLog(@"expiryDate %@",expiryDate);
    NSLog(@"pan:%@", pan);
    NSString* string =[[NSString alloc] initWithFormat:@"ksn:%@\n encTracks:%@ \n track1Length:%i \n track2Length:%i \n track3Length:%i \n randomNumber:%@ \n cardNum:%@ \n PAN:%@ \n expiryDate:%@ \n cardHolderName:%@ \n mac:%@ \n cardType:%d \n cardSerial:%@ \n emvDataInfo:%@ \n cmv:%@  \n readBuf:%@",ksn,encTracks,track1Length,track2Length,track3Length,randomNumber, maskedPAN,pan,expiryDate,cardHolderName,mac,type,serialNum,data55,cvm,readBuf];
    NSLog(@"%@",string);
    _displayTextView.text =string;
    _displayTextView.userInteractionEnabled = YES;
    [string release];
    
}


-(void)onDecodeCompleted:(NSString*) formatID
                  andKsn:(NSString*) ksn
            andencTracks:(NSString*) encTracks
         andTrack1Length:(int) track1Length
         andTrack2Length:(int) track2Length
         andTrack3Length:(int) track3Length
         andRandomNumber:(NSString*) randomNumber
           andCardNumber:(NSString *)maskedPAN
                  andPAN:(NSString*) pan
           andExpiryDate:(NSString*) expiryDate
       andCardHolderName:(NSString*) cardHolderName
                  andMac:(NSString *)mac
        andQTPlayReadBuf:(NSString*) readBuf
                cardType:(int)type
              cardserial:(NSString *)serialNum
             emvDataInfo:(NSString *)data55
                 cvmData:(NSString *)cvm
{
    NSLog(@"回调函数接受返回数据");
    NSLog(@"ksn %@" ,ksn);
    NSLog(@"encTracks %@" ,encTracks);
    NSLog(@"track1Length %i",track1Length);
    NSLog(@"track2Length %i",track2Length);
    NSLog(@"track3Length %i",track3Length);
    NSLog(@"randomNumber %@",randomNumber);
    NSLog(@"maskedPAN %@",maskedPAN);
    NSLog(@"expiryDate %@",expiryDate);
    NSLog(@"pan:%@", pan);
    NSString* string =[[NSString alloc] initWithFormat:@"ksn:%@\n encTracks:%@ \n track1Length:%i \n track2Length:%i \n track3Length:%i \n randomNumber:%@ \n cardNum:%@ \n PAN:%@ \n expiryDate:%@ \n cardHolderName:%@ \n mac:%@ \n cardType:%d \n cardSerial:%@ \n emvDataInfo:%@ \n cmv:%@  \n readBuf:%@",ksn,encTracks,track1Length,track2Length,track3Length,randomNumber, maskedPAN,pan,expiryDate,cardHolderName,mac,type,serialNum,data55,cvm,readBuf];
    NSLog(@"%@",string);
    _displayTextView.text =string;
    _displayTextView.userInteractionEnabled = YES;
    [string release];
}
- (void)didfinishICUpdate{
    
    NSLog(@"公钥修复完成！");
}
- (void)updateMytextView:(NSString *)str{
    
    _displayTextView.text = str;
    NSLog(@"string == %@", str);
}
@end
