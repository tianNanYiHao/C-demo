
//
//  iTronSwipeDeviceViewController.h : interface for the iTronSwipeDeviceViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import <UIKit/UIKit.h>
#import "vcom.h"
#import <Foundation/Foundation.h>
#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MessageUI.h>
#import "CSwiperStateChangedListener.h"
//#import "vcomEvt.h"
#import "QCheckBox.h"

@interface iTronSwipeDeviceViewController : UIViewController<CSwiperStateChangedListener,UITextViewDelegate,MFMailComposeViewControllerDelegate,QCheckBoxDelegate>
{
    vcom* m_vcom;
    UITextView *_cardInfoView;
    id timer;
    id timerForAishua;
}
@property (nonatomic,retain) UITextView *cardInfoView;
@property (nonatomic,retain) UIButton *getKsnBtn;
@property (nonatomic,retain) UIButton *swipeCardBtn;
@property (nonatomic,retain) UIButton *stopBtn;

-(void)refreshSwipeDisplay:(NSString *)displayData;
@end
