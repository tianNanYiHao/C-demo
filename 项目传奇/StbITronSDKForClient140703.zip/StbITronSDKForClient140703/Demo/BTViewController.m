//
//  BTViewController.m
//  StaticLibSDKDemo
//
//  Created by hezewen on 14-5-27.
//
//

#import "BTViewController.h"

#define HEIGHT   [[UIScreen mainScreen] applicationFrame].size.height


@interface BTViewController ()
{
    NSArray *commandDataArr;
    UITableView * myTable;
    NSMutableArray *deviceArr;
    UITextView * myTXTView;
    UILabel *lab;
    UILabel *retLab;
}
@end

@implementation BTViewController

char bout11[4096];
int  boutlen11;
char* HexToBin11(char* hin)
{
	int i;
	char highbyte,lowbyte;
	int len= (int)strlen(hin);
	for (i=0;i<len/2;i++)
	{
		if (hin[i*2]>='0'&&hin[i*2]<='9')
			highbyte=hin[i*2]-'0';
		if (hin[i*2]>='A'&&hin[i*2]<='F')
			highbyte=hin[i*2]-'A'+10;
		if (hin[i*2]>='a'&&hin[i*2]<='f')
			highbyte=hin[i*2]-'a'+10;
		
		if (hin[i*2+1]>='0'&&hin[i*2+1]<='9')
			lowbyte=hin[i*2+1]-'0';
		if (hin[i*2+1]>='A'&&hin[i*2+1]<='F')
			lowbyte=hin[i*2+1]-'A'+10;
		if (hin[i*2+1]>='a'&&hin[i*2+1]<='f')
			lowbyte=hin[i*2+1]-'a'+10;
		
		bout11[i]=(highbyte<<4)|(lowbyte);
	}
	boutlen11=len/2;
	return bout11;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"蓝牙通讯测试界面";
        self.view.backgroundColor = [UIColor lightGrayColor];
        deviceArr = [[NSMutableArray alloc] initWithCapacity:0];
        myRandom = "12345678";
        myRandomLen = 3;
    }
    return self;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [cmManager closeDevice];

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    commandDataArr = [[NSArray alloc] initWithObjects:@"获取卡号", @"获取磁道明文", @"获取PIN", @"MAC计算", @"刷卡密码连续指令", @"获取终端号商户号", @"修改终端号商户号", @"获取psam卡号", @"获取磁道密文", @"请求输入", @"打印", @"透传测试", nil];
    pkView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, HEIGHT-120, 320, 120)];
    pkView.dataSource = self;
    pkView.delegate = self;
    [self.view addSubview:pkView];
    [pkView release];
    
    lab = [[UILabel alloc] initWithFrame:CGRectMake(10, 80, 120, 36)];
    NSString *str = [commandDataArr objectAtIndex:0];
    [lab setFont:[UIFont systemFontOfSize:14]];
    lab.text = str;
    lab.alpha = 0.9;
    lab.layer.cornerRadius =2;
    lab.layer.borderWidth = 0.5;
    [self.view addSubview:lab];
    [lab release];
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(180-5, 80, 125, 36)];
    [button setTitle:@"点击发送指令" forState:UIControlStateNormal];
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [button setFont:[UIFont systemFontOfSize:14]];

    [button setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    button.layer.cornerRadius = 2;
    button.layer.borderWidth = 0.5;
    [button setBackgroundColor:[UIColor colorWithRed:205/250.0f green:156/255.0f blue:248/255.0f alpha:1.0f]];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];

    [button addTarget:self action:@selector(sendCMD:) forControlEvents:UIControlEventTouchUpInside];
    [button release];
    /*************************************/
    myTXTView = [[UITextView alloc] initWithFrame:CGRectMake(lab.frame.origin.x, lab.frame.origin.y+lab.frame.size.height+10, 140, 210)];
    myTXTView.delegate = self;
    myTXTView.layer.cornerRadius = 5;
    myTXTView.layer.borderWidth = 0.5;
    myTXTView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:myTXTView];
    [myTXTView release];
    /************************************************/
    
    cmManager = [CommunicationManagerBase getInstance];
    cmManager.communication = self;
    //
    UIButton *searchBth = [[UIButton alloc] initWithFrame:CGRectMake(170, lab.frame.origin.y + lab.frame.size.height+20, 100, 36)];
    [searchBth setTitle:@"搜索蓝牙设备" forState:UIControlStateNormal];
    searchBth.layer.cornerRadius = 2;
    searchBth.layer.borderWidth = 0.5;
    [searchBth setBackgroundColor:[UIColor colorWithRed:205/250.0f green:156/255.0f blue:248/255.0f alpha:1.0f]];
    searchBth.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [searchBth setFont:[UIFont systemFontOfSize:14]];
    [searchBth setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [searchBth addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];
    [searchBth addTarget:self action:@selector(seachBtDevices:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:searchBth];
    [searchBth release];
    /***************************************************************/
    myTable = [[UITableView alloc] initWithFrame:CGRectMake(170, searchBth.frame.origin.y+searchBth.frame.size.height+8, 130, 150)];
    myTable.dataSource = self;
    myTable.delegate = self;
    myTable.layer.cornerRadius = 5;
    myTable.layer.borderWidth = 0.5;
    myTable.backgroundColor = [UIColor clearColor];
    [self.view addSubview:myTable];
    [myTable release];
    
    retLab = [[UILabel alloc] initWithFrame:CGRectMake(myTable.frame.origin.x, myTable.frame.origin.y+myTable.frame.size.height+4, 80, 30)];
    retLab.text = @"蓝牙状态";
    retLab.font = [UIFont systemFontOfSize:12];
    retLab.layer.cornerRadius = 2;
    retLab.layer.borderWidth = 0.5;
    [self.view addSubview:retLab];
    [retLab release];
    
}

- (void)seachBtDevices:(UIButton *)btn
{
    btn.alpha = 1.0;
    [deviceArr removeAllObjects];
    [cmManager searchDevices:self timeout:15*1000];

}
- (void)touchDown:(UIButton *)btn
{
    btn.alpha = 0.6;
}
//发送指令
- (void)sendCMD:(UIButton *)btn
{
    btn.alpha = 1;
//    commandDataArr = [[NSArray alloc] initWithObjects:@"获取卡号", @"获取磁道明文", @"获取PIN", @"MAC计算", @"刷卡密码连续指令", @"获取终端号商户号", @"修改终端号商户号",@“获取磁道密文”,@"请求输入", nil];
    myTXTView.text=@"";
    switch ([pkView selectedRowInComponent:0]) {
        case 0://获取卡号
            [cmManager Request_GetCardNo:60];
            break;
        case 1://获取磁道明文
            [cmManager Request_GetTrackPlaintext:60];
            break;
        case 2://获取PIN
            [cmManager Request_GetPin:0 keyIndex:1 cash:"12345" cashLen:5 random:myRandom randomLen:myRandomLen panData:"" pandDataLen:0 time:60];
            break;
        case 3://MAC计算
            {
                NSString *str = @"1990050000000000100000011719241217313233343531323334353834";
                char *temp = HexToBin11((char *)[str UTF8String]);
                int datalen = (int)[str length]/2;
                NSLog(@"数据长度%i",datalen);
                char data[datalen];
                memcpy(data, temp, datalen);
                [cmManager Request_GetMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen];
            }
            break;
        case 4://刷卡密码连续指令
            {
                NSString *appendDataStr = @"499000032000151413";
                int len = [appendDataStr length]/2;
//                char *appendData =  HexToBin11((char *)[appendDataStr UTF8String]);
                char *appendData = [cmManager HexToBin1:((char *)[appendDataStr UTF8String])];
                
//                char appendDataChar[100];
//                strcpy(appendDataChar,(char*)[appendData UTF8String]);
//                int appendlen =(int)[appendData length];
//                NSLog(@"appendlen %d",appendlen);
                
                [cmManager Request_ExtCtrlConOper:1 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:0x1c ParameterRandom:myRandom ParameterRandomLen:myRandomLen cash:"100" cashLen:3 appendData:"" appendDataLen:0 time:30];
            }
            break;
            
        case 5://获取终端号商户号
            [cmManager Request_VT];
            break;
        case 6://修改终端号商户号
            [cmManager Request_ReNewVT:"122010000201" vendorLen:15 terid:"99960000" teridLen:8];
            break;
        case 7://获取psam卡号和硬件序列号
            [cmManager Request_GetExtKsn];
            break;
        case 8://获取磁道密文
            [cmManager Request_GetDes:0 keyIndex:1 random:myRandom randomLen:myRandomLen time:60];
        case 9://请求输入
            [cmManager Get_Userinput:0x01 timeout:60 min:2 max:6 keyindex:0 random:myRandom randomLen:myRandomLen title:"abc" titleLen:3];
            break;
        case 10://打印
        {
            
//            NSMutableArray *test=[[NSMutableArray alloc]initWithObjects:nil];
//            NSArray *valueArr =[[NSArray alloc] initWithObjects:@"111merchantName", @"merchantNo", @"111terminalNo", @"111operator", @"111acquirer", @"111acquirer", @"111", @"111merchantName", @"111merchantName", @"111merchantName", @"111merchantName", @"111merchantName", @"111merchantName", nil];
//            NSArray *keyArr = [[NSArray alloc] initWithObjects:@"merchantName",@"merchantNo",@"terminalNo",@"operator",@"acquirer",@"expDate",@"cardNo",@"transType",@"voucherNo",@"authNo",@"referNO",@"dateTime", @"amount",nil];
//            NSDictionary *dic = [[NSDictionary  alloc] initWithObjects:valueArr forKeys:keyArr];
//            [test addObject:@"00           POS签购单            "];
//            [test addObject:@"00==============================="];
//            [test addObject:[NSString stringWithFormat:@"00商户名称(MERCHANT NAME):\n%@",[dic objectForKey:@"merchantName"]]];
//            [test addObject:[NSString stringWithFormat:@"00商户编号(MERCHANT NO):%@",[dic objectForKey:@"merchantNo"]]];
//            [test addObject:[NSString stringWithFormat:@"00终端编号(TERMINAL NO):%@",[dic objectForKey:@"terminalNo"]]];
//            [test addObject:[NSString stringWithFormat:@"00操作员号(OPERATOR NO):%@",[dic objectForKey:@"operator"]]];
//            [test addObject:[NSString stringWithFormat:@"00发卡｀(ISSUER):%@",[dic objectForKey:@"issuer"]]];
//            [test addObject:[NSString stringWithFormat:@"00收单行(ACQUIRER):%@",[dic objectForKey:@"acquirer"]]];
//            [test addObject:[NSString stringWithFormat:@"00有效期(EXP DATE):%@",[dic objectForKey:@"expDate"]]];
//            [test addObject:[NSString stringWithFormat:@"00卡号(CARD NO):  \n%@",[dic objectForKey:@"cardNo"]]];
//            [test addObject:[NSString stringWithFormat:@"00交易类型(TRANS TYPE):  \n%@",[dic objectForKey:@"transType"]]];
//            [test addObject:[NSString stringWithFormat:@"00批次号(BATCH NO):  \n%@",@"batchNo"]];
//            [test addObject:[NSString stringWithFormat:@"00凭证号(VOUCHER NO):%@",[dic objectForKey:@"voucherNo"]]];
//            [test addObject:[NSString stringWithFormat:@"00授权码(AUTH NO):%@",[dic objectForKey:@"authNo"]]];
//            [test addObject:[NSString stringWithFormat:@"00参考号(REFER NO):%@",[dic objectForKey:@"referNO"]]];
//            [test addObject:[NSString stringWithFormat:@"00日期时间(DATE TIME):  \n%@",[dic objectForKey:@"dateTime"]]];
//            [test addObject:[NSString stringWithFormat:@"00金额(AMOUNT):      \n%@",[dic objectForKey:@"amount"]]];
//            [test addObject:[NSString stringWithFormat:@"00备注(REFERENCE):      "]];
//            [test addObject: @"21持卡人签名:\n\n\n商户存根\n- - - - - 由此线撕开 - - - - - -"] ;
//            [test addObject: @"22持卡人存根\n- - - - - 由此线撕开 - - - - - -"] ;
//            printf("发送指令-test完成\n");
//            NSLog(@"test:>>>>>>>>%@",test);
            
//            
//            NSString *appName = @"yft";//[dict objectForKey:@"app_name"];
//            NSString *memberNo = @"15957120196";//[dict objectForKey:@"memberNo"];
//            NSString *termNo = @"12345673";//[dict objectForKey:@"termNo"];
//            NSString *cardNo = @"12345678";//[dict objectForKey:@"cardNo"];
//            NSString *date = @"2014-7-29 17:24";//[dict objectForKey:@"date"];
//            NSString *order = @"123455678889";//[dict objectForKey:@"order"];
//            NSString *money = @"123";//[dict objectForKey:@"money"];
//            NSString *reason = @"";//[dict objectForKey:@"reason"];
//
//            
//            NSMutableArray *test=[[NSMutableArray alloc]initWithObjects:nil];
//            
//            [test addObject:[NSString stringWithFormat:@"11%@\n\n商户存根            请妥善保管",appName]];
//            [test addObject:[NSString stringWithFormat:@"00商户编号（MERCHAANT NO）：\n%@",memberNo]];
//            [test addObject:[NSString stringWithFormat:@"00终端编号（TERMINAL NO）：\n%@",termNo]];
//            [test addObject:[NSString stringWithFormat:@"00卡号（CARD NUMBER）：\n%@",cardNo]];
//            [test addObject:[NSString stringWithFormat:@"00交易类型（TRANS TYPE）：\n    消费（SALE）"]];
//            [test addObject:[NSString stringWithFormat:@"00交易时间（DATE/TIME）：\n    %@",date]];
//            [test addObject:[NSString stringWithFormat:@"00流水号（TRADE NO）：\n%@",order]];
//            [test addObject:[NSString stringWithFormat:@"00交易金额（AMOUNT）： RMB %@",money]];
//            [test addObject:[NSString stringWithFormat:@"00备注（REFERENCE）：%@",reason]];
//            [test addObject: @"21持卡人签名（SIGNATURE）：\n\n\n\n\n\n\n本人确认以上交易，同意将其计入本卡账户\nI ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES\n- - - - - 由此线撕开 - - - - - -\n\n"] ;
//            
//            [test addObject:[NSString stringWithFormat:@"12%@\n\n持卡人存根            请妥善保管",appName]];
//            [test addObject:[NSString stringWithFormat:@"00商户编号（MERCHAANT NO）：\n%@",memberNo]];
//            [test addObject:[NSString stringWithFormat:@"00终端编号（TERMINAL NO）：\n%@",termNo]];
//            [test addObject:[NSString stringWithFormat:@"00卡号（CARD NUMBER）：\n%@",cardNo]];
//            [test addObject:[NSString stringWithFormat:@"00交易类型（TRANS TYPE）：\n    消费（SALE）"]];
//            [test addObject:[NSString stringWithFormat:@"00交易时间（DATE/TIME）：\n    %@",date]];
//            [test addObject:[NSString stringWithFormat:@"00流水号（TRADE NO）：\n%@",order]];
//            [test addObject:[NSString stringWithFormat:@"00交易金额（AMOUNT）： RMB %@",money]];
//            [test addObject:[NSString stringWithFormat:@"00备注（REFERENCE）：%@",reason]];
//            [test addObject: @"21\n- - - - - 由此线撕开 - - - - - -"];
//            printf("发送指令-test完成\n");
//            NSLog(@"test:>>>>>>>>%@",test);
//            
//            
//            [cmManager rmPrint3:test pCnt:2 pakLen:1000];
////            [cmManager rmPrint3:test pCnt:1 pakLen:1000];
            NSString *appName = @"yft";//[dict objectForKey:@"app_name"];
            NSString *memberNo = @"15957120196";//[dict objectForKey:@"memberNo"];
            NSString *termNo = @"12345673";//[dict objectForKey:@"termNo"];
            NSString *cardNo = @"12345678";//[dict objectForKey:@"cardNo"];
            NSString *date = @"2014-7-29 17:24";//[dict objectForKey:@"date"];
            NSString *order = @"123455678889";//[dict objectForKey:@"order"];
            NSString *money = @"123";//[dict objectForKey:@"money"];
            NSString *reason = @"";//[dict objectForKey:@"reason"];
            
            
            NSMutableArray *test=[[NSMutableArray alloc]initWithObjects:nil];
            
            [test addObject:[NSString stringWithFormat:@"11%@\n\n商户存根            请妥善保管",appName]];
            [test addObject:[NSString stringWithFormat:@"00商户编号（MERCHAANT NO）：\n%@",memberNo]];
            [test addObject:[NSString stringWithFormat:@"00终端编号（TERMINAL NO）：\n%@",termNo]];
            [test addObject:[NSString stringWithFormat:@"00卡号（CARD NUMBER）：\n%@",cardNo]];
            [test addObject:[NSString stringWithFormat:@"00交易类型（TRANS TYPE）：\n    消费（SALE）"]];
            [test addObject:[NSString stringWithFormat:@"00交易时间（DATE/TIME）：\n    %@",date]];
            [test addObject:[NSString stringWithFormat:@"00流水号（TRADE NO）：\n%@",order]];
            [test addObject:[NSString stringWithFormat:@"00交易金额（AMOUNT）： RMB %@",money]];
            [test addObject:[NSString stringWithFormat:@"00备注（REFERENCE）：%@",reason]];
            [test addObject: @"21持卡人签名（SIGNATURE）：\n\n\n\n\n\n\n本人确认以上交易，同意将其计入本卡账户\nI ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES\n- - - - - 由此线撕开 - - - - - -\n\n"] ;
            
            [test addObject:[NSString stringWithFormat:@"12%@\n\n持卡人存根            请妥善保管",appName]];
            [test addObject: @"22\n- - - - - 由此线撕开 - - - - - -"] ;
            
            [cmManager rmPrint3:test pCnt:2 pakLen:1000];
            
            
        }

            break;
        case 11://
        {
            NSString *str = @"01310D3000A4040007A0000003330101063000B2010C00";
            char * temp=HexToBin11((char *)[str UTF8String]);
            int datalen = [str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            [cmManager Request_ThroughOrders:1 OrdersIndex:3 OrdersData:data OrdersLegth:datalen TimeOut:20];
        }
            break;
        default:
            break;
    }
}
#pragma mark DeviceSearchListener method
- (void)discoverOneDevice:(CBPeripheral *)peripheral
{
    [deviceArr addObject:peripheral];
    NSLog(@"name is %@",peripheral.name);
    [self updateTable];
}
- (void)discoverComplete
{
    NSLog(@"-----------------搜索结束-----------------");

}
- (void)updateTable
{
    [myTable reloadData];
    
}
//char hout99[4096];
//
//char* BinToHex99(char* bin,int off,int len)
//{
////    memset(hout99, 0, 4096);
//    NSLog(@"hout99- >%s %p", hout99, hout99);
//	int i;
//	//	hout=(char*)hout;
//	for (i=0;i<len;i++)
//	{
//		sprintf((char*)hout99+i*2,"%02x",*(unsigned char*)((char*)bin+i+off));
//	}
//	hout99[len*2]=0;
//	return hout99;
//}
char hout99[4096];
char* BinToHex99(char* bin,int off,int len)
{
	int i;
	//	hout=(char*)hout;
	for (i=0;i<len;i++)
	{
		sprintf((char*)hout99+i*2,"%02x",*(unsigned char*)((char*)bin+i+off));
	}
	hout99[len*2]=0;
	return hout99;
}

#pragma mark Communication method
- (void)dataArrive:(Data_Result *)vs Status:(int)_status
{
    
    if(_status==-3){
        //设备没有响应
        NSLog(@"通信超时");
        return;
    }else if(_status == -2){
        //耳机没有插入
        return;
    }else if(_status==-1){
        //接收数据的格式错误
    }
    else{
        //操作指令正确
        if(vs->res==0){
        //设备有成功返回指令
            NSString *succStr = @"";
            NSMutableString *strTemp = [[NSMutableString alloc] initWithCapacity:0];
            //获取psam卡号
            if (vs->psamnoLen>0) {
                NSLog(@"%s", BinToHex99(vs->psamno, 0, vs->psamnoLen));
                [strTemp appendString:[NSString stringWithFormat:@"%@\n psamNum:%@, psamnoLen:%d", succStr,[self HexValue:vs->psamno Len:vs->psamnoLen],vs->psamnoLen ]];
            }
            //获取mac
            if (vs->macresLen>0) {
                NSLog(@"macresLen = %s", vs->macres);
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,mac:%@, Len:%d" , succStr,[self HexValue:vs->macres Len:vs->macresLen], vs->psamnoLen]];
                
            }
            //校验mac
            bool rs = vs->macVerifyResult;
            if (rs == 1) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,校验mac结果: %d", succStr,rs]];
            }
            //打印
            
            //刷卡连续操作
            if(vs->pinEncryptionLen > 0)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n pinEncryption：%@", [self HexValue:vs->pinEncryption Len:vs->pinEncryptionLen]]];
            }
            ////磁道
            if (vs->trackPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackPlaintext:%@",[self HexValue:vs->trackPlaintext Len:vs->trackPlaintextLen]]];
            }
            if (vs->trackEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackEncryption:%@",[self HexValue:vs->trackEncryption Len:vs->trackEncryptionLen]]];
                
                
            }
            if (vs->cardPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardPlaintext:%s", vs->cardPlaintext]];
                
            }
            if (vs->cardEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardEncryption:%@", [self HexValue:vs->cardEncryption Len:vs->cardEncryptionLen]]];
                
            }
            if (vs->panLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n pan码:%@",[self HexValue:vs->pan Len:vs->panLen] ]];
            }
            if (vs->hardSerialNoLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n hardNo:%@",[self HexValue:vs->hardSerialNo Len:vs->hardSerialNoLen] ]];
            }
            if (vs->traderNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n shnoInPsam:%@",[self HexValue:vs->traderNoInPsam Len:vs->traderNoInPsamLen] ]];
                
            }
            if (vs->termialNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n zdnoInPsam:%@",[self HexValue:vs->termialNoInPsam Len:vs->termialNoInPsamLen] ]];
                
            }
            if (vs->userInputLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n userInput:%@",[self HexValue:vs->userInput Len:vs->userInputLen] ]];
            }
            if (vs->cdnolen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cdno:%s",vs->cdno]];
                NSString *str1=[NSString stringWithCString:vs->cdno  encoding:NSUTF8StringEncoding];
                NSLog(@"str1 is %@", str1);
                
            }
            if (vs->orderLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ordersData:%@", [self HexValue:vs->Return_orders Len:vs->orderLen]]];
            }

            if (![strTemp isEqualToString:@""]) {
                [self performSelectorOnMainThread:@selector(updateData:) withObject:strTemp waitUntilDone:NO];
            }

    
        }
        else
        {
            NSLog(@"cmd exec error:%d\n",vs->res);
            switch (vs->res) {
                case 1:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"通信超时" waitUntilDone:NO];
                    break;
                case 2:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"PSAM卡认证失败" waitUntilDone:NO];
                    break;
                case 3:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"Psam卡上电失败或者不存在" waitUntilDone:NO];
                    break;
                case 4:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotSupportCmdFormPosToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 10:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"用户退出" waitUntilDone:NO];
                    break;
                case 11:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"MAC校验失败" waitUntilDone:NO];
                    break;
                case 12:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"终端加密失败" waitUntilDone:NO];
                    break;
                case 14:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"用户按了取消健" waitUntilDone:NO];
                    break;
                case 15:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"Psam卡状态异常" waitUntilDone:NO];
                    break;
                case 0x20:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不匹配的主命令码" waitUntilDone:NO];
                    break;
                case 0x21:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不匹配的子命令码" waitUntilDone:NO];
                    break;
                case 0x50:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"获取电池电量失败" waitUntilDone:NO];
                    break;
                case 0x80:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"数据接收正确" waitUntilDone:NO];
                    break;
                    
                case 0x40:
                    [self performSelectorOnMainThread:@selector(refreshStatusNoPaperInPrinterToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xe0:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"重传数据无效" waitUntilDone:NO];
                    break;
                case 0xe1:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"终端设置待机信息失败" waitUntilDone:NO];
                    break;
                case 0xf0:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不识别的包头" waitUntilDone:NO];
                    break;
                case 0xf1:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不识别的主命令码" waitUntilDone:NO];
                    break;
                    
                case 0xf2:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotVerifySubCmdToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf3:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"该版本不支持此指令" waitUntilDone:NO];
                    break;
                    
                case 0xf4:
                    [self performSelectorOnMainThread:@selector(refreshStatusRandomLengthErrToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf5:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不支持的部件" waitUntilDone:NO];
                    break;
                case 0xf6:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不支持的模式" waitUntilDone:NO];
                    break;
                case 0xf7:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataLengthErrToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                    
                case 0xfc:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataConentErrToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xfd:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"终端ID错误" waitUntilDone:NO];
                    break;
                case 0xfe:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"MAC_TK校验失败" waitUntilDone:NO];
                    break;
                case 0xff:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"校验和错误" waitUntilDone:NO];
                    break;
                default:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:nil waitUntilDone:NO];
                    break;
            }
            /* 失败和中间状态代码
             01
             命令执行超时
             02
             PSAM卡认证失败
             03
             Psam卡上电失败或者不存在
             04
             Psam卡操作失败
             0A
             用户退出
             0B
             MAC校验失败
             0C
             终端加密失败
             0E
             用户按了取消健
             0F
             Psam卡状态异常
             20
             不匹配的主命令码
             21
             不匹配的子命令码
             50
             获取电池电量失败
             80
             数据接收正确
             E0
             重传数据无效
             E1
             终端设置待机信息失败
             F0
             不识别的包头
             F1
             不识别的主命令码
             F2
             不识别的子命令码
             F3
             该版本不支持此指令
             F4
             随机数长度错误
             F5
             不支持的部件
             F6
             不支持的模式
             F7
             数据域长度错误
             FC
             数据域内容有误
             FD
             终端ID错误
             FE
             MAC_TK校验失败
             FF
             校验和错误
             // 打印错误
             PROTOCOL_ERR_PRT_NOPAPER     == 0X40   ;打印机缺纸
             PROTOCOL_ERR_PRT_OFF         == 0X41   ;打印机离线
             PROTOCOL_ERR_PRT_NO          == 0X42   ;没有打印机
             PROTOCOL_ERR_PRT_NOBM        == 0X43  ;没有黑标
             PROTOCOL_ERR_PRT_CLOSE       == 0X44  ;打印机关闭
             PROTOCOL_ERR_PRT_OTHER       == 0X45  ;打印机故障
             */
        }
    }
}
- (void)updateData:(NSString *)str
{
    myTXTView.text = str;
}
- (void)onError:(NSInteger) code message:(NSString*) msg
{
    NSLog(@"onError:%d mesage:%@", (int)code, msg);
}
- (void)onTimeout
{
    NSLog(@"-----------------超时--------------------");
}
//命令字响应部分
-(void)refreshStatusNotSupportCmdFormPosToPhone1
{
    myTXTView.text = @"cmd exec error:4,刷卡器硬件暂不支持该命令！";
}
-(void)refreshStatusNoReponseFromPosToPhone1
{
    myTXTView.text = @"命令超时！";
}
-(void)refreshPOSSwipeAction1
{
    myTXTView.text = @"执行命令成功！";
}

-(void)refreshStatusNotVerifySubCmdToPhone1
{
    myTXTView.text = @"cmd exec error:242,不识别的子命令码!";
}

-(void)refreshStatusRandomLengthErrToPhone1
{
    myTXTView.text = @"cmd exec error:244,随机数长度错误!";
}

-(void)refreshStatusNoPaperInPrinterToPhone1
{
    myTXTView.text = @"cmd exec error:64,打印机缺纸!";
}
-(void)refreshStatusDataLengthErrToPhone1
{
    myTXTView.text = @"cmd exec error:247,数据域长度错误!";
}
-(void)refreshStatusDataConentErrToPhone1
{
    myTXTView.text = @"cmd exec error:252,数据域内容错误!";
}
- (NSString*)HexValue:(char*)bin Len:(int)binlen{
    char *hs;
    hs = BinToHex99(bin,0,binlen);
    hs[binlen*2]=0;
    NSString* str =[[NSString alloc] initWithFormat:@"%s",hs];
    //NSLog(@"str=%@,len=%d,buf=%c",str,buflen,buf[0]);
    return str;
}


#pragma mark pickerView delegate method
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [commandDataArr count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [commandDataArr objectAtIndex:row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    lab.text =  [commandDataArr objectAtIndex:row];
}
#pragma mark UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [deviceArr count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *oneCell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (oneCell == nil) {
        oneCell  = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"] autorelease];
    
    }
    CBPeripheral *peripheral = [deviceArr objectAtIndex:indexPath.row];
    oneCell.textLabel.font = [UIFont systemFontOfSize:12];
    oneCell.textLabel.text = peripheral.name;
    return oneCell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([deviceArr count] == 0) {
        return;
    }
    CBPeripheral *peripheral = [deviceArr objectAtIndex:indexPath.row];
    
    int ret = [cmManager openDevice:peripheral cb:self timeout:15*1000];
    retLab.text = @"正在打开";
    if (ret == 0) {
        retLab.text = @"蓝牙连接成功";
        NSLog(@"%d" , [cmManager isConnected]);
        UIButton *btnn = [[UIButton alloc] initWithFrame:CGRectMake(retLab.frame.origin.x, retLab.frame.origin.y + retLab.frame.size.height +4, retLab.frame.size.width, retLab.frame.size.height)];
        [btnn setTitle:@"断开连接" forState:UIControlStateNormal];
        [btnn addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];
        [btnn addTarget:cmManager action:@selector(closeDevice) forControlEvents:UIControlEventTouchUpInside];
        [btnn setBackgroundColor:[UIColor colorWithRed:135/250.0f green:156/255.0f blue:208/255.0f alpha:1.0f]];

        btnn.layer.cornerRadius = 4;
        btnn.layer.borderWidth = 0.5;
        btnn.tag = 120;
        [btnn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [self.view addSubview:btnn];
        [btnn release];
    }
    else{
        retLab.text = @"蓝牙连接失败";
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}

#pragma mark UITextView delegate
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)closeOk
{
    retLab.text = @"蓝牙已经断开";
    NSLog(@"蓝牙已经断开");
    UIButton *btn = (UIButton *)[self.view viewWithTag:120];
    if (btn) {
        [btn removeFromSuperview];
    }
    NSLog(@" %d" ,[cmManager isConnected]);

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    [deviceArr release];
    [super dealloc];
}
@end




