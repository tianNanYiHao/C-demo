
//
//  iTronSwipeDeviceViewController.m : implementation of the iTronSwipeDeviceViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import "iTronSwipeDeviceViewController.h"
#import "vcom.h"
#define HIGHT   [[UIScreen mainScreen] applicationFrame].size.height

static int pageNum = 0;

@interface iTronSwipeDeviceViewController ()
{
    int randLength;
    UIButton *icBtn;
    UIButton *paramBtn;
    UIButton *kindBtn;
    UIButton *secondIssBtn;
}
@end

NSString * text;
int ctrlFlag;
bool readOldFileForiTronDevice = TRUE;
@implementation iTronSwipeDeviceViewController
@synthesize getKsnBtn = _getKsnBtn;
@synthesize cardInfoView = _cardInfoView;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title =@"爱刷测试界面";
        self.view.backgroundColor = [UIColor lightGrayColor];
        text = @" ";
        randLength = 0;
    }
    return self;
}
/*补位后的密码 06123456FFFFFFFF
 格式化后的pin:06127456FDDFBCCD
 ksndes:3130323133313630
 本次临时密钥:87453B5375CEE4B54682869A99E207F6
 加密后的pin:A7709A05C2F31557
 rom = 303132333435363738
 
 Printing description of pinString:
 111111
 Printing description of panString:
 0000166222169626
 Printing description of tKey:
 10213160000411854
 Printing description of rondom:
 3132333435363738
 */
- (void)transPIN:(NSString *)pinString Pan:(NSString *)panString tempKey:(NSString *)tKey Rondom:(NSString *)rondom
{
    
    
    NSLog(@"rondom == %@", rondom);
    pinString  = [NSString stringWithFormat:@"%02x%@",(int)pinString.length, pinString];
    //补齐八的倍数 后补F
    if(pinString.length < 16){
        int bw = 16 - (int)pinString.length;
        for (int i = 0; i < bw; i++) {
            pinString = [NSString stringWithFormat:@"%@%@",pinString,@"F"];
        }
    }
    pinString = [pinString uppercaseString];
    NSLog(@"补位后的密码:%@" ,pinString);
    char *tempPin = HexToBin((char *)[pinString UTF8String]);
    char pin[100];
    memcpy(pin, tempPin, [pinString length]/2);//一定要拷贝否则会占用通一块内存
    char *tempPan = HexToBin((char *)[panString UTF8String]);
    char pan[100];
    memcpy(pan, tempPan, [panString length]/2);//一定要拷贝否则会占用通一块内存
    for (int i = 0; i < panString.length/2; i++) {
        pin[i] =  (pin[i] ^ pan[i]);
    }
    NSLog(@"格式化后的pin:%s", BinToHex(pin, 0, (int)pinString.length/2));
    TribleDes  *Util = [[TribleDes alloc] init];
    //ksn需要处理下
    char *tempTK = HexToBin((char *)[[tKey substringToIndex:16] UTF8String]);
    char Tk[100];
    memcpy(Tk, tempTK, 8);//一定要拷贝否则会占用通一块内存
    tKey = [NSString stringWithFormat:@"%s", BinToHex(Tk, 0, 8)];
    tKey = [NSString stringWithFormat:@"%@%@",tKey,tKey];
    NSLog(@"TKEY: %@", tKey);
    
    NSString *lin = [Util lisan:rondom mainKey:tKey];
    NSLog(@"临时工作秘钥：%@", lin);
    pinString = [NSString stringWithFormat:@"%s", BinToHex(pin, 0, (int)pinString.length/2)];
    NSLog(@"pinSting == %@",pinString);
    NSString *encString = [Util encData:pinString mainKey:lin];
    NSLog(@"加密后的密码：%@", encString);
    
    tempPin = HexToBin((char *)[encString UTF8String]);
    memset(pin, 0, 100);
    memcpy(pin, tempPin, [encString length]/2);//一定要拷贝否则会占用通一块内存
    char *tempRom = HexToBin((char*)[rondom UTF8String]);
    char rom[100];
    memcpy(rom, tempRom, [rondom length]/2);//
    int rLen = (int)[rondom length]/2;
    [m_vcom TransPinEnc:pin pinLen:(int)[encString length]/2 ramdom:rom ramLen:rLen tiemOut:15];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //初始化对象
    m_vcom = [vcom getInstance];
    [m_vcom open];
    m_vcom.eventListener=self;
    [m_vcom setCommmunicatinMode:aiShua];
    [m_vcom setVloumn:95];
    [m_vcom setDebug:1];
    
    NSString *test = @"王国";
    
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData *data = [test dataUsingEncoding:enc];
    char ss[20];
    memset(ss,0,20);
    memcpy(ss,[data bytes],[data length]);
    
    //获取ksn
    self.getKsnBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.getKsnBtn setFrame:CGRectMake(14, 70, 58, 28)];
    [self.getKsnBtn setTitle:@"KSN" forState:UIControlStateNormal];
    [self.getKsnBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    self.getKsnBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [self.getKsnBtn addTarget:self action:@selector(getKsnData) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.getKsnBtn];
    //刷卡按钮
    self.swipeCardBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.swipeCardBtn setFrame:CGRectMake(98, 70, 58, 28)];
    [self.swipeCardBtn setTitle:@"刷卡" forState:UIControlStateNormal];
    [self.swipeCardBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    [self.swipeCardBtn setBackgroundColor:[UIColor clearColor]];
    self.swipeCardBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [self.swipeCardBtn addTarget:self action:@selector(swipeCardAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.swipeCardBtn];
    //ic刷卡按钮
    icBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [icBtn setFrame:CGRectMake(178, 70, 58, 28)];
    [icBtn setTitle:@"ic刷卡" forState:UIControlStateNormal];
    [icBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    [icBtn setBackgroundColor:[UIColor clearColor]];
    icBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [icBtn addTarget:self action:@selector(swipeICCardAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:icBtn];
    
    
    //停止按钮
    self.stopBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.stopBtn setFrame:CGRectMake(252, 70, 58, 28)];
    [self.stopBtn setTitle:@"停止" forState:UIControlStateNormal];
    [self.stopBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    [self.stopBtn setBackgroundColor:[UIColor clearColor]];
    self.stopBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [self.stopBtn addTarget:self action:@selector(stopAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.stopBtn];
    
    //设置控制字bit0 0/1 表示随机由爱刷产生/由双方产生
    QCheckBox *_check1 = [[QCheckBox alloc] initWithDelegate:self];
    _check1.frame = CGRectMake(20, 95, 80, 40);
    [_check1 setTitle:@"随机数" forState:UIControlStateNormal];
    [_check1 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_check1.titleLabel setFont:[UIFont boldSystemFontOfSize:13.0f]];
    [self.view addSubview:_check1];
    [_check1 setChecked:NO];
    [_check1 release];
    
    //设置控制字bit1 0/1 表示终端需要不上送/上送mac
    QCheckBox *_check2 = [[QCheckBox alloc] initWithDelegate:self];
    _check2.frame = CGRectMake(80, 95, 80, 40);
    [_check2 setTitle:@"上送MAC" forState:UIControlStateNormal];
    [_check2 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_check2.titleLabel setFont:[UIFont boldSystemFontOfSize:13.0f]];
    [self.view addSubview:_check2];
    [_check2 setChecked:NO];
    [_check2 release];
    
    //设置控制字bit2 0/1 表示终端上送的卡号不屏蔽/屏蔽
    QCheckBox *_check3 = [[QCheckBox alloc] initWithDelegate:self];
    _check3.frame = CGRectMake(155, 95, 80, 40);
    [_check3 setTitle:@"屏蔽卡号" forState:UIControlStateNormal];
    [_check3 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_check3.titleLabel setFont:[UIFont boldSystemFontOfSize:13.0f]];
    [self.view addSubview:_check3];
    [_check3 setChecked:NO];
    [_check3 release];
    
    //设置控制字bit3 0/1 表示终端不上送/上送磁道的原始长度
    QCheckBox *_check4 = [[QCheckBox alloc] initWithDelegate:self];
    _check4.frame = CGRectMake(230, 95, 120, 40);
    [_check4 setTitle:@"上送磁道" forState:UIControlStateNormal];
    [_check4 setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_check4.titleLabel setFont:[UIFont boldSystemFontOfSize:13.0f]];
    [self.view addSubview:_check4];
    [_check4 setChecked:YES];
    [_check4 release];
    
    //获取终端类型
    kindBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [kindBtn setFrame:CGRectMake(14, 140, 100, 28)];
    [kindBtn setTitle:@"获取终端类型" forState:UIControlStateNormal];
    [kindBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    //    [self.getKsnBtn setBackgroundColor:[UIColor clearColor]];
    kindBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [kindBtn addTarget:self action:@selector(getDeviceKind) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:kindBtn];
    
//    //更新主秘钥
//    UIButton *mainKeyBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//    [mainKeyBtn setFrame:CGRectMake(14, 140+40, 100, 28)];
//    [mainKeyBtn setTitle:@"更新主秘钥" forState:UIControlStateNormal];
//    [mainKeyBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
//    //    [self.getKsnBtn setBackgroundColor:[UIColor clearColor]];
//    mainKeyBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
//    [mainKeyBtn addTarget:self action:@selector(updateMainkey) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:mainKeyBtn];
    
    //参数下载
    paramBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [paramBtn setFrame:CGRectMake(14+110, 140, 80, 28)];
    [paramBtn setTitle:@"参数下载" forState:UIControlStateNormal];
    [paramBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    //    [self.getKsnBtn setBackgroundColor:[UIColor clearColor]];
    paramBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [paramBtn addTarget:self action:@selector(loadParam) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:paramBtn];
    //Ic卡交易脚本回写
    secondIssBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [secondIssBtn setFrame:CGRectMake(14+110+90, 140, 100, 28)];
    [secondIssBtn setTitle:@"IC卡脚本回写" forState:UIControlStateNormal];
    [secondIssBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    secondIssBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [secondIssBtn addTarget:self action:@selector(secondIssBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:secondIssBtn];
    
    
    
    
    UIButton *initBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [initBtn setFrame:CGRectMake(14, HIGHT-60, 78, 28)];
    [initBtn setTitle:@"初始化应用" forState:UIControlStateNormal];
    [initBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    initBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [initBtn addTarget:self action:@selector(initClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:initBtn];
    
    UIButton *encBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [encBtn setFrame:CGRectMake(14+78+4, HIGHT-60, 68, 28)];
    [encBtn setTitle:@"Des加密" forState:UIControlStateNormal];
    [encBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    encBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [encBtn addTarget:self action:@selector(encClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:encBtn];
    
    UIButton *desBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [desBtn setFrame:CGRectMake(14+78+4+68+4, HIGHT-60, 68, 28)];
    [desBtn setTitle:@"Des解密" forState:UIControlStateNormal];
    [desBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    desBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [desBtn addTarget:self action:@selector(desClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:desBtn];
    
    UIButton *cardNoBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [cardNoBtn setFrame:CGRectMake(14+68+4+78+4+68+4, HIGHT-60, 68, 28)];
    [cardNoBtn setTitle:@"获取卡号" forState:UIControlStateNormal];
    [cardNoBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    cardNoBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [cardNoBtn addTarget:self action:@selector(cardNoClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:cardNoBtn];
    
    UIButton *TrackExBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [TrackExBtn setFrame:CGRectMake(14, HIGHT-60+32, 108, 28)];
    [TrackExBtn setTitle:@"更新工作秘钥" forState:UIControlStateNormal];
    [TrackExBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    TrackExBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [TrackExBtn addTarget:self action:@selector(updataWorkKey) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:TrackExBtn];
    
    
    UIButton *macBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [macBtn setFrame:CGRectMake(14+88, HIGHT-60+32, 108, 28)];
    [macBtn setTitle:@"获取mac" forState:UIControlStateNormal];
    [macBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    macBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [macBtn addTarget:self action:@selector(macBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:macBtn];
    
    UIButton *pinBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [pinBtn setFrame:CGRectMake(14+108+88, HIGHT-60+32, 88, 28)];
    [pinBtn setTitle:@"获取Pin" forState:UIControlStateNormal];
    [pinBtn setBackgroundImage:[UIImage imageNamed:@"btn_press_ksn.png"] forState:UIControlStateNormal];
    pinBtn.titleLabel.font = [UIFont boldSystemFontOfSize:15.0f];
    [pinBtn addTarget:self action:@selector(pinBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:pinBtn];
    
    
    self.cardInfoView = [[UITextView alloc] initWithFrame:CGRectMake(10, 190+40, 300, 280-40)];
    _cardInfoView.textColor = [UIColor blackColor];
    _cardInfoView.font = [UIFont fontWithName:@"Arial" size:12.0f];
    _cardInfoView.delegate = self;
    _cardInfoView.backgroundColor = [UIColor whiteColor];
    _cardInfoView.text = text;
    _cardInfoView.returnKeyType = UIReturnKeyDefault;//返回键的类型
    _cardInfoView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.cardInfoView];
    
    if ([self hasHeadset])
    {
        self.cardInfoView.text = @"耳机插入";
        
    }
    else
    {
        self.cardInfoView.text = @"耳机未插入";
    }
    
    //点击空白处，键盘下落
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyBoarddown:)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
    
}
- (void)updateMainkey
{
    //更新主秘钥
    NSString *str = @"11111111111111111111111111111111";
    char *tempStr = HexToBin((char *)[str UTF8String]);
    int mLen = (int)[str length]/2;
    char data[mLen];
    memcpy(data, tempStr, mLen);
    [m_vcom Request_ReNewTMK3:data dataLen:mLen time:10];
    [m_vcom StartRec];
    
    //    4ecd57b64ed27bc54ed27c2b4ed6a11e
    //主密钥明文：9f517c31ed08a1f69f517c31ed08a1f6，工作秘钥密文：f83035fb98a48243f83035fb98a4824382e13665,校验位：82e13665
}
- (void)macBtnClick
{
    NSString *str = @"3230313530383236313732393336203335343945353939353134313435433239373845414234434533423635384445203233454434354542323936374535414120334534323636354145363937383831432042454433373730464230373532353745394630343335463939383737443235322038434439354231434144344638353445203335393344353535363334423141314230343046443437323739363044333846333237443632464543333341433330462033324232364631343341353830414144413939324643423243353146344635433642204144434535443143393134353130363130313030203839434336334530313837324535434320303038203946313031333037303030313033413030303032303130413031303030303035323030303436384530394439394633373034433546433435314139463236303833323945434541443836364141354542394631413032303135363943303130303546324130323031353639463431303430303033333230343946303930323030303139463335303132313946303230363030303030303030303030313946333330333630463843383935303530303830303030383030394632373031383039463336303230394635394630333036303030303030303030303030394631453038333133323333333433353336333733383832303237433030394633343033314530333030394130333135303832363834303841303030303030333333303130313036800000008000000000000000";
    
    //    str = @"20150907115136 F88FA7642C932A77F0C2FB854419C90B CB63EF831577A7D3 7F047BCCCCBB7DBE 36AA9B2631547BCA1BA04B76F1D23000 28B2E5E4E41C1109 FFECE5E7EA4F72DB85CD0820F995D00D639DD3F005C16A52 32DCEEAE1BB08439E45CC355C122D67527 ADCE5D1C914510610100 59770BA6DB4FF171 008 9F330360F8C89F2701809C01009F360202F79F03060000000000009F1E083132333435363738950500800008009F34031E03009F101307000103A00002010A0100000010005DB0E0CC9F37048E7F46BF9F26086A9054F588F522AA9F1A0201565F2A02015682027C009F090200019F3501219F4104000332049A031509079F02060000000000018408A000000333010106";
    
    str  = @"1234567890";
    char * temp=HexToBin((char *)[str UTF8String]);
    int datalen = (int)[str length]/2;
    char data[datalen];
    memcpy(data, temp, datalen);
    NSLog(@"mac数据：%@",[m_vcom HexValue:data  Len:datalen]);
    NSString *dateString = @"20150826172936";
    //    dateString = @"20150907115136";
    char * temp1=HexToBin((char *)[dateString UTF8String]);
    int datalen1 = (int)[dateString length]/2;
    char oData[datalen1];
    
    memcpy(oData, temp1, datalen1);
    //    [m_vcom Request_GetMac2:1 mode:0 keyIndex:1 random:"" randomLen:0 otherData:oData oDataLen:datalen1 data:data dataLen:datalen];
    [m_vcom Request_GetMac1:1 keyIndex:0 random:"" randomLen:0 otherData:"" oDataLen:0 data:data dataLen:datalen];
    [m_vcom StartRec];
}
- (void)pinBtnClick
{
    //
    NSString *string = @"06122456FEFFFFF7";
    char *dd  = HexToBin((char*)[string UTF8String]);
    int datalen = (int)string.length/2;
    char data[datalen];
    memcpy(data, dd, datalen);
    
    NSString *timeString = @"20150906231434";
    char *cc = HexToBin((char *)[timeString UTF8String]);
    int romLen = (int)timeString.length/2;
    char rom[romLen];
    memcpy(rom, cc, romLen);
    
    [m_vcom TransPinEnc:data pinLen:datalen ramdom:rom ramLen:romLen tiemOut:10];
    [m_vcom StartRec];
    [m_vcom close];
}
- (void)keyBoarddown:(id)obj
{
    [self.cardInfoView resignFirstResponder];
}
-(void)viewDidUnload
{
    [super viewDidUnload];
    NSLog(@"viewDidDisappear 释放资源");
    m_vcom.eventListener=nil;
    [m_vcom close];
    m_vcom =nil;
}
- (void)encClick
{   //
    NSString *string = @"12345678901234567890";
    char *dd  = HexToBin((char*)[string UTF8String]);
    int datalen = (int)string.length/2;
    char data[datalen];
    memcpy(data, dd, datalen);
    
    
    NSString *timeString = @"20150906231434";
    char *cc = HexToBin((char *)[timeString UTF8String]);
    int romLen = (int)timeString.length/2;
    char rom[romLen];
    memcpy(rom, cc, romLen);
    [m_vcom Request_DESEnc:0 pinIndex:0 random:rom randomLen:romLen data:data dataLen:datalen timeOut:15];
    [m_vcom StartRec];
}
- (void)desClick
{
    NSString *str = @"65cc0e12b838e7c2";
    char *temp = HexToBin((char *)[str UTF8String]);
    char data[100];
    int len = (int)[str length]/2;
    memcpy(data, temp, [str length]/2);
    
    NSString *timeString = @"20150906231434";
    char *cc = HexToBin((char *)[timeString UTF8String]);
    int romLen = (int)timeString.length/2;
    char rom[romLen];
    memcpy(rom, cc, romLen);
    
    [m_vcom Request_DESDec:0 pinIndex:0 random:rom randomLen:romLen data:data dataLen:len timeOut:15];
    [m_vcom StartRec];
}
- (void)initClick
{
    [m_vcom Request_InitApp];
    [m_vcom StartRec];
}
- (void)cardNoClick
{
    [m_vcom request_cardNo];
    [m_vcom StartRec];
}
//更新工作秘钥
- (void)updataWorkKey
{
    NSString *workKey = @"f83035fb98a48243f83035fb98a4824382e13665";
    //瀚银版本这里的数据：秘钥类型+秘钥长度+数据，比如秘钥类型13，长度10，则：1210010203040506070809
    NSString *pinKey = workKey;
    NSString *macKey = workKey;
    NSString *desKey = workKey;
    char pin[100],mac[100],des[100];
    pin[0]=0;
    mac[0]=0;
    des[0]=0;
    char *tempPin = HexToBin((char*)[pinKey UTF8String]);
    memcpy(pin, tempPin, [pinKey length]/2);
    int len =(int)[pinKey length]/2;
    char *tempMac = HexToBin((char*)[macKey UTF8String]);
    memcpy(mac, tempMac, [macKey length]/2);
    char *tempDes = HexToBin((char*)[macKey UTF8String]);
    memcpy(des, tempDes, [desKey length]/2);
    [m_vcom Request_ReNewKey:0 PinKey:pin PinKeyLen:len
                      MacKey:mac MacKeyLen:len
                      DesKey:des DesKeyLen:len];
    [m_vcom StartRec];
}
//初始化完成
- (void)initComplete
{
    NSLog(@"initComplete");
}
//des加密完成
- (void)desEncComplete:(NSString *)string
{
    NSLog(@"desEncComplete:%@",string);
    //    [self performSelectorInBackground:@selector(test:) withObject:string];
    
}
//des解密完成
- (void)desDecComplete:(NSString *)string
{
    NSLog(@"desDecComplete:%@",string);
    //8475f1070ab2033abf7923c90c8a545d6356498194e204cf1 03a0000
}
//pin转加密完成
- (void)tranPinComplete:(NSString *)string
{
    NSLog(@"tranPinComplete:%@",string);
    
}
-(void)switchAction:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    BOOL isButtonOn = [switchButton isOn];
    if (isButtonOn) {
        readOldFileForiTronDevice = YES;
    }else {
        readOldFileForiTronDevice = NO;
    }
}
//获取设备类型
- (void)getDeviceKind
{
    [m_vcom StopRec];
    [m_vcom getTerminalType];
    [m_vcom StartRec];
    
}
//参数下载
- (void)loadParam
{
    paramBtn.userInteractionEnabled = NO;
    pageNum = 0;
    self.cardInfoView.text = @"参数下载";
    //    公钥下载
    NSString *str = @"319F0605A0000000049F220106DF05083230323331323331DF060101DF070101DF0281F8CB26FC830B43785B2BCE37C81ED334622F9622F4C89AAE641046B2353433883F307FB7C974162DA72F7A4EC75D9D657336865B8D3023D3D645667625C9A07A6B7A137CF0C64198AE38FC238006FB2603F41F4F3BB9DA1347270F2F5D8C606E420958C5F7D50A71DE30142F70DE468889B5E3A08695B938A50FC980393A9CBCE44AD2D64F630BB33AD3F5F5FD495D31F37818C1D94071342E07F1BEC2194F6035BA5DED3936500EB82DFDA6E8AFB655B1EF3D0D7EBF86B66DD9F29F6B1D324FE8B26CE38AB2013DD13F611E7A594D675C4432350EA244CC34F3873";
    NSString *str1 = @"319F0608A000000333010102DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
    char * temp=HexToBin((char *)[str1 UTF8String]);
    int datalen = (int)[str1 length]/2;
    char data[datalen];
    memcpy(data, temp, datalen);
    [m_vcom StopRec];
    
    [m_vcom UpdateTerminalParameters:1 pageNum:pageNum++ data:data dataLen:datalen time:6];
    [m_vcom StartRec];
    
    
}
//IC卡脚本回写
- (void)secondIssBtnClick
{
    secondIssBtn.userInteractionEnabled = NO;
    self.cardInfoView.text = @"IC卡脚本回写";
    //    NSString *str =@"9F2608BEC5FDD8569CED7C9F2701809F101307020103A02002010A010000000000424E87069F37044C24C2199F360200149505000004E8009A031409189C01009F02060000000060005F2A02015682027C009F1A0201569F03060000000000009F3303E0E1C89F34034203009F3501229F1E0830303030303030318408A0000003330101029F090200209F4104000000029F631030313035303030300000000000000000";
    NSString *str =@"";
    char * temp=HexToBin((char *)[str UTF8String]);
    int datalen = [str length]/2;
    char data[datalen];
    memcpy(data, temp, datalen);
    
    NSString *resCode = @"00";
    char * temp1=(char *)[resCode UTF8String];
    int datalen1 = (int)[resCode length];
    char resData[datalen1];
    memcpy(resData, temp1, datalen1);
    
    [m_vcom StopRec];
    //    [m_vcom secondIssuance:data dataLength:datalen time:10];
    [m_vcom secondIssuance:resData data:data dataLength:datalen time:60];
    [m_vcom StartRec];
    
}
- (void)swipeICCardAction
{
    [m_vcom StopRec];
    
    icBtn.userInteractionEnabled = NO;
    self.cardInfoView.text = @"ic卡刷";
    //ic卡刷卡命令
    
    NSString *str = @"123456";
    char *temp = HexToBin((char *)[str UTF8String]);
    char rom[100];
    memcpy(rom, temp, [str length]/2);//一定要拷贝否则会占用通一块内存
    
    
    NSString *appendData = @"49900003200015141399";
    char *temp1 = HexToBin((char*)[appendData UTF8String]);
    char appendDataChar[100];
    memcpy(appendDataChar, temp1, [appendData length]/2);//一定要拷贝否则会占用通一块内存
    int appendlen =(int)[appendData length]/2;
    
    NSString *cash = @"100";
    int cashLen = [cash length];
    char cData[100];
    cData[0] = 0;
    strcpy(cData,((char*)[cash UTF8String]));
    
    Transactioninfo *tranInfo = [[Transactioninfo alloc] init];
    //    it6=0/1 55域数据是否加密1011
    //    NSString *ctrm = @"C33B7700";//银嘉
    NSString *ctrm = @"93030000";
    //    NSString *ctrm = @"5b600000";
    char *temp2 = HexToBin((char*)[ctrm UTF8String]);
    char ctr[4];
    memcpy(ctr, temp2, [ctrm length]/2);
    [m_vcom setCustomer:36];
    [m_vcom stat_EmvSwiper:0 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:ctr ParameterRandom:"" ParameterRandomLen:0 cash:cData cashLen:cashLen appendData:"" appendDataLen:0 time:30 Transactioninfo:tranInfo];
    [m_vcom StartRec];
    
}
//下发KSN命令获取KSN返回数据
- (void)getKsnData
{
    self.cardInfoView.text = @"获取ksn";
    [self.getKsnBtn setUserInteractionEnabled:NO];
    [self.getKsnBtn setEnabled:NO];
    
    //    if (![self hasHeadset])
    //    {
    //        UIAlertView *NotifyAlertView;
    //        NotifyAlertView = [[UIAlertView alloc] initWithTitle:@"检查设备"
    //                                                     message:@"检查设备是否就位."
    //                                                    delegate:NULL
    //                                           cancelButtonTitle:@"OK"
    //                                           otherButtonTitles:nil];
    //        [NotifyAlertView show];
    //        [NotifyAlertView release];
    //        [self.getKsnBtn setUserInteractionEnabled:YES];
    //        [self.getKsnBtn setEnabled:YES];
    //        return;
    //    }
    [m_vcom StopRec];
    [m_vcom Request_GetKsn];
    [m_vcom StartRec];
}
//显示KSN信息到TextView上
- (void)writeKsnDataToTextView
{
    char * retData = [m_vcom GetKsnRetData]; //alex
    //判断设备类型
    if((strcmp(retData, "\0")==0)||strncmp(retData, "00000000000000000000000000000000000000000000000000", 25)==0)
    {
        UIAlertView *NotifyAlertView;
        NotifyAlertView = [[UIAlertView alloc] initWithTitle:@"检查设备"
                                                     message:@"检查设备是否正确."
                                                    delegate:NULL
                                           cancelButtonTitle:@"OK"
                                           otherButtonTitles:nil];
        [NotifyAlertView show];
        [NotifyAlertView release];
        return;
    }
    
    NSString * retDataStr = [[NSString alloc] initWithUTF8String:retData];
    NSLog(@"retDataStr->%@",retDataStr);
    NSString * KsnDataStr = [retDataStr substringWithRange:NSMakeRange(18, 16)];
    NSString * VerDataStr = [retDataStr substringWithRange:NSMakeRange(34, 14)];
    NSString * retSDKVerson = [m_vcom GetSDKVerson];
    NSString * displayFormattedString = [[NSString alloc]initWithFormat: @" KSN:%@ \n VER:%@ \n SDKVer:%@",KsnDataStr,VerDataStr,retSDKVerson];
    self.cardInfoView.text = displayFormattedString;
    
    [retDataStr release];
    retDataStr=nil;
    [self.getKsnBtn setEnabled:YES];
    [self.getKsnBtn setUserInteractionEnabled:YES];
}
//下发刷卡命令，该命令属于连续操作命令，回调刷卡监听,同时要记录控制标志信息,来确定终端是否解析终端不上送/上送磁道的原始长度
- (void)swipeCardAction
{
    [self.swipeCardBtn setEnabled:NO];
    [m_vcom StopRec];
    [m_vcom setMode:VCOM_TYPE_F2F recvMode:VCOM_TYPE_F2F];
    int smode=(int)[m_vcom getSendMode];
    self.cardInfoView.text = @"";
    //刷卡
    NSString *param = @"135031116.359,39.9558";
    char appdata[100];
    appdata[0] = 0;
    int appDataLen = (int)[param length]/2;
    strcpy(appdata,((char*)[param UTF8String]));
    NSLog(@"appdata is %s",appdata);
    
    
    NSString *str = @"123456";
    char *temp = HexToBin((char *)[str UTF8String]);
    char rom[100];
    memcpy(rom, temp, [str length]/2);//一定要拷贝否则会占用通一块内存
    
    
    NSString *ss = @"010203040506";
    int len = [ss length]/2;
    char *data = HexToBin((char *)[ss UTF8String]);
    char aData[100];
    memcpy(aData, data, len);
    NSLog(@"%x", ctrlFlag);
    //    ctrlFlag = 0b00001011;
    //    NSLog(@"%x", ctrlFlag);
    //    ctrlFlag = 0x0b;
    //    NSLog(@"%x", ctrlFlag);
    //    ctrlFlag = ctrlFlag<<4;
    //    NSLog(@"%02x", ctrlFlag);
    //公钥信息修复
    //    [m_vcom publickeyRepair];
    [m_vcom startDetector:ctrlFlag random:"123" randomLen:3 data:"" datalen:0 time:15];
    [m_vcom StartRec];
    
}

- (void)stopAction
{
    [m_vcom Request_Exit];
    self.cardInfoView.text = @"停止";
    [self.swipeCardBtn setEnabled:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/***********************************************
 消息通知函数
 ***********************************************/

//通知监听器刷卡器插入手机
-(void) onDevicePlugged
{
    self.cardInfoView.text =@"耳机插入";
    NSLog(@"耳机插入");
    
}


//通知监听器刷卡器已从手机拔出
-(void) onDeviceUnPlugged
{
    self.cardInfoView.text=@"耳机拔出";
    NSLog(@"耳机拔出");
}

- (void)onError:(int)errorCode ErrorMessage:(NSString *)errorMessage;
{
    NSLog(@"errorMessage==%@", errorMessage);
    
    if (errorCode == ERROR_FAIL_TO_GET_KSN) {
        NSLog(@"获取ksn失败");
        [self performSelectorOnMainThread:@selector(updateText:) withObject:@"获取ksn失败" waitUntilDone:YES];
    }
    else{
        [self performSelectorOnMainThread:@selector(updateText:) withObject:errorMessage waitUntilDone:YES];
    }
    
    
}

//检查micphone状态
- (BOOL)hasHeadset
{
#if TARGET_IPHONE_SIMULATOR
#warning *** Simulator mode: audio session code works only on a device
    return NO;
#else
    CFStringRef route;
    UInt32 propertySize = sizeof(CFStringRef);
    AudioSessionGetProperty(kAudioSessionProperty_AudioRoute, &propertySize, &route);
    if((route == NULL) || (CFStringGetLength(route) == 0))
    {
        
    }
    else
    {
        NSString* routeStr = (NSString*)route;
        NSRange headphoneRange = [routeStr rangeOfString : @"Headphone"];
        NSRange headsetRange = [routeStr rangeOfString : @"Headset"];
        if (headphoneRange.location != NSNotFound)
        {
            return YES;
        } else if(headsetRange.location != NSNotFound)
        {
            return YES;
        }
    }
    return NO;
#endif
}

//通知监听器控制器CSwiperController正在搜索刷卡器
-(void) onWaitingForDevice
{
    
}

//通知监听器没有刷卡器硬件设备
-(void)onNoDeviceDetected
{
    
}

//通知监听器可以进行刷卡动作
-(void)onWaitingForCardSwipeForAiShua
{
    [self performSelectorOnMainThread:@selector(refreshSwipeAction) withObject:nil waitUntilDone:NO];
    
}

//解析艾刷返回的数据信息的实现
-(void)secondReturnDataFromAiShua
{
    
}

-(void)refreshSwipeAction
{
    self.cardInfoView.text = @"请刷卡！";
    
    //    timer = [NSTimer scheduledTimerWithTimeInterval:6.0 target:self
    //                                           selector:@selector(writeCardDataToTextView) userInfo:nil repeats:NO];
}

/**
 *	@注释  通知电话中断结束设备准备好了
 */
-(void)onDeviceReady
{
    NSLog(@"onDeviceReady0");
}

-(void)writeCardDataToTextView
{
    int retCmdResultLoc,retCmdResult,retDataLen,retDataLoc,encTrack1Loc,encTrack1Len,encTrack2Loc,encTrack2Len,encTrack3Loc,encTrack3Len,randomLoc,randomLen,KsnNumLoc,KsnNumLen,CardNumLoc,CardNumLen,Track1Loc,Track1Len,Track2Loc,Track2Len,Track3Loc,Track3Len,encTracksLoc,randomNumberLoc,MaskedPanLoc,TrackOriginalLen,TrackOriginalLoc,expireDateLoc;
    int stepLen = 2;
    NSString *KSN,*encTracks,*randomNumber,*maskedPan,*expireDate;
    
    char * retData = [m_vcom GetKsnRetData]; //alex
    NSString *praserDataStr = [[NSString alloc] initWithUTF8String:retData];
    
    NSLog(@"praserDataStr %@",praserDataStr);
    
    retCmdResultLoc = 12;
    retCmdResult = strtoul([[praserDataStr substringWithRange:NSMakeRange(retCmdResultLoc, stepLen)]UTF8String],0,16);
    
    if (0 != retCmdResult)
    {
        switch (retCmdResult)
        {
            case 01:
                self.cardInfoView.text = @"命令执行超时，请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 10:
                self.cardInfoView.text = @"用户退出，请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 128:
                self.cardInfoView.text = @"数据接收正确但无解析,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 129:
                self.cardInfoView.text = @"磁道数据解析失败,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 130:
                self.cardInfoView.text = @"当前非刷卡状态,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 241:
                self.cardInfoView.text = @"不识别的主命令码,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 242:
                self.cardInfoView.text = @"不识别的子命令码,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 244:
                self.cardInfoView.text = @"随机数长度错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 247:
                self.cardInfoView.text = @"KSN错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 248:
                self.cardInfoView.text = @"更新KSN失败错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 249:
                self.cardInfoView.text = @"组包数据失败错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 250:
                self.cardInfoView.text = @"加密失败错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 251:
                self.cardInfoView.text = @"密钥更新失败错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 252:
                self.cardInfoView.text = @"数据域内容有误错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 253:
                self.cardInfoView.text = @"MAC_TK校验失败错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
                
            case 254:
                self.cardInfoView.text = @"校验和错误,请重新刷卡！";
                [self.swipeCardBtn setEnabled:YES];
                break;
            default:
                break;
        }
        
        return;
    }else
    {
        if (ctrlFlag >=0x08)
        {
            //解析带磁道原始长度
            //数据总长度
            retDataLoc = retCmdResultLoc + stepLen*2;
            retDataLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(retDataLoc, stepLen)]UTF8String],0,16);
            NSLog(@"retDataLen %d",retDataLen);
            
            //磁道1长度
            encTrack1Loc = retDataLoc + stepLen;
            encTrack1Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(encTrack1Loc, stepLen)]UTF8String],0,16);
            NSLog(@"encTrack1Len %d",encTrack1Len);
            
            //磁道2长度
            encTrack2Loc = encTrack1Loc + stepLen;
            encTrack2Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(encTrack2Loc, stepLen)]UTF8String],0,16);
            NSLog(@"encTrack2Len %d",encTrack2Len);
            
            //磁道3长度
            encTrack3Loc = encTrack2Loc + stepLen;
            encTrack3Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(encTrack3Loc, stepLen)]UTF8String],0,16);
            NSLog(@"encTrack3Len %d",encTrack3Len);
            
            //随机数长度
            randomLoc = encTrack3Loc + stepLen;
            randomLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(randomLoc, stepLen)]UTF8String],0,16);
            NSLog(@"randomLen %d",randomLen);
            
            //Ksn数长度
            KsnNumLoc = randomLoc + stepLen;
            KsnNumLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(KsnNumLoc, stepLen)]UTF8String],0,16);
            NSLog(@"KsnNumLen %d",KsnNumLen);
            
            //卡长度
            CardNumLoc = KsnNumLoc + stepLen;
            CardNumLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(CardNumLoc, stepLen)]UTF8String],0,16);
            NSLog(@"CardNumLen %d",CardNumLen);
            
            //原始磁道1长度
            Track1Loc = CardNumLoc + stepLen;
            Track1Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(Track1Loc, stepLen)]UTF8String],0,16);
            NSLog(@"Track1Len %d",Track1Len);
            
            //原始磁道2长度
            Track2Loc = Track1Loc + stepLen;
            Track2Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(Track2Loc, stepLen)]UTF8String],0,16);
            NSLog(@"Track2Len %d",Track2Len);
            
            //原始磁道3长度
            Track3Loc = Track2Loc + stepLen;
            Track3Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(Track3Loc, stepLen)]UTF8String],0,16);
            NSLog(@"Track3Len %d",Track3Len);
            
            encTracksLoc = Track3Loc + stepLen;
            encTracks = [praserDataStr substringWithRange:NSMakeRange(encTracksLoc,(encTrack1Len+encTrack2Len+encTrack3Len)*stepLen)];
            NSLog(@"encTracks %@",encTracks);
            
            randomNumberLoc = encTracksLoc + ((encTrack1Len + encTrack2Len + encTrack3Len)*2);
            randomNumber = [praserDataStr substringWithRange:NSMakeRange(randomNumberLoc, randomLen*stepLen)];
            NSLog(@"randomNumber %@",randomNumber);
            
            KsnNumLoc = randomNumberLoc + KsnNumLen*stepLen;
            KSN = [praserDataStr substringWithRange:NSMakeRange(KsnNumLoc, KsnNumLen*stepLen)];
            NSLog(@"KSN %@",KSN);
            
            MaskedPanLoc = KsnNumLoc + KsnNumLen*stepLen;
            maskedPan = [praserDataStr substringWithRange:NSMakeRange(MaskedPanLoc, CardNumLen*stepLen)];
            NSLog(@"maskedPan %@",maskedPan);
            
            expireDateLoc = MaskedPanLoc + CardNumLen*stepLen;
            expireDate = [praserDataStr substringWithRange:NSMakeRange(expireDateLoc, 8)];
            
            NSString * displayFormattedString = [[NSString alloc]initWithFormat: @" formatID:null \n ksn: %@ \n track1Length: %d \n track2Length: %d \n track3Length: %d \n encTracks: %@ \n randomNumber: %@ \n MaskedPan: %@ \n expiryDate: %@ \n cardHolerName: null",KSN,Track1Len,Track2Len,Track3Len,encTracks,randomNumber,maskedPan,expireDate];
            
            self.cardInfoView.text = displayFormattedString;
        }
        else
        {
            //解析不带磁道原始长度
            retDataLoc = retCmdResultLoc + stepLen*2;
            retDataLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(retDataLoc, stepLen)]UTF8String],0,16);
            NSLog(@"retDataLen %d",retDataLen);
            
            encTrack1Loc = retDataLoc + stepLen;
            encTrack1Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(encTrack1Loc, stepLen)]UTF8String],0,16);
            NSLog(@"encTrack1Len %d",encTrack1Len);
            
            encTrack2Loc = encTrack1Loc + stepLen;
            encTrack2Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(encTrack2Loc, stepLen)]UTF8String],0,16);
            NSLog(@"encTrack2Len %d",encTrack2Len);
            
            encTrack3Loc = encTrack2Loc + stepLen;
            encTrack3Len = strtoul([[praserDataStr substringWithRange:NSMakeRange(encTrack3Loc, stepLen)]UTF8String],0,16);
            NSLog(@"encTrack3Len %d",encTrack3Len);
            
            randomLoc = encTrack3Loc + stepLen;
            randomLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(randomLoc, stepLen)]UTF8String],0,16);
            NSLog(@"randomLen %d",randomLen);
            
            KsnNumLoc = randomLoc + stepLen;
            KsnNumLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(KsnNumLoc, stepLen)]UTF8String],0,16);
            NSLog(@"KsnNumLen %d",KsnNumLen);
            
            CardNumLoc = KsnNumLoc + stepLen;
            CardNumLen = strtoul([[praserDataStr substringWithRange:NSMakeRange(CardNumLoc, stepLen)]UTF8String],0,16);
            NSLog(@"CardNumLen %d",CardNumLen);
            
            encTracksLoc = CardNumLoc + stepLen;
            encTracks = [praserDataStr substringWithRange:NSMakeRange(encTracksLoc,(encTrack1Len+encTrack2Len+encTrack3Len)*stepLen)];
            NSLog(@"encTracks %@",encTracks);
            
            randomNumberLoc = encTracksLoc + ((encTrack1Len + encTrack2Len + encTrack3Len)*2);
            randomNumber = [praserDataStr substringWithRange:NSMakeRange(randomNumberLoc, randomLen*stepLen)];
            NSLog(@"randomNumber %@",randomNumber);
            
            KsnNumLoc = randomNumberLoc + KsnNumLen*stepLen;
            KSN = [praserDataStr substringWithRange:NSMakeRange(KsnNumLoc, KsnNumLen*stepLen)];
            NSLog(@"KSN %@",KSN);
            
            MaskedPanLoc = KsnNumLoc + KsnNumLen*stepLen;
            maskedPan = [praserDataStr substringWithRange:NSMakeRange(MaskedPanLoc, CardNumLen*stepLen)];
            NSLog(@"maskedPan %@",maskedPan);
            
            expireDateLoc = MaskedPanLoc + CardNumLen*stepLen;
            expireDate = [praserDataStr substringWithRange:NSMakeRange(expireDateLoc, 8)];
            NSLog(@"expireDate %@",expireDate);
            
            NSString * displayFormattedString = [[NSString alloc]initWithFormat: @" formatID:null \n ksn: %@ \n track1Length: %d \n track2Length: %d \n track3Length: %d \n encTracks: %@ \n randomNumber: %@ \n MaskedPan: %@ \n expiryDate: %@ \n cardHolerName: null",KSN,encTrack1Len,encTrack2Len,encTrack3Len,encTracks,randomNumber,maskedPan,expireDate];
            
            self.cardInfoView.text = displayFormattedString;
            
        }
    }
    [praserDataStr release];
    praserDataStr=nil;
    [self.swipeCardBtn setEnabled:YES];
}
// 通知监听器检测到刷卡动作
-(void)onCardSwipeDetected
{
    
}

//通知监听器开始解析或读取卡号、磁道等相关信息
-(void)onDecodingStart
{
    
}
//解析卡号、磁道信息等数据出错时，回调此接口
-(void)onDecodeDrror:(int)decodeResult
{
    NSLog(@"磁道数据解析失败");
    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"磁道数据解析失败" waitUntilDone:YES];
}
-(void)onError:(int)errorCode andMsg:(NSString*)errorMsg
{
    NSLog(@"error %@",errorMsg);
}

//通知监听器控制器CSwiperController的操作被中断
-(void)onInterrupted
{
    
}


//通知监听器控制器CSwiperController的操作超时
//(超出预定的操作时间，30秒)
-(void)onTimeout
{
    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"通讯超时" waitUntilDone:YES];
    NSLog(@"time out,通讯超时");
}

/*!
 @method
 @abstract 通知ksn
 @discussion 正常启动刷卡器后，将返回ksn
 @param ksn 取得的ksn
 */
- (void)onGetKsnCompleted:(NSString *)ksn
{
    NSString* string =[[NSString alloc] initWithFormat:@"ksn:%@ ",ksn];
    self.cardInfoView.text = string;
    [string release];
    [self.getKsnBtn setUserInteractionEnabled:YES];
    [self.getKsnBtn setEnabled:YES];
    
    //    [self swipeCardAction];
}
- (void)onGetKsnAndVersionCompleted:(NSArray *)ksnAndVerson
{
    NSLog(@"ksn is %@", [ksnAndVerson objectAtIndex:0]);
    NSLog(@"version is %@", [ksnAndVerson objectAtIndex:1]);
    
    NSString *ksn = [ksnAndVerson objectAtIndex:0];
    NSString *version = [ksnAndVerson objectAtIndex:1];
    self.cardInfoView.text = [NSString stringWithFormat:@"ksn=%@\n version=%@",ksn, version];
    [self.getKsnBtn setUserInteractionEnabled:YES];
    [self.getKsnBtn setEnabled:YES];
    
}
//收到数据
//len=-1，data=0表示接收的是错误的数据包
-(void) dataArrive:(vcom_Result*)vs Status:(int)_status
{
    
    [self.getKsnBtn setEnabled:YES];
    [self.swipeCardBtn setEnabled:YES];
    self.getKsnBtn.userInteractionEnabled = YES;
    self.swipeCardBtn.userInteractionEnabled = YES;
    paramBtn.userInteractionEnabled = YES;
    kindBtn.userInteractionEnabled =YES;
    icBtn.userInteractionEnabled = YES;
    secondIssBtn.userInteractionEnabled =YES;
    
    NSLog(@"dataArrive========================");
    [m_vcom StopRec];
    
    if(_status==-3){
        //设备没有响应
        NSLog(@"通信超时");
        self.cardInfoView.text = @"通信超时";
        
        return;
    }else if(_status == -2){
        //耳机没有插入
        return;
    }else if(_status==-1){
        //接收数据的格式错误
        return;
    }else {
        //操作指令正确
        if(vs->res==0){
            if(vs->rescode[0] == 0x09 && vs->rescode[1] == 0x07)
            {
                NSLog(@"命令已经停止");
            }
            //设备有成功返回指令
            [self.getKsnBtn setUserInteractionEnabled:YES];
            NSMutableString *strTemp = [[NSMutableString alloc] initWithCapacity:0];
            if (vs->ksnlen>0) {
                [strTemp appendString:[NSString stringWithFormat:@" KSN :%@",[m_vcom HexValue:vs->ksn  Len:vs->ksnlen]]];
            }
            
            [self performSelectorOnMainThread:@selector(updateText:) withObject:strTemp waitUntilDone:YES];
            NSLog(@"Aishua cmd exec ok\n");
        }else {
            
            switch (vs->res) {
                case 0x01:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"命令执行超时" waitUntilDone:YES];
                    break;
                case 0x0a:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"用户退出" waitUntilDone:YES];
                    break;
                case 0x80:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"数据接收正确" waitUntilDone:YES];
                    break;
                case 0x81:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"磁道数据解析失败" waitUntilDone:YES];
                    break;
                    
                case 0x82:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"当前非刷卡状态" waitUntilDone:YES];
                    break;
                case 0x83:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"磁道数据解析成功，返回当前的卡号" waitUntilDone:YES];
                    break;
                case 0xf1:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"不识别的主命令码" waitUntilDone:YES];
                    break;
                case 0xf2:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"不识别的子命令码" waitUntilDone:YES];
                    break;
                case 0xf4:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"随机数长度错误" waitUntilDone:YES];
                    break;
                case 0xf7:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"Ksn错误" waitUntilDone:YES];
                    break;
                case 0xf8:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"更新ksn失败" waitUntilDone:YES];
                    break;
                case 0xf9:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"组包数据失败" waitUntilDone:YES];
                    break;
                case 0xfa:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"加密失败" waitUntilDone:YES];
                    break;
                case 0xfb:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"密钥更新失败" waitUntilDone:YES];
                    break;
                case 0xfc:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"数据内容有误" waitUntilDone:YES];
                    break;
                case 0xfe:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"MAC_TK校验失败" waitUntilDone:YES];
                    break;
                case 0xff:
                    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"校验和错误" waitUntilDone:YES];
                    break;
                default:
                    break;
            }
            
            /* 失败和中间状态代码
             00	成功执行命令
             01	命令执行超时
             0A	用户退出
             80	数据接收正确
             81	磁道数据解析失败
             82	当前非刷卡状态(正常不会出现，可以不用理)
             83	磁道数据解析成功，返回当前的卡号
             F1	不识别的主命令码
             F2	不识别的子命令码
             F4	随机数长度错误
             F7	Ksn错误
             F8	更新ksn失败
             F9	组包数据失败
             FA	加密失败
             FB	密钥更新失败
             FC	数据域内容有误
             FE	MAC_TK校验失败
             FF	校验和错误
             */
        }
    }
}
- (void)updateText:(NSString *)str
{
    
    [_getKsnBtn setEnabled:YES];
    [self.swipeCardBtn setEnabled:YES];
    [_getKsnBtn setUserInteractionEnabled:YES];
    self.swipeCardBtn.userInteractionEnabled = YES;
    paramBtn.userInteractionEnabled = YES;
    kindBtn.userInteractionEnabled =YES;
    icBtn.userInteractionEnabled = YES;
    secondIssBtn.userInteractionEnabled =YES;
    
    
    
    self.cardInfoView.text = str;
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_RECORDDATA object:nil];
    [m_vcom release];
    [super dealloc];
}
-(void)viewDidDisappear:(BOOL)animated
{
    NSLog(@"viewDidDisappear 释放资源");
    m_vcom.eventListener=nil;
    [m_vcom close];
    m_vcom =nil;
    [super viewDidDisappear:YES];
    
}



//mic插入
-(void) onMicInOut:(int) inout
{
    
}

- (void) getPanCallback : (unsigned char)status pan:(unsigned char*)pan panLen:(unsigned char)panLen
{
    
}
- (void)onWaitingForCardSwipe
{
    NSLog(@"请刷卡");
    [self performSelectorOnMainThread:@selector(updateText:) withObject:@"请刷卡" waitUntilDone:YES];
}
#pragma mark - QCheckBoxDelegate
- (void)didSelectedCheckBox:(QCheckBox *)checkbox checked:(BOOL)checked
{
    NSLog(@"did tap on CheckBox:%@ checked:%d", checkbox.titleLabel.text, checked);
    
    if ([checkbox.titleLabel.text isEqualToString:@"随机数"])
    {
        if (checked) {
            ctrlFlag = ctrlFlag | 0x01;
            randLength = 4;//此处需要随机数长度
        }
        else
        {
            ctrlFlag = ctrlFlag & 0x0E;
            randLength = 0;
        }
    }
    
    if ([checkbox.titleLabel.text isEqualToString:@"上送MAC"])
    {
        if (checked) {
            ctrlFlag = ctrlFlag | 0x02;
        }
        else
        {
            ctrlFlag = ctrlFlag & 0x0D;
        }
    }
    
    if ([checkbox.titleLabel.text isEqualToString:@"屏蔽卡号"])
    {
        if (checked) {
            ctrlFlag = ctrlFlag | 0x04;
        }
        else
        {
            ctrlFlag = ctrlFlag & 0x0B;
        }
    }
    
    if ([checkbox.titleLabel.text isEqualToString:@"上送磁道"])
    {
        if (checked) {
            ctrlFlag = ctrlFlag | 0x08;
        }
        else
        {
            ctrlFlag = ctrlFlag & 0x07;
        }
    }
}

//IC卡回写脚本执行返回结果
- (void)onICResponse:(int)result resScript:(NSString *)resuiltScript data:(NSString *)data
{
    NSLog(@"result = %d ,resScript = %@, data = %@", result, resuiltScript, data);
    self.cardInfoView.text = [NSString stringWithFormat:@"IC卡回写脚本执行返回结果:%d,脚本：%@，数据：%@",result, resuiltScript, data];
    secondIssBtn.userInteractionEnabled = YES;
}
//设备类型回调
- (void)onDeviceKind:(int) result
{
    kindBtn.userInteractionEnabled = YES;
    NSLog(@"设备类型 ： %d", result);
    self.cardInfoView.text =[NSString stringWithFormat:@"设备类型:%d",result];
    //    [self performSelectorInBackground:@selector(getDeviceKind) withObject:nil];
    
    
}
- (void)getKsn{
    
    [m_vcom Request_GetKsn];
    [m_vcom StartRec];
}
- (void)mytest
{
    //    [m_vcom Request_GetKsn];
    //    [m_vcom StartRec];
    
    [self performSelectorInBackground:@selector(getDeviceKind) withObject:nil];
    
}
// 中间状态
- (void)EmvOperationWaitiing
{
    NSString *string = @"插入了IC卡，不要拔出IC卡";
    self.cardInfoView.text =string;
    NSLog(@"EmvOperationWaitiing");
}
//参数下载回调
- (void)onLoadParam:(NSString *)param
{
    paramBtn.userInteractionEnabled = YES;
    self.cardInfoView.text =[NSString stringWithFormat:@"第%d包数下载成功",pageNum];
    
    [self performSelectorInBackground:@selector(sendParm) withObject:nil];
    
    
}
- (void)sendParm
{
    if(pageNum == 4)
    {
        return;
    }
    paramBtn.userInteractionEnabled = NO;
    NSString *str = nil;
    NSString *str1 = nil;
    if(pageNum ==1){
        str = @"319f0605a0000003339f220104df050420241231df060101df070101df0281f8bc853e6b5365e89e7ee9317c94b02d0abb0dbd91c05a224a2554aa29ed9fcb9d86eb9ccbb322a57811f86188aac7351c72bd9ef196c5a01acef7a4eb0d2ad63d9e6ac2e7836547cb1595c68bcbafd0f6728760f3a7ca7b97301b7e0220184efc4f653008d93ce098c0d93b45201096d1adff4cf1f9fc02af759da27cd6dfd6d789b099f16f378b6100334e63f3d35f3251a5ec78693731f5233519cdb380f5ab8c0f02728e91d469abd0eae0d93b1cc66ce127b29c7d77441a49d09fca5d6d9762fc74c31bb506c8bae3c79ad6c2578775b95956b5370d1d0519e37906b384736233251e8f09ad79dfbe2c6abfadac8e4d8624318c27daf1df040103df0314f527081cf371dd7e1fd4fa414a665036e0f5e6e5";
        str1 = @"319F0608A000000333010103DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
    }
    if(pageNum==2){
        str = @"319F0605A0000003339F220102DF050420211231DF060101DF070101DF028190A3767ABD1B6AA69D7F3FBF28C092DE9ED1E658BA5F0909AF7A1CCD907373B7210FDEB16287BA8E78E1529F443976FD27F991EC67D95E5F4E96B127CAB2396A94D6E45CDA44CA4C4867570D6B07542F8D4BF9FF97975DB9891515E66F525D2B3CBEB6D662BFB6C3F338E93B02142BFC44173A3764C56AADD202075B26DC2F9F7D7AE74BD7D00FD05EE430032663D27A57DF040103DF031403BB335A8549A03B87AB089D006F60852E4B8060";
        str1 = @"319F0608A000000333010101DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
        
    }
    if (pageNum == 3) {
        str1 = @"319F0608A000000333010106DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160120DF170110DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
    }
    
    char * temp=HexToBin((char *)[str1 UTF8String]);
    int datalen = (int)[str1 length]/2;
    char data[datalen];
    memcpy(data, temp, datalen);
    //    [m_vcom StopRec];
    [m_vcom UpdateTerminalParameters:1 pageNum:pageNum++ data:data dataLen:datalen time:6];
    [m_vcom StartRec];
    
}
//ic卡刷卡器回调。
-(void)onDecodeCompleted:(NSString*) formatID
                  andKsn:(NSString*) ksn
            andencTracks:(NSString*) encTracks
         andTrack1Length:(int) track1Length
         andTrack2Length:(int) track2Length
         andTrack3Length:(int) track3Length
         andRandomNumber:(NSString*) randomNumber
           andCardNumber:(NSString *)maskedPAN
                  andPAN:(NSString*) pan
           andExpiryDate:(NSString*) expiryDate
       andCardHolderName:(NSString*) cardHolderName
                  andMac:(NSString *)mac
        andQTPlayReadBuf:(NSString*) readBuf
                cardType:(int)type
              cardserial:(NSString *)serialNum
             emvDataInfo:(NSString *)data55
                 cvmData:(NSString *)cvm;


{
    icBtn.userInteractionEnabled = YES;
    NSLog(@"回调函数接受返回数据");
    NSLog(@"ksn %@" ,ksn);
    NSLog(@"encTracks %@" ,encTracks);
    NSLog(@"track1Length %i",track1Length);
    NSLog(@"track2Length %i",track2Length);
    NSLog(@"track3Length %i",track3Length);
    NSLog(@"randomNumber %@",randomNumber);
    NSLog(@"maskedPAN %@",maskedPAN);
    NSLog(@"expiryDate %@",expiryDate);
    NSString* string =[[NSString alloc] initWithFormat:@"ksn:%@\n encTracks:%@ \n track1Length:%i \n track2Length:%i \n track3Length:%i \n randomNumber:%@ \n cardNum:%@ \n PAN:%@ \n expiryDate:%@ \n cardHolderName:%@ \n mac:%@ \n cardType:%d \n cardSerial:%@ \n emvDataInfo:%@ \n cmv:%@  \n readBuf:%@",ksn,encTracks,track1Length,track2Length,track3Length,randomNumber, maskedPAN,pan,expiryDate,cardHolderName,mac,type,serialNum,data55,cvm,readBuf];
    NSLog(@"%@",string);
    self.cardInfoView.text =string;
    self.cardInfoView.userInteractionEnabled = YES;
    [string release];
    [self.swipeCardBtn setEnabled:YES];
}
- (void)didfinishICUpdate{
    
    _swipeCardBtn.userInteractionEnabled = YES;
    _swipeCardBtn.enabled = YES;
    NSLog(@"公钥修复完成！");
}

@end
