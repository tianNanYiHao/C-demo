
//
//  SignViewController.h : interface for the vcom class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignViewController : UIViewController<UIImagePickerControllerDelegate>

@property (retain, nonatomic) IBOutlet UIImageView *imageView;
@end
