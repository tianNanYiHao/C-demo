//
//  BTViewController.h
//  StaticLibSDKDemo
//
//  Created by hezewen on 14-5-27.
//
//

#import <UIKit/UIKit.h>
#import "CommunicationCallBack.h"
#import "ItronCommunicationManagerBase.h"


@interface BTViewController : UIViewController<CommunicationCallBack,DeviceSearchListener,UIPickerViewDataSource,UIPickerViewDelegate,UITableViewDataSource,UITableViewDelegate,UITextViewDelegate>
{
    ItronCommunicationManagerBase *cmManager;
    UIPickerView *pkView;
    char *myRandom;
    int myRandomLen;
}
@end
