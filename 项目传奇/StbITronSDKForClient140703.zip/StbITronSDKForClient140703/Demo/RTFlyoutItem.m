//
//  RTFlyoutItem.m : implementation of the FlyoutItem class..
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import "RTFlyoutItem.h"

@implementation RTFlyoutItem


@end
