//
//  BTViewController.m
//  StaticLibSDKDemo
//
//  Created by hezewen on 14-5-27.
//
//

#import "BTViewController.h"

#define HEIGHT   [[UIScreen mainScreen] applicationFrame].size.height


@interface BTViewController ()
{
    NSArray *commandDataArr;
    UITableView * myTable;
    NSMutableArray *deviceArr;
    UITextView * myTXTView;
    UILabel *lab;
    UILabel *retLab;
    NSInteger Hcount;
}
@end

@implementation BTViewController

char bout11[5096];
int  boutlen11;
char* HexToBin11(char* hin)
{
	int i;
	char highbyte,lowbyte;
	int len= (int)strlen(hin);
	for (i=0;i<len/2;i++)
	{
		if (hin[i*2]>='0'&&hin[i*2]<='9')
			highbyte=hin[i*2]-'0';
		if (hin[i*2]>='A'&&hin[i*2]<='F')
			highbyte=hin[i*2]-'A'+10;
		if (hin[i*2]>='a'&&hin[i*2]<='f')
			highbyte=hin[i*2]-'a'+10;
		
		if (hin[i*2+1]>='0'&&hin[i*2+1]<='9')
			lowbyte=hin[i*2+1]-'0';
		if (hin[i*2+1]>='A'&&hin[i*2+1]<='F')
			lowbyte=hin[i*2+1]-'A'+10;
		if (hin[i*2+1]>='a'&&hin[i*2+1]<='f')
			lowbyte=hin[i*2+1]-'a'+10;
		
		bout11[i]=(highbyte<<4)|(lowbyte);
	}
	boutlen11=len/2;
	return bout11;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"蓝牙通讯测试界面";
        self.view.backgroundColor = [UIColor lightGrayColor];
        deviceArr = [[NSMutableArray alloc] initWithCapacity:0];
        myRandom = "12345678";
        myRandomLen = 3;
    }
    return self;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [cmManager closeDevice];

}
- (void)UPTEXT:(NSNotification *)note
{

    
    NSData *data = [note object];
    NSString *string = [NSString stringWithFormat:@"%@",data];
    string = [NSString stringWithFormat:@"%@%@",myTXTView.text,string];
    string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString *ss = @"000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f707172737475767778797a7b7c7d7e7f808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9fa0a1a2a3a4a5a6a7a8a9aaabacadaeafb0b1b2b3b4b5b6b7b8b9babbbcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdcecfd0d1d2d3d4d5d6d7d8d9dadbdcdddedfe0e1e2e3e4e5e6e7e8e9eaebecedeeeff0f1f2f3f4f5f6f7f8f9fafbfcfdfeff000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f707172737475767778797a7b7c7d7e7f808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9fa0a1a2a3a4a5a6a7a8a9aaabacadaeafb0b1b2b3b4b5b6b7b8b9babbbcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdcecfd0d1d2d3d4d5d6d7d8d9dadbdcdddedfe0e1e2e3e4e5e6e7e8e9eaebecedeeeff0f1f2f3f4f5f6f7f8f9fafbfcfdfeff000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f707172737475767778797a7b7c7d7e7f808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9fa0a1a2a3a4a5a6a7a8a9aaabacadaeafb0b1b2b3b4b5b6b7b8b9babbbcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdcecfd0d1d2d3d4d5d6d7d8d9dadbdcdddedfe0e1e2e3e4e5e6e7e8e9eaebecedeeeff0f1f2f3f4f5f6f7f8f9fafbfcfdfeff";
    
    if ([string containsString:ss]) {
        

        NSString *str = [NSString stringWithFormat:@"成功--第%ld次",(long)Hcount];
        [self performSelectorOnMainThread:@selector(updateData:) withObject:str waitUntilDone:NO];
        
        if (Hcount < 100) {
            
            NSLog(@"发送了第 %ld 次",(long)++Hcount);
            
            [self performSelectorOnMainThread:@selector(updateData:) withObject:[NSString stringWithFormat:@"发送了第 %ld 次",(long)Hcount] waitUntilDone:NO];
            
            [cmManager performSelectorInBackground:@selector(Request_Exit) withObject:nil];
            
        }

    }else{
        NSString *str = [NSString stringWithFormat:@"失败--第%ld次",(long)Hcount];
        [self performSelectorOnMainThread:@selector(updateData:) withObject:str waitUntilDone:NO];
//        [cmManager closeDevice];
    }


    
    
//    [self performSelectorOnMainThread:@selector(updateData:) withObject:string waitUntilDone:YES];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"calldelegateBluetoothReceive" object:data];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(UPTEXT:) name:@"calldelegateBluetoothReceive" object:nil];
    
    
    //
     commandDataArr = [[NSArray alloc] initWithObjects:@"获取psam卡号", @"获取磁道明文", @"获取PIN", @"MAC计算", @"刷卡密码连续指令", @"获取终端号商户号", @"修改终端号商户号",@"获取卡号",  @"获取磁道密文", @"请求输入", @"打印", @"透传测试", @"更新工作秘钥", @"ic卡刷卡",@"获取设备类型", @"参数下载", @"脚本回写",@"测试回显命令",@"停止命令",@"更新主秘钥",@"ic卡查询命令",@"上送脱机交易记录",nil];

    pkView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, HEIGHT-120, 320, 120)];
    pkView.dataSource = self;
    pkView.delegate = self;
    [self.view addSubview:pkView];
    [pkView release];
    
    lab = [[UILabel alloc] initWithFrame:CGRectMake(10, 80, 120, 36)];
    NSString *str = [commandDataArr objectAtIndex:0];
    [lab setFont:[UIFont systemFontOfSize:14]];
    lab.text = str;
    lab.alpha = 0.9;
    lab.layer.cornerRadius =2;
    lab.layer.borderWidth = 0.5;
    [self.view addSubview:lab];
    [lab release];
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(180-5, 80, 125, 36)];
    [button setTitle:@"点击发送指令" forState:UIControlStateNormal];
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [button setFont:[UIFont systemFontOfSize:14]];

    [button setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
    button.layer.cornerRadius = 2;
    button.layer.borderWidth = 0.5;
    [button setBackgroundColor:[UIColor colorWithRed:205/250.0f green:156/255.0f blue:248/255.0f alpha:1.0f]];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];

    [button addTarget:self action:@selector(sendCMD:) forControlEvents:UIControlEventTouchUpInside];
    [button release];
    /*************************************/
    myTXTView = [[UITextView alloc] initWithFrame:CGRectMake(lab.frame.origin.x, lab.frame.origin.y+lab.frame.size.height+10, 140, 210)];
    myTXTView.delegate = self;
    myTXTView.layer.cornerRadius = 5;
    myTXTView.layer.borderWidth = 0.5;
    myTXTView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:myTXTView];
    [myTXTView release];
    /************************************************/
    
    cmManager = [ItronCommunicationManagerBase getInstance];
//    NSLog(@"Ver_SDK= %@", [cmManager GetSDKVerson]);
    cmManager.communication = self;
    [cmManager setDebug:1];
    //
    
//    [cmManager openDevice:@"D4D666FA-E07E-7566-3540-CEE700394378" cbDelegate:self timeout:100];

    UIButton *searchBth = [[UIButton alloc] initWithFrame:CGRectMake(170, lab.frame.origin.y + lab.frame.size.height+20, 100, 36)];
    [searchBth setTitle:@"搜索蓝牙设备" forState:UIControlStateNormal];
    searchBth.layer.cornerRadius = 2;
    searchBth.layer.borderWidth = 0.5;
    [searchBth setBackgroundColor:[UIColor colorWithRed:205/250.0f green:156/255.0f blue:248/255.0f alpha:1.0f]];
    searchBth.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [searchBth setFont:[UIFont systemFontOfSize:14]];
    [searchBth setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [searchBth addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];
    [searchBth addTarget:self action:@selector(seachBtDevices:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:searchBth];
    [searchBth release];
    /***************************************************************/
    myTable = [[UITableView alloc] initWithFrame:CGRectMake(170, searchBth.frame.origin.y+searchBth.frame.size.height+8, 130, 150)];
    myTable.dataSource = self;
    myTable.delegate = self;
    myTable.layer.cornerRadius = 5;
    myTable.layer.borderWidth = 0.5;
    myTable.backgroundColor = [UIColor clearColor];
    [self.view addSubview:myTable];
    [myTable release];
    
    retLab = [[UILabel alloc] initWithFrame:CGRectMake(myTable.frame.origin.x, myTable.frame.origin.y+myTable.frame.size.height+4, 80, 30)];
    retLab.text = @"蓝牙状态";
    retLab.font = [UIFont systemFontOfSize:12];
    retLab.layer.cornerRadius = 2;
    retLab.layer.borderWidth = 0.5;
    [self.view addSubview:retLab];
    [retLab release];
    
}

- (void)seachBtDevices:(UIButton *)btn
{
    btn.alpha = 1.0;
    [deviceArr removeAllObjects];
    [cmManager searchDevices:self timeout:15*1000];

}
- (void)touchDown:(UIButton *)btn
{
    btn.alpha = 0.6;
}
//发送指令
- (void)sendCMD:(UIButton *)btn
{
//    Printing description of uuidString:
//    D4D666FA-E07E-7566-3540-CEE700394378
    Hcount = 1;
    btn.alpha = 1;
    myTXTView.text=@"";
    NSLog(@"%d", [cmManager isConnected]);
    switch ([pkView selectedRowInComponent:0]) {
        case 0:
            //获取psam卡号和硬件序列号
            [cmManager Request_GetExtKsn];
            break;
        case 1://获取磁道明文
            [cmManager Request_GetTrackPlaintext:60];
            break;
        case 2://获取PIN
        {
            NSString *cash = @"00";
            int cashLen = (int)[cash length];
            char cData[100];
            cData[0] = 0;
            strcpy(cData,((char*)[cash UTF8String]));

            [cmManager Request_GetPin:0 keyIndex:1 cash:cData cashLen:cashLen random:myRandom randomLen:0 panData:"" pandDataLen:0 time:60];
        }
            break;
        case 3://MAC计算
            {
                NSString *str = @"12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890";
                char * temp=HexToBin11((char *)[str UTF8String]);
                int datalen = (int)[str length]/2;
                NSLog(@"数据长度%i",datalen);
                char data[datalen];
                memcpy(data, temp, datalen);
                [cmManager Request_GetMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen];
            }
            break;
        case 4://刷卡密码连续指令
            {
                NSString *appendData = @"499000032000151413";
                char appendDataChar[100];
                memcpy(appendDataChar, HexToBin11((char*)[appendData UTF8String]),[appendData length]/2);
                int appendlen =(int)[appendData length];
                NSLog(@"appendlen %d",appendlen);
                
                [cmManager Request_ExtCtrlConOper:1 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:0x1c ParameterRandom:myRandom ParameterRandomLen:3 cash:"100" cashLen:3 appendData:"" appendDataLen:0 time:30];
            }
            break;
            
        case 5://获取终端号商户号
            [cmManager Request_VT];
            break;
        case 6://修改终端号商户号
            [cmManager Request_ReNewVT:"122010000201" vendorLen:15 terid:"99960000" teridLen:8];
            break;
        case 7:
            //获取卡号
            [cmManager Request_GetCardNo:60];
            break;
        case 8://获取磁道密文
            [cmManager Request_GetDes:0 keyIndex:1 random:myRandom randomLen:myRandomLen time:60];
        case 9://请求输入
            [cmManager Get_Userinput:0x01 timeout:60 min:2 max:6 keyindex:0 random:myRandom randomLen:myRandomLen title:"abc" titleLen:3];
            break;
        case 10://打印
        {
            
            char *test[]={"11            POS签购单",
                "11商户存根              请妥善保管",
                "12持卡人存根           请妥善保管",
                "00商户名称（MERCHANT NAME):\n柳州旺富家百货超市",////"柳州旺富家百货超市"
                "00商户号（MERCHANT NO.):\n826391045118696",
                "00终端号(TERMINAL NO.):\nW2054531",
                "00操作员号(OPERATOR NO.):01",
                "00------------------------------",
                "00发卡行(ISSUER):\n",
                "00收单行(ACQ):\n48264000",
                "00卡号(CARD NO.):\n520152******4119",
                "00交易类型(TRANS TYPE): \n",
                "00批次号(BATCH NO.):000001",
                "00凭证号(VOUCHER NO.):000196",
                "00授权号(AUTH NO.):",
                "00日期/时间(DATE/TIME):",
                "002015-04-05 12:49:43",
                "00参考号(REFER NO.):146183024097",
                "00金额(AMOUNT):",
                "00RMB:200.00",
                "00------------------------------",
                "00备注(REFERENCE):",
                "21持卡人签名(SIGNATURE):",
                "00本人确认以上交易，同意将其计入本卡账户",
                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
                "00ARQC 50A893A1F9C81BC3",
                "00TVR:008646000 AID:AOOOO333010102",
                "00TVR:PAN SN:001 TSI:E800 ATC:0057 AIP:7C00",
                "00IAD:07010103A0B802010A0100000000CBF55674",
                "00APPLAB PBOC CREDIT",
                "00应用首选名称 PBOC CREDIT",
                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
                "00ARQC 50A893A1F9C81BC3",
                "00TVR:008646000 AID:AOOOO333010102",
                "00TVR:PAN SN:001 TSI:E800 ATC:0057 AIP:7C00",
                "00IAD:07010103A0B802010A0100000000CBF55674",
                "00APPLAB PBOC CREDIT",
                "00应用首选名称 PBOC CREDIT",
                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
                "00ARQC 50A893A1F9C81BC3",
                "00TVR:008646000 AID:AOOOO333010102",
                "00TVR:PAN SN:001 TSI:E800 ATC:0057 AIP:7C00",
                "00IAD:07010103A0B802010A0100000000CBF55674",
                "00APPLAB PBOC CREDIT",
                "00应用首选名称 PBOC CREDIT",
                
                "00------------------------------",
                "22"};
            
            int i;
            NSMutableArray* na=[[NSMutableArray alloc] init];
            //            printf("print cnt=%ld\n ，sizeof(char*) == %lu",sizeof(test)/sizeof(char *) ,sizeof(char *));
            for(i=0;i<sizeof(test)/sizeof(char *);i++){
                [na addObject:[NSString stringWithUTF8String:test[i]]];
            }
            [cmManager rmPrint3:na pCnt:1 pakLen:400];
            break;

            
        }
            break;
        case 11://
        {
            ////PSAM卡货IC卡透传指令

            NSMutableString *str = [[NSMutableString alloc] initWithCapacity:0];
            for (int i = 0; i < 256; i++) {
                [str appendString:[NSString stringWithFormat:@"%02x",i ]];
            }
//            NSLog(@"str == %@", str);
            [str appendString:[NSString stringWithFormat:@"%@%@", str, str]];
            NSLog(@"str == %@", str);

            char * temp=HexToBin11((char *)[str UTF8String]);
            int datalen = [str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            [cmManager Request_ThroughOrders:1 OrdersIndex:3 OrdersData:data OrdersLegth:datalen TimeOut:60];
        }
            break;
        case 12://更新工作秘钥
        {
            NSString *workKey = @"3cef5086031cd21b3cef5086031cd21b82e13665";
            NSString *pinKey = workKey;
            NSString *macKey = workKey;
            NSString *desKey = workKey;
            char pin[100],mac[100],des[100];
            pin[0]=0;
            mac[0]=0;
            des[0]=0;
            char *tempPin = HexToBin11((char*)[pinKey UTF8String]);
            memcpy(pin, tempPin, [pinKey length]/2);//一定要拷贝否则会占用通一块内存
            int len =(int)[pinKey length]/2;
            char *tempMac = HexToBin11((char*)[macKey UTF8String]);
            memcpy(mac, tempMac, [macKey length]/2);//一定要拷贝否则会占用通一块内存
            char *tempDes = HexToBin11((char*)[macKey UTF8String]);
            memcpy(des, tempDes, [desKey length]/2);//一定要拷贝否则会占用通一块内存
            
            [cmManager Request_ReNewKey:0 PinKey:pin PinKeyLen:len
                                 MacKey:mac MacKeyLen:len
                                 DesKey:des DesKeyLen:len];
        }
            break;
        case 13:{
            //ic卡刷卡命令
            char * yy = "989898";
            NSString *str = @"31323334";
            char *temp = HexToBin11((char *)[str UTF8String]);
//            NSString *ksn = [NSString stringWithFormat:@"%s",temp];
            char rom[100];
            memcpy(rom, temp, [str length]/2);//一定要拷贝否则会占用通一块内存
            NSLog(@"%s", rom);
            NSString *appendData = @"123";
            char *temp1 = HexToBin11((char*)[appendData UTF8String]);
            char appendDataChar[1024];
            memcpy(appendDataChar, temp1, [appendData length]/2);//一定要拷贝否则会占用通一块内存
            int appendlen =(int)[appendData length]/2;
            NSString *cash = @"00";
            int cashLen = (int)[cash length];
            char cData[100];
            cData[0] = 0;
            strcpy(cData,((char*)[cash UTF8String]));
            Transactioninfo *tranInfo = [[Transactioninfo alloc] init];
            NSString *ctrm = @"88FB0400";
            ctrm = @"007B0E01";
            char *temp2 = HexToBin11((char*)[ctrm UTF8String]);
            char ctr[4];
            memcpy(ctr, temp2, [ctrm length]/2);
            [cmManager setCustomer:36];
            [cmManager stat_EmvSwiper:0x21 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:ctr ParameterRandom:"123" ParameterRandomLen:0 cash:cData cashLen:cashLen appendData:"" appendDataLen:0 time:30 Transactioninfo:tranInfo];
        }
            break;
        case 14:{//获取设备类型
            
            [cmManager getTerminalType];
            break;
        }
        case 15://参数下载
        {
            NSString *str = @"319F0605A0000000049F220106DF05083230323331323331DF060101DF070101DF0281F8CB26FC830B43785B2BCE37C81ED334622F9622F4C89AAE641046B2353433883F307FB7C974162DA72F7A4EC75D9D657336865B8D3023D3D645667625C9A07A6B7A137CF0C64198AE38FC238006FB2603F41F4F3BB9DA1347270F2F5D8C606E420958C5F7D50A71DE30142F70DE468889B5E3A08695B938A50FC980393A9CBCE44AD2D64F630BB33AD3F5F5FD495D31F37818C1D94071342E07F1BEC2194F6035BA5DED3936500EB82DFDA6E8AFB655B1EF3D0D7EBF86B66DD9F29F6B1D324FE8B26CE38AB2013DD13F611E7A594D675C4432350EA244CC34F3873";
            NSString *str1 = @"319F0608A000000333010102DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
            char * temp=HexToBin11((char *)[str1 UTF8String]);
            int datalen = (int)[str1 length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            [cmManager UpdateTerminalParameters:1 pageNum:1 data:data dataLen:datalen time:6];
        }
            break;
        case 16://脚本回写
        {
            NSString *str =@"9F2608BEC5FDD8569CED7C9F2701809F101307020103A02002010A010000000000424E87069F37044C24C2199F360200149505000004E8009A031409189C01009F02060000000060005F2A02015682027C009F1A0201569F03060000000000009F3303E0E1C89F34034203009F3501229F1E0830303030303030318408A0000003330101029F090200209F4104000000029F631030313035303030300000000000000000";
            NSData *testData = [str dataUsingEncoding:NSUTF8StringEncoding] ;
            NSLog(@"testData == %@", testData);
            char * temp=HexToBin11((char *)[str UTF8String]);
            int datalen = (int)[str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            
            NSString *resCode = @"00";
            char * temp1=(char *)[resCode UTF8String];
            NSLog(@"%s", temp1);
            int datalen1 = (int)[resCode length];
            char resData[datalen1];
            memcpy(resData, temp1, datalen1);
            [cmManager secondIssuance:resData data:data dataLength:datalen+datalen1 time:10];
        }
        case 17:{
            [cmManager display:@"测试显示命令" timer:15];
        }
            break;
        case 18:{
            [cmManager Request_Exit];
            cmManager.tCount = 1;
            Hcount = 1;
            NSLog(@"发送了第 %ld 次",Hcount);

//            [cmManager publickeyRepair];
        }
            break;
        case 19:{
            //更新主秘钥
            NSString *str = @"11111111111111111111111111111111";
            char *tempStr = HexToBin((char *)[str UTF8String]);
            int mLen = (int)[str length]/2;
            char data[mLen];
            memcpy(data, tempStr, mLen);
            [cmManager Request_ReNewTMK3:data dataLen:mLen time:10];
//            -(void) Request_ReNewTMK:(char*)_MainKey MainKeyLen:(int)_MainKeyLen time:(int)_timeOut
//            [cmManager Request_ReNewTMK:data MainKeyLen:mLen time:10];
            //主密钥明文：2f38051d6392a7a02f38051d6392a7a0，工作秘钥密文：271f59c0d2fdd5a4271f59c0d2fdd5a482e13665,校验位：82e13665

        }
            break;
        case 20:{
            //ic卡查询命令
            [cmManager icSelected:2 hasRecode:0 timeOut:20];
            
        }
            break;
        default:
            break;
    }
}
#pragma mark DeviceSearchListener method
//- (void)discoverOneDevice:(CBPeripheral *)peripheral
//{
////    [deviceArr addObject:peripheral];
//    NSLog(@"name is %@",peripheral.name);
//}
- (void)discoverBLeDevice:(NSDictionary *)uuidAndName
{
    [deviceArr addObject:uuidAndName];
    NSLog(@"device is %@", uuidAndName);
    [self updateTable];

//    [cmManager stopSearching];
//    [self mytest];
//    [self performSelector:@selector(mytest) withObject:nil];
}
- (void)mytest
{
    int res = [cmManager openDevice:@"47239079-EB7A-FCAF-CCA1-E05FE91C699C" cbDelegate:self timeout:15*1000];
    retLab.text = @"正在打开";
    if (res == 0) {
        NSLog(@"%d", [cmManager isConnected]);
        
        retLab.text = @"蓝牙连接成功";
        UIButton *btnn = [[UIButton alloc] initWithFrame:CGRectMake(retLab.frame.origin.x, retLab.frame.origin.y + retLab.frame.size.height +4, retLab.frame.size.width, retLab.frame.size.height)];
        [btnn setTitle:@"断开连接" forState:UIControlStateNormal];
        [btnn addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];
        [btnn addTarget:cmManager action:@selector(closeDevice) forControlEvents:UIControlEventTouchUpInside];
        [btnn setBackgroundColor:[UIColor colorWithRed:135/250.0f green:156/255.0f blue:208/255.0f alpha:1.0f]];
        
        btnn.layer.cornerRadius = 4;
        btnn.layer.borderWidth = 0.5;
        btnn.tag = 120;
        [btnn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [self.view addSubview:btnn];
        [btnn release];
    }
    else{
        retLab.text = @"蓝牙连接失败";
    }
}
- (void)discoverComplete
{
    NSLog(@"-----------------搜索结束-----------------");
}
- (void)updateTable
{
    [myTable reloadData];
    
}
char hout99[5096];
char* BinToHex99(char* bin,int off,int len)
{
	int i;
	//	hout=(char*)hout;
	for (i=0;i<len;i++)
	{
		sprintf((char*)hout99+i*2,"%02x",*(unsigned char*)((char*)bin+i+off));
	}
	hout99[len*2]=0;
	return hout99;
}
#pragma mark Communication method
//刷卡信息返回
- (void)dataArrive:(vcom_Result *)vs Status:(int)_status
{
    
    if(_status==-3){
        //设备没有响应
        NSLog(@"通信超时");
        [self performSelectorOnMainThread:@selector(updateData:) withObject:@"通信超时" waitUntilDone:YES];

        return;
    }else if(_status == -2){
        //耳机没有插入
        return;
    }else if(_status==-1){
        //接收数据的格式错误
    }
    else if(_status == -4 )
    {
        NSLog(@"数据内容有错误！-4");
    }
    else{
        //操作指令正确
        if(vs->res==0){
        //更新工作秘钥成功
            if (vs->rescode[0] == 0x02 &&vs->rescode[1] == 0x10) {
                 [self performSelectorOnMainThread:@selector(updateData:) withObject:@"更新工作秘钥成功！" waitUntilDone:NO];
            }
            else if(vs->rescode[0] == 0x09 && vs->rescode[1] == 0x07)
            {
                
                NSString *str = [NSString stringWithFormat:@"成功--第%ld次",(long)Hcount];
                [self performSelectorOnMainThread:@selector(updateData:) withObject:str waitUntilDone:NO];
                
                if (Hcount < 200) {
                    
                    NSLog(@"发送了第 %ld 次",(long)++Hcount);
                    
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:[NSString stringWithFormat:@"发送了第 %ld 次",(long)Hcount] waitUntilDone:NO];
                    
                    [cmManager performSelectorInBackground:@selector(Request_Exit) withObject:nil];
                    
                }
               
                NSLog(@"停止命令执行成功");
                return;
            }
            else if (vs->rescode[0] == 0x09 && vs->rescode[1] == 0x26)
            {
                //                NSLog(@"更新主秘钥完成！");
            }
            else if (vs->rescode[0] == 0x02 && vs->rescode[1] == 0xa0) {
                NSLog(@"刷卡命令完成！" );
            }
         //设备有成功返回指令
            NSString *succStr = @"";
            NSMutableString *strTemp = [[NSMutableString alloc] initWithCapacity:0];
            //获取psam卡号
            //刷卡连续操作
            if(vs->pinEncryptionLen > 0)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n pinEncryption：%@", [self HexValue:vs->pinEncryption Len:vs->pinEncryptionLen]]];
                
            }
            ////磁道
            if (vs->trackPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackPlaintext:%@",[self HexValue:vs->trackPlaintext Len:vs->trackPlaintextLen]]];
            }
            if (vs->trackEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackEncryption:%@",[self HexValue:vs->trackEncryption Len:vs->trackEncryptionLen]]];
                
                
            }
            if (vs->cardPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardPlaintext:%s", vs->cardPlaintext]];
                
            }
            if (vs->cardEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardEncryption:%@", [self HexValue:vs->cardEncryption Len:vs->cardEncryptionLen]]];
                
            }
            if (vs->panLen>0) {
                //                NSLog(@"%d", vs->panLen);
                [strTemp appendString:[NSString stringWithFormat:@"\n pan码:%@",[self HexValue:vs->pan Len:vs->panLen] ]];
            }
            if (vs->traderNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n shnoInPsam:%@",[self HexValue:vs->traderNoInPsam Len:vs->traderNoInPsamLen] ]];
                
            }
            if (vs->termialNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n zdnoInPsam:%@",[self HexValue:vs->termialNoInPsam Len:vs->termialNoInPsamLen] ]];
                
            }
            if (vs->userInputLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n userInput:%@",[self HexValue:vs->userInput Len:vs->userInputLen] ]];
            }
            if (vs->cdnolen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cdno:%s",vs->cdno]];
                NSString *str1=[NSString stringWithCString:vs->cdno  encoding:NSUTF8StringEncoding];
                NSLog(@"str1 is %@", str1);
                
            }
            if (vs->orderLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ordersData:%@", [self HexValue:vs->Return_orders Len:vs->orderLen]]];
            }
            if (vs->track2Len > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n Track2:%@",[self HexValue:vs->Track2 Len:vs->track2Len] ]];
            }
            if (vs->track3Len > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n Track3:%@",[self HexValue:vs->Track3 Len:vs->track3Len] ]];
            }
            if (vs->cvmLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cvm:%@",[self HexValue:vs->cvmData Len:vs->cvmLen] ]];
            }
            if (vs->deviceLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n deviceKind:%@",[self HexValue:vs->deviceKind Len:vs->deviceLen] ]];
                
            }
            if (vs->cardTypeLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardType:%@",[self HexValue:vs->cardType Len:vs->cardTypeLen] ]];
            }
            if (vs->data55Len>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n data55:%@",[self HexValue:vs->data55 Len:vs->data55Len] ]];
                NSString * st55 = [NSString stringWithFormat:@"\n data55:%@",[self HexValue:vs->data55 Len:vs->data55Len] ];
                [self check5f24:st55];
//                NSLog(@"得到的55域：%@",st55);
//                NSRange rg = [st55 rangeOfString:@"5f2403"];
//                if (rg.location != NSNotFound) {
//                    NSString *str1 = [st55 substringWithRange:NSMakeRange(rg.location, 6)];
//                    st55 = [st55 stringByReplacingOccurrencesOfString:str1 withString:@""];
//                    //修改len+value
//                    str1 = [str1 stringByReplacingOccurrencesOfString:@"03" withString:@"02"];
//                    str1 = [str1 substringToIndex:5];
//                    st55 = [NSString stringWithFormat:@"%@%@",st55,str1];
//                }
//                NSLog(@"处理后的55域：%@",st55);

                
            }
            if (vs->ICReturnDataLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ICReturnData:%@",[self HexValue:vs->ICReturnData Len:vs->ICReturnDataLen] ]];
                
            }
            if (vs->psamno > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ICReturnData:%@",[self HexValue:vs->psamno Len:vs->psamnoLen] ]];
                
            }
            if (vs->hardSerialNoLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ICReturnData:%@",[self HexValue:vs->hardSerialNo Len:vs->hardSerialNoLen] ]];
                
            }
            if (vs->loadLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n loadData:%@",[self HexValue:vs->loadData Len:vs->loadLen] ]];
                
            }
            if (vs->xulieDataLen)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n xulieData:%@",[self HexValue:vs->xulieData Len:vs->xulieDataLen] ]];
                
            }
            if (![strTemp isEqualToString:@""]) {
                [self performSelectorOnMainThread:@selector(updateData:) withObject:strTemp waitUntilDone:NO];
            }
            
    
        }
        else
        {
            NSLog(@"cmd exec error:%d\n",vs->res);
            switch (vs->res) {
                case 1:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"通信超时" waitUntilDone:NO];
                    break;
                case 2:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"PSAM卡认证失败" waitUntilDone:NO];
                    break;
                case 3:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"Psam卡上电失败或者不存在" waitUntilDone:NO];
                    break;
                case 4:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotSupportCmdFormPosToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 10:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"用户退出" waitUntilDone:NO];
                    break;
                case 11:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"MAC校验失败" waitUntilDone:NO];
                    break;
                case 12:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"终端加密失败" waitUntilDone:NO];
                    break;
                case 14:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"用户按了取消健" waitUntilDone:NO];
                    break;
                case 15:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"Psam卡状态异常" waitUntilDone:NO];
                    break;
                case 0x20:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不匹配的主命令码" waitUntilDone:NO];
                    break;
                case 0x21:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不匹配的子命令码" waitUntilDone:NO];
                    break;
                case 0x50:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"获取电池电量失败" waitUntilDone:NO];
                    break;
                case 0x80:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"数据接收正确" waitUntilDone:NO];
                    break;
                case 0x86:
                    NSLog(@"ic卡操作失败");
                    break;
                case 0x40:
                    [self performSelectorOnMainThread:@selector(refreshStatusNoPaperInPrinterToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xe0:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"重传数据无效" waitUntilDone:NO];
                    break;
                case 0xe1:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"终端设置待机信息失败" waitUntilDone:NO];
                    break;
                case 0xf0:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不识别的包头" waitUntilDone:NO];
                    break;
                case 0xf1:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不识别的主命令码" waitUntilDone:NO];
                    break;
                    
                case 0xf2:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotVerifySubCmdToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf3:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"该版本不支持此指令" waitUntilDone:NO];
                    break;
                    
                case 0xf4:
                    [self performSelectorOnMainThread:@selector(refreshStatusRandomLengthErrToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf5:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不支持的部件" waitUntilDone:NO];
                    break;
                case 0xf6:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"不支持的模式" waitUntilDone:NO];
                    break;
                case 0xf7:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataLengthErrToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                    
                case 0xfc:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataConentErrToPhone1) withObject:nil waitUntilDone:NO];
                    break;
                case 0xfd:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"终端ID错误" waitUntilDone:NO];
                    break;
                case 0xfe:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"MAC_TK校验失败" waitUntilDone:NO];
                    break;
                case 0xff:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:@"校验和错误" waitUntilDone:NO];
                    break;
                default:
                    [self performSelectorOnMainThread:@selector(updateData:) withObject:nil waitUntilDone:NO];
                    break;
            }
            /* 失败和中间状态代码
             01
             命令执行超时
             02
             PSAM卡认证失败
             03
             Psam卡上电失败或者不存在
             04
             Psam卡操作失败
             0A
             用户退出
             0B
             MAC校验失败
             0C
             终端加密失败
             0E
             用户按了取消健
             0F
             Psam卡状态异常
             20
             不匹配的主命令码
             21
             不匹配的子命令码
             50
             获取电池电量失败
             80
             数据接收正确
             E0
             重传数据无效
             E1
             终端设置待机信息失败
             F0
             不识别的包头
             F1
             不识别的主命令码
             F2
             不识别的子命令码
             F3
             该版本不支持此指令
             F4
             随机数长度错误
             F5
             不支持的部件
             F6
             不支持的模式
             F7
             数据域长度错误
             FC
             数据域内容有误
             FD
             终端ID错误
             FE
             MAC_TK校验失败
             FF
             校验和错误
             // 打印错误
             PROTOCOL_ERR_PRT_NOPAPER     == 0X40   ;打印机缺纸
             PROTOCOL_ERR_PRT_OFF         == 0X41   ;打印机离线
             PROTOCOL_ERR_PRT_NO          == 0X42   ;没有打印机
             PROTOCOL_ERR_PRT_NOBM        == 0X43  ;没有黑标
             PROTOCOL_ERR_PRT_CLOSE       == 0X44  ;打印机关闭
             PROTOCOL_ERR_PRT_OTHER       == 0X45  ;打印机故障
             */
        }
    }
}
- (void)keyTest
{
//    NSString* param = @"6D894CB8B15D89111F017515A7EC6AC39E689758FE635B90ACAEFDB16FB13B818330D3EB2C2507F3D72DC0CB9F75835F";
//    NSString* pinKey = [param substringToIndex:40];
//    NSString* macKey = [param substringWithRange:NSMakeRange(48,40)];
//    char pin[100],mac[100],des[100];
//    pin[0]=0;
//    mac[0]=0;
//    des[0]=0;
//    strcpy(pin,HexToBin11((char*)[pinKey UTF8String]));
//    strcpy(mac,HexToBin11((char*)[macKey UTF8String]));
//    
//    [cmManager Request_ReNewKey:0 PinKey:pin PinKeyLen:20
//                         MacKey:mac MacKeyLen:20
//                         DesKey:pin DesKeyLen:20];
    
    //联动优势
    NSString *workKey = @"89b07b35a1b3f47e4eb13bf6";
    NSString *pinKey = workKey;
    NSString *macKey = workKey;
    NSString *desKey = workKey;
    char pin[100],mac[100],des[100];
    pin[0]=0;
    mac[0]=0;
    des[0]=0;
    char *tempPin = HexToBin11((char*)[pinKey UTF8String]);
    memcpy(pin, tempPin, [pinKey length]/2);//一定要拷贝否则会占用通一块内存
    int len =(int)[pinKey length]/2;
    
    char *tempMac = HexToBin11((char*)[macKey UTF8String]);
    memcpy(mac, tempMac, [macKey length]/2);//一定要拷贝否则会占用通一块内存
    char *tempDes = HexToBin11((char*)[macKey UTF8String]);
    memcpy(des, tempDes, [desKey length]/2);//一定要拷贝否则会占用通一块内存
    
    
    [cmManager Request_ReNewKey:0 PinKey:pin PinKeyLen:len
                         MacKey:mac MacKeyLen:len
                         DesKey:des DesKeyLen:len];

}
- (void)updateData:(NSString *)str
{
    myTXTView.text = str;
}
- (void)onError:(NSInteger) code msg:(NSString*) msg
{
    NSLog(@"%d", [cmManager isConnected]);
    NSLog(@"onError:%d mesage:%@", (int)code, msg);
    [self performSelectorOnMainThread:@selector(updateData:) withObject:msg waitUntilDone:NO];
}
- (void)onTimeout
{
    NSLog(@"-----------------通信超时--------------------");
}
//命令字响应部分
-(void)refreshStatusNotSupportCmdFormPosToPhone1
{
    myTXTView.text = @"cmd exec error:4,刷卡器硬件暂不支持该命令！";
}
-(void)refreshStatusNoReponseFromPosToPhone1
{
    myTXTView.text = @"命令超时！";
}
-(void)refreshPOSSwipeAction1
{
    myTXTView.text = @"执行命令成功！";
}

-(void)refreshStatusNotVerifySubCmdToPhone1
{
    myTXTView.text = @"cmd exec error:242,不识别的子命令码!";
}

-(void)refreshStatusRandomLengthErrToPhone1
{
    myTXTView.text = @"cmd exec error:244,随机数长度错误!";
}

-(void)refreshStatusNoPaperInPrinterToPhone1
{
    myTXTView.text = @"cmd exec error:64,打印机缺纸!";
}
-(void)refreshStatusDataLengthErrToPhone1
{
    myTXTView.text = @"cmd exec error:247,数据域长度错误!";
}
-(void)refreshStatusDataConentErrToPhone1
{
    myTXTView.text = @"cmd exec error:252,数据域内容错误!";
}
- (NSString*)HexValue:(char*)bin Len:(int)binlen{
    char *hs;
    hs = BinToHex99(bin,0,binlen);//, <#int off#>, <#int len#>)
    hs[binlen*2]=0;
    NSString* str =[[NSString alloc] initWithFormat:@"%s",hs];
    //NSLog(@"str=%@,len=%d,buf=%c",str,buflen,buf[0]);
    return str;
}


#pragma mark pickerView delegate method
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [commandDataArr count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [commandDataArr objectAtIndex:row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    lab.text =  [commandDataArr objectAtIndex:row];
}
#pragma mark UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [deviceArr count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *oneCell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (oneCell == nil) {
        oneCell  = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"] autorelease];
    
    }
    if ([deviceArr count] != 0) {
        NSDictionary * dic = [deviceArr objectAtIndex:indexPath.row];
        NSString *name = [dic objectForKey:[dic objectForKey:@"mainKey"]];
        NSLog(@"deviecName is %@", name);
        oneCell.textLabel.font = [UIFont systemFontOfSize:12];
        oneCell.textLabel.text = name; ;
    }
    
    return oneCell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cmManager stopSearching];
    if ([deviceArr count] == 0) {
        return;
    }
    NSString *uuidString = [[deviceArr objectAtIndex:indexPath.row] objectForKey:@"mainKey"];
    int ret = [cmManager openDevice:uuidString cbDelegate:self timeout:15*1000];

    retLab.text = @"正在打开";
    if (ret == 0) {
        NSLog(@"%d", [cmManager isConnected]);

        retLab.text = @"蓝牙连接成功";
        UIButton *btnn = [[UIButton alloc] initWithFrame:CGRectMake(retLab.frame.origin.x, retLab.frame.origin.y + retLab.frame.size.height +4, retLab.frame.size.width, retLab.frame.size.height)];
        [btnn setTitle:@"断开连接" forState:UIControlStateNormal];
        [btnn addTarget:self action:@selector(touchDown:) forControlEvents:UIControlEventTouchDown];
        [btnn addTarget:cmManager action:@selector(closeDevice) forControlEvents:UIControlEventTouchUpInside];
        [btnn setBackgroundColor:[UIColor colorWithRed:135/250.0f green:156/255.0f blue:208/255.0f alpha:1.0f]];

        btnn.layer.cornerRadius = 4;
        btnn.layer.borderWidth = 0.5;
        btnn.tag = 120;
        [btnn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [self.view addSubview:btnn];
        [btnn release];
    }
    else{
        retLab.text = @"蓝牙连接失败";
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}

#pragma mark UITextView delegate
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)closeOk
{
    retLab.text = @"蓝牙已经断开";
    NSLog(@"蓝牙已经断开");
    UIButton *btn = (UIButton *)[self.view viewWithTag:120];
    if (btn) {
        [btn removeFromSuperview];
    }
    NSLog(@" %d" ,[cmManager isConnected]);
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)onWaitingForCardSwipe
{

    NSLog(@"等待刷卡===");
}
- (void)EmvOperationWaitiing{
    
    NSLog(@"ic卡插入，请不要拔卡！");
}
//IC卡回写脚本执行返回结果
- (void)onICResponse:(int)result resScript:(NSString *)resuiltScript data:(NSString *)data
{
    NSLog(@"result = %d ,resScript = %@, data = %@", result, resuiltScript, data);
    
}
int pageNum = 1;

//参数下载回调
- (void)onLoadParam:(NSString *)param
{
    NSLog(@"参数下载：%@",param);
    
//    myTXTView.text =[NSString stringWithFormat:@"第%d包数下载成功",pageNum];
    
    [self performSelectorInBackground:@selector(sendParm) withObject:nil];
}
- (void)onDeviceKind:(int)result
{
    
    NSLog(@"设备类型：%d", result);
}
- (void)sendParm
{
    if(pageNum == 4)
    {
        return;
    }
    NSString *str = nil;
    NSString *str1 = nil;
    if(pageNum ==1){
        str = @"319f0605a0000003339f220104df050420241231df060101df070101df0281f8bc853e6b5365e89e7ee9317c94b02d0abb0dbd91c05a224a2554aa29ed9fcb9d86eb9ccbb322a57811f86188aac7351c72bd9ef196c5a01acef7a4eb0d2ad63d9e6ac2e7836547cb1595c68bcbafd0f6728760f3a7ca7b97301b7e0220184efc4f653008d93ce098c0d93b45201096d1adff4cf1f9fc02af759da27cd6dfd6d789b099f16f378b6100334e63f3d35f3251a5ec78693731f5233519cdb380f5ab8c0f02728e91d469abd0eae0d93b1cc66ce127b29c7d77441a49d09fca5d6d9762fc74c31bb506c8bae3c79ad6c2578775b95956b5370d1d0519e37906b384736233251e8f09ad79dfbe2c6abfadac8e4d8624318c27daf1df040103df0314f527081cf371dd7e1fd4fa414a665036e0f5e6e5";
        str1 = @"319F0608A000000333010103DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
    }
    if(pageNum==2){
        str = @"319F0605A0000003339F220102DF050420211231DF060101DF070101DF028190A3767ABD1B6AA69D7F3FBF28C092DE9ED1E658BA5F0909AF7A1CCD907373B7210FDEB16287BA8E78E1529F443976FD27F991EC67D95E5F4E96B127CAB2396A94D6E45CDA44CA4C4867570D6B07542F8D4BF9FF97975DB9891515E66F525D2B3CBEB6D662BFB6C3F338E93B02142BFC44173A3764C56AADD202075B26DC2F9F7D7AE74BD7D00FD05EE430032663D27A57DF040103DF031403BB335A8549A03B87AB089D006F60852E4B8060";
        str1 = @"319F0608A000000333010101DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
        
    }
    if (pageNum == 3) {
        str1 = @"319F0608A000000333010106DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160120DF170110DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
         str = @"319F0605A0000003339F220102DF050420211231DF060101DF070101DF028190A3767ABD1B6AA69D7F3FBF28C092DE9ED1E658BA5F0909AF7A1CCD907373B7210FDEB16287BA8E78E1529F443976FD27F991EC67D95E5F4E96B127CAB2396A94D6E45CDA44CA4C4867570D6B07542F8D4BF9FF97975DB9891515E66F525D2B3CBEB6D662BFB6C3F338E93B02142BFC44173A3764C56AADD202075B26DC2F9F7D7AE74BD7D00FD05EE430032663D27A57DF040103DF031403BB335A8549A03B87AB089D006F60852E4B8060";
    }
    
    char * temp=HexToBin11((char *)[str UTF8String]);
    int datalen = (int)[str1 length]/2;
    char data[datalen];
    memcpy(data, temp, datalen);
    [cmManager UpdateTerminalParameters:1 pageNum:pageNum++ data:data dataLen:datalen time:6];
    
}

- (void)dealloc
{
    [deviceArr release];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}
- (NSString *)check5f24:(NSString *)st55
{
//    NSLog(@"得到的55域：%@",st55);
    st55 = [st55 lowercaseString];
    NSRange rg = [st55 rangeOfString:@"5f2403"];
    if (rg.location != NSNotFound) {
        st55 = [st55 stringByReplacingOccurrencesOfString:@"5f2403" withString:@"5f2402"];
        st55 = [st55 stringByReplacingCharactersInRange:NSMakeRange(rg.location+10, 2) withString:@""];
    }
//    NSLog(@"处理后的55域：%@",st55);
    return [st55 uppercaseString];
}
- (void)didfinishICUpdate{
    
    myTXTView.text = @"公钥修复完成！";
    NSLog(@"公钥修复完成！");
}
-(void) ocICselectBack:(NSArray *) array
{
    NSLog(@"交易记录查询结果");
}
@end




