
//
//  ViewController.h : interface for the ViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import <UIKit/UIKit.h>
#import "vcom.h"
#import <Foundation/Foundation.h>

@interface NewBTViewController : UIViewController<CSwiperStateChangedListener,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate>
{
    vcom* m_vcom;
    id timer;
    char *myRandom;
    int myRandomLen;
}

-(void)readcardcont:(id)sender;
-(void)comModeChange:(id)sender;
-(void)sendCmd:(id)sender;
-(void)recswitch:(id)sender;
-(void)closesdk:(id)sender;

@property (retain, nonatomic)  UILabel *m_sdkver;
@property (retain, nonatomic)  UILabel *m_commStat;
@property (retain, nonatomic)  UITextView *m_recvData;
@property (retain, nonatomic)  UITextField *m_cmdIndex;

@end