
//
//  MainViewController.m : implementation of the MainViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import "MainViewController.h"
#import "ViewController.h"
#import "iTronSwipeDeviceViewController.h"
#import "BTViewController.h"
#import "NewBTViewController.h"
#import "BleFori21ViewController.h"
//#import "HYinViewController.h"
@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //初始化对象
    self.title = @"艾创ios测试程序";
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"back" style:UIBarButtonItemStyleBordered target:nil action:nil];
    [self.navigationItem setBackBarButtonItem:backItem];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
//点刷测试界面
- (IBAction)buttonClick:(id)sender
{
    ViewController *vc = [[ViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}
//爱刷测试界面
-(IBAction)iTronSwiptbuttonClick:(id)sender
{
    iTronSwipeDeviceViewController *vc = [[iTronSwipeDeviceViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}
//蓝牙测试界面
- (IBAction)btoothClick:(id)sender
{
    BTViewController *btVctl = [[BTViewController alloc] init];
    [self.navigationController pushViewController:btVctl animated:YES];
}

- (IBAction)newBTclick:(id)sender {
    
    NewBTViewController *newBtvCtl = [[NewBTViewController alloc] init];
    [self.navigationController pushViewController:newBtvCtl animated:YES];
}
- (IBAction)I21BleClick:(UIButton *)sender {
    
    BleFori21ViewController * ble21 = [[BleFori21ViewController alloc] init];
    [self.navigationController pushViewController:ble21 animated:YES];
}


-(IBAction)main_readid:(id)sender
{
    //启动接收刷卡器数据
    [m_vcom playCmd:"000200000000"];
    [m_vcom StartRec];
    
}


- (void)dealloc
{
    [super dealloc];
}
- (IBAction)hanyinTest:(id)sender {
    
//    HYinViewController *hViewCtrl = [[HYinViewController alloc] init];
//    [self.navigationController pushViewController:hViewCtrl animated:YES];
}
@end









