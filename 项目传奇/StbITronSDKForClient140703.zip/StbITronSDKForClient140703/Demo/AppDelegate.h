
//
//  AppDelegate.h : interface for the AppDelegate class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreTelephony/CTCallCenter.h>
#import <CoreTelephony/CTCall.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;
@property (retain, nonatomic) UINavigationController *navVC;

@end
