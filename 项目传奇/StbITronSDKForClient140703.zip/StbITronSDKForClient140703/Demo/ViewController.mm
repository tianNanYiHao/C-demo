
//
//  ViewController.m : implementation of the ViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import "ViewController.h"
#import "vcom.h"
#import "SignViewController.h"
#import "RTFlyoutItem.h"

@interface ViewController ()

@property (strong, nonatomic) RTFlyoutMenu *flyoutMenu;
@property (strong, nonatomic) UIView *menuContainerView;

@property (strong,nonatomic) NSArray *mainItems;
@property (strong,nonatomic) NSArray *subItems;

@end

@implementation ViewController

@synthesize m_commStat;
@synthesize m_lineIn;
@synthesize m_recvData;
@synthesize m_cmdIndex;
@synthesize m_sdkver;

bool readOldFile = TRUE;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title =@"点付宝和音频POS测试界面";
        self.view.backgroundColor = [UIColor lightGrayColor];
        myRandom = "12345678";
        myRandomLen = 8;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(20, 85, 60, 30)];
    view.backgroundColor = [UIColor clearColor];
    [self.view addSubview:view];
    self.menuContainerView = view;
    
    UIView *menuContainerView = [[UIView alloc] initWithFrame:CGRectMake(20, 85, 1, 1)];
    menuContainerView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:menuContainerView];
    self.mainItems = @[@"选取指令    "];
    self.subItems = @[@[@"获取psam卡号和硬件序列号", @"修改终端号商户号",@"获取卡号", @"获取磁道密文",@"获取PIN", @"刷卡密码连续指令", @"MAC计算",@"打印", @"透传测试"]];
    
    
    //初始化对象
    m_vcom = [vcom getInstance];
    [m_vcom open];
    m_vcom.eventListener=self;
    //设置数据发送模式和接收模式
    [m_vcom setCommmunicatinMode:dianFB];
    [m_vcom setVloumn:75];
    [m_vcom setDebug:1];
    [m_vcom setMac:false];
    if ([self hasHeadset]) {
        m_lineIn.text = @"耳机插入";
    }else{
        m_lineIn.text = @"耳机未插入";
    }
    
    m_sdkver.text=@"3.0.2";
    
}

-(void)switchAction:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    BOOL isButtonOn = [switchButton isOn];
    if (isButtonOn) {
        readOldFile = YES;
    }else {
        readOldFile = NO;
    }
}
//检查micphone状态
- (BOOL)hasHeadset
{
#if TARGET_IPHONE_SIMULATOR
#warning *** Simulator mode: audio session code works only on a device
    return NO;
#else
    CFStringRef route;
    UInt32 propertySize = sizeof(CFStringRef);
    AudioSessionGetProperty(kAudioSessionProperty_AudioRoute, &propertySize, &route);
    if((route == NULL) || (CFStringGetLength(route) == 0))
    {
        // Silent Mode
        //NSLog(@"AudioRoute: SILENT, do nothing!");
    }
    else
    {
        NSString* routeStr = (NSString*)route;
        //NSLog(@"AudioRoute: %@", routeStr);
        
        NSRange headphoneRange = [routeStr rangeOfString : @"Headphone"];
        NSRange headsetRange = [routeStr rangeOfString : @"Headset"];
        if (headphoneRange.location != NSNotFound)
        {
            return YES;
        } else if(headsetRange.location != NSNotFound)
        {
            return YES;
        }
    }
    return NO;
#endif
}

//麦克风是否插入消息函数
- (void)checkmic_event:(NSNotification* )note
{
    int res=[[note object] intValue];
    
    if(res==0)
        m_lineIn.text=@"耳机未插入";
    else {
        m_lineIn.text=@"耳机插入";
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

int rcnt=0;
-(void) doRefresh:(NSString*)str
{
    m_recvData.text=str;
    rcnt++;
    m_commStat.text=[NSString stringWithFormat:@"RECV:%d",rcnt];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

void converttogbk(char* uf8[],int uf8len,char gbk[20][200])
{
    int i;
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    for(i=0;i<uf8len;i++){
        NSString* obj=[NSString stringWithUTF8String:uf8[i]];
        NSData *ele = [obj dataUsingEncoding:enc];
        int elen=[ele length];
        char* pc=(char*)[ele bytes];
        memcpy(gbk[i],pc,elen);
    }
}


/**
 * mac
 * @param in 计算mac数据
 * @param customer 客户ID
 * @param key 客户MAC密钥
 * @return  返回加上mac后的数据   数据+ mac + 随机数
 * @throws Exception
 */
//发送指令测试
-(IBAction)sendCmd:(id)sender
{
    m_recvData.text=@"";
    int cmdindex=[m_cmdIndex.text intValue];
//    cmdindex = 15;
    [m_vcom StopRec];
    switch (cmdindex) {
        case 1:
        {
            //获取磁道明文
            [m_vcom Request_GetTrackPlaintext:60];
            m_recvData.text = @"cmdindex:1";
            break;
        }
        case 2:
        {
            //获取随机数
            [m_vcom Request_GetRandom:8];
            m_recvData.text = @"cmdindex:2";
            break;
        }
        case 3:
        {
            //获取psam卡上保存的商户号码和终端号
            [m_vcom Request_VT];
            m_recvData.text = @"cmdindex:3";
            //v3.2psam卡不支持该命令
            break;
        }
        case 4:
        {
            //退出指令
            [m_vcom Request_Exit];
            m_recvData.text = @"cmdindex:4";
            break;
        }
        case 5:
        {
            //获取电池电量
            [m_vcom Request_BatLevel];
            m_recvData.text = @"cmdindex:5";
            break;
        }
        case 6:
        {
            //获取打印机状态
            [m_vcom Request_PrtState];
            m_recvData.text = @"cmdindex:6";
            break;
        }
        case 7:
        {
            //重传指令
            [m_vcom Request_ReTrans];
            m_recvData.text = @"cmdindex:7";
            break;
        }
        case 8:
        {
            //获取磁卡卡号明文
            [m_vcom Request_GetCardNo:60];
            m_recvData.text = @"cmdindex:8";
            break;
        }
        case 9:
        {
            //获取磁道信息明文
            [m_vcom Request_GetTrackPlaintext:60];
            m_recvData.text = @"cmdindex:9";
            break;
        }
        case 10:
        {
            //银行卡口令密文
            [m_vcom Request_GetPin:0 keyIndex:0 cash:"12345" cashLen:5 random:myRandom randomLen:myRandomLen panData:"" pandDataLen:0 time:30];
            m_recvData.text = @"cmdindex:10";
            break;
        }
        case 11:
        {
            //磁道密文
            [m_vcom Request_GetDes:0 keyIndex:1 random:myRandom randomLen:myRandomLen time:60];
            
            m_recvData.text = @"cmdindex:11";
            break;
        }
        case 12:
        {
            //得到psam卡号码和硬件序列号
            [m_vcom Request_GetExtKsn];
            m_recvData.text = @"cmdindex:12";
            break;
        }
        case 13:
        {
            //扩展请求连续操作
            
            
            NSString *appendData = @"499000032000151413";
            char appendDataChar[100];
            strcpy(appendDataChar,(char*)[appendData UTF8String]);
            int appendlen =[appendData length];
            NSLog(@"appendlen %d",appendlen);
            
            [m_vcom Request_ExtCtrlConOper:1 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:0x1f ParameterRandom:myRandom ParameterRandomLen:myRandomLen cash:"100" cashLen:3 appendData:nil appendDataLen:0 time:30];
            
            m_recvData.text = @"cmdindex:13";
            break;
        }
        case 14:
        {
            //获取随机数
            [m_vcom Request_GetRandom:8];
            m_recvData.text = @"cmdindex:14";
            break;
        }
        case 15:
        {
            //获取设备KSN号和硬件版本信息
            [m_vcom Request_GetKsn];
            m_recvData.text = @"cmdindex:15";
            break;
        }
        case 16:
        {
            //获取计算mac的数据
            NSString *str = @"1990050000000000100000011719241217313233343531323334353834";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = [str length]/2;
            NSLog(@"数据长度%i",datalen);
            char data[datalen];
            memcpy(data, temp, datalen);
            [m_vcom Request_GetMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen];
            m_recvData.text = @"cmdindex:16";
            break;
        }
        case 17:
        {
            // 回显
            [m_vcom display:@"交易成功" timer:15];
            m_recvData.text = @"cmdindex:17";
            break;
        }
        case 18:
        {
            //请求mac
            char data[17]={0};
            // 请求计算mac的数据 mab
            strcpy(data,"12345678");
            
            [m_vcom Request_CheckMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:8];
            m_recvData.text = @"cmdindex:18";
            break;
        }
        case 19:
        {
            //打印数据
            char pdata[180];
            pdata[0]=1;
            pdata[1]=00;
            pdata[2]=180;
            for(int i=3;i<183;){
                pdata[i++]='1';
                pdata[i++]='2';
                pdata[i++]='3';
            }
            
            [m_vcom Request_PrtData:1 totalPackage:1 count:1 data:pdata dataLen:183];
            m_recvData.text = @"cmdindex:19";
            break;
        }
        case 20:
        {
//            char *test[]={"11            掌富通",
//                "11商户存根              请妥善保管",
//                "12持卡人存根          请妥善保管",
//                "00商户名称（MERCHANT NAME:)",
//                "00  全聚德大烤鸭大烤鸭",
//                "00商户号（MERCHANT NO.)",
//                "00   500000000022697",
//                "00终端号(TERMINAL NO.):30022784",
//                "00卡号(CARD NO.):",
//                "00    6013 82** ***3 350",
//                "00交易类型(TRANS TYPE):",
//                "00    消费/SALE(S)",
//                "00授权号(AUTH NO.): ",
//                "00参考号(REFER NO.):100006162843",
//                "00批次号(BATCH NO.):000001",
//                "00凭证号(VOUCHER NO.):000009",
//                "00交易日期(DATE):2014年03月04日",
//                "00交易时间(TIME):17:46:49",
//                "00操作员号(OPERATOR NO.):01",
//                "00",
//                "00金额(AMOUNT):RMB 0.01",
//                "00备注(REFERENCE):补打小票",
//                "21持卡人签名(SIGNATURE):",
//                "00本人确认以上交易，同意将其计入本卡账户",
//                "00--------------------------------",
//                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
//                "00--------------------------------",
//                "22"};
            
            char *test[]={"11            POS签购单",
                "11商户存根              请妥善保管",
                "12持卡人存根           请妥善保管",
                "00商户名称（MERCHANT NAME):\n柳州旺富家百货超市",////"柳州旺富家百货超市"
                "00商户号（MERCHANT NO.):\n826391045118696",
                "00终端号(TERMINAL NO.):\nW2054531",
                "00操作员号(OPERATOR NO.):01",
                "00------------------------------",
                "00发卡行(ISSUER):\n",
                "00收单行(ACQ):\n48264000",
                "00卡号(CARD NO.):\n520152******4119",
                "00交易类型(TRANS TYPE): \n",
                "00批次号(BATCH NO.):000001",
                "00凭证号(VOUCHER NO.):000196",
                //				"00授权号(AUTH NO.):"+"",
                "00日期/时间(DATE/TIME):",
                "002015-04-05 12:49:43",
                "00参考号(REFER NO.):146183024097",
                "00金额(AMOUNT):",
                "00RMB:200.00",
                "00------------------------------",
                "00备注(REFERENCE):",
                "21持卡人签名(SIGNATURE):",
                "00本人确认以上交易，同意将其计入本卡账户",
                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
                "00------------------------------",
                "22"};
            
            //第二份的落款};//第二份的落款//通讯模式变化
            int i;
            NSMutableArray* na=[[NSMutableArray alloc] init];
            //printf("print cnt=%ld\n",sizeof(test)/sizeof(char *));
            for(i=0;i<sizeof(test)/sizeof(char *);i++){
                [na addObject:[NSString stringWithUTF8String:test[i]]];
            }
            NSLog(@"na is %@", na);
            [m_vcom rmPrint3:na pCnt:1 pakLen:1000];
            m_recvData.text = @"cmdindex:20";
            break;
        }
        case 21:
        {
            //请求输入
            [m_vcom Get_Userinput:0x01 timeout:60 min:2 max:6 keyindex:0 random:"1234567812345678" randomLen:16 title:"abc" titleLen:3];
            m_recvData.text = @"cmdindex:21";
            break;
        }
        case 22:
        {
            //显示信息
            [m_vcom display:@"Demo Test" timer:10];
            m_recvData.text = @"cmdindex:22";
            break;
        }
        case 23:
        {
            char data[17]={0};
            char macv[8] ={0};
            // 原始请求的数据 mab + mac
            strcpy(data,"12345678");
            // 一下为Request_CheckMac 请求得到的mac值，请根据自己情况修改
            data[8]=0x35;
            data[9]=0x37;
            data[10]=0x32;
            data[11]=0x42;
            data[12]=0x45;
            data[13]=0x45;
            data[14]=0x32;
            data[15]=0x38;
            
            macv[0] = 0x11;
            macv[1] = 0xee;
            macv[2] = 0xf2;
            macv[3] = 0x70;
            macv[4] = 0xa6;
            macv[5] = 0x15;
            macv[6] = 0x68;
            macv[7] = 0x36;
            [m_vcom Request_CheckMacEx:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:16 mac:macv maclen:8];
            m_recvData.text = @"cmdindex:23";
            break;
        }
        case 24:
        {   //打印
            NSLog(@"打印");
            //            char *test[]={"11    掌富通\n商户存根            请妥善保管",
            //            "12    商户名称：银盛科技惠州办事处\n商户存根            请妥善保管",
            //            "13    商户名称：银盛科技惠州办事处\n商户存根            请妥善保管",
            //            "00-------------------------------",
            //            "00商户名称（MERCHANT NAME:)",
            //            "全聚德大烤鸭全聚德大烤鸭",
            //            "00商户号（MERCHANT NO.)",
            //            "500000000022697",
            //            "00终端号(TERMINAL NO.):30022784,",
            //            "00卡号 (CARD NO)",
            //            "00622559******4066",
            //            "00交易类型 (TRANS TYPE):\n消费",
            //            "00授权号(AUTH NO.): ,",
            //            "00参考号(REFER NO.):100006162843,",
            //            "00批次号(BATCH NO.):000001,",
            //            "00凭证号(VOUCHER NO.):000009,",
            //            "00交易日期(DATE):2014年03月04日,",
            //            "00交易时间(TIME):17:46:49,",
            //            "00操作员号(OPERATOR NO.):01,\n",
            //            "金额(AMOUNT):RMB 0.01,",
            //            "00备注 (REFERENCE):补打小票,",
            //            "21持卡人签名(SIGNATURE):",
            //            "本人确认以上交易，同意将其计入本卡账户",
            //            "I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
            //                "23"};
            
            
//            char *test[]={"11      SmartPOS 特约商户 商户存根             请妥善保管",
//                "12    SmartPOS 特约商户 持卡人存根           请妥善保管",
//                "00商户编号 708392",
//                "00发卡行 建设银行",
//                "00卡号 622700******9400",
//                "00交易类型 撤销",
//                "00交易时间 09-09 14:46:38",
//                "00参考号 000000471899",
//                "00交易金额 ￥ 0.12",
//                "00原参考号 471898",
//                "00原交易日期 2014-09-09 14:43:01",
//                "00备注: 手机APP""招财进宝""回报大余额宝百分之20，网址：8.shengpay.com",
//                "21持卡人签名                                                                                                                             本人确认以上交易，同意将其计入本卡账户"
//                ,
//                "22"};
            char *test[]={"11            POS签购单",
                "11商户存根              请妥善保管",
                "12持卡人存根           请妥善保管",
                "00商户名称（MERCHANT NAME):\n柳州旺富家百货超市",////"柳州旺富家百货超市"
                "00商户号（MERCHANT NO.):\n826391045118696",
                "00终端号(TERMINAL NO.):\nW2054531",
                "00操作员号(OPERATOR NO.):01",
                "00------------------------------",
                "00发卡行(ISSUER):\n",
                "00收单行(ACQ):\n48264000",
                "00卡号(CARD NO.):\n520152******4119",
                "00交易类型(TRANS TYPE): \n",
                "00批次号(BATCH NO.):000001",
                "00凭证号(VOUCHER NO.):000196",
                //				"00授权号(AUTH NO.):"+"",
                "00日期/时间(DATE/TIME):",
                "002015-04-05 12:49:43",
                "00参考号(REFER NO.):146183024097",
                "00金额(AMOUNT):",
                "00RMB:200.00",
                "00------------------------------",
                "00备注(REFERENCE):",
                "21持卡人签名(SIGNATURE):",
                "00本人确认以上交易，同意将其计入本卡账户",
                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
                "00------------------------------",
                "22"};
            int i;
            NSMutableArray* na=[[NSMutableArray alloc] init];
            printf("print cnt=%ld\n",sizeof(test)/sizeof(char *));
            for(i=0;i<sizeof(test)/sizeof(char *);i++){
                [na addObject:[NSString stringWithUTF8String:test[i]]];
            }
            [m_vcom rmPrint3:na pCnt:1 pakLen:400];
            
            /////Users/mymacpro/Documents/艾创程序/SDK(2014.7.3)/StbITronSDKForClient140703/Demo/ViewController.mm
//libvoclib.a/////
            /* NSMutableArray *test=[[NSMutableArray alloc]initWithObjects:nil];
             NSArray *valueArr =[[NSArray alloc] initWithObjects:@"111merchantName", @"merchantNo", @"111terminalNo", @"111operator", @"111acquirer", @"111acquirer", @"111", @"111merchantName", @"111merchantName", @"111merchantName", @"111merchantName", @"111merchantName", @"111merchantName", nil];
             NSArray *keyArr = [[NSArray alloc] initWithObjects:@"merchantName",@"merchantNo",@"terminalNo",@"operator",@"acquirer",@"expDate",@"cardNo",@"transType",@"voucherNo",@"authNo",@"referNO",@"dateTime", @"amount",nil];
             NSDictionary *dic = [[NSDictionary  alloc] initWithObjects:valueArr forKeys:keyArr];
             [test addObject:@"00           POS签购单            "];
             [test addObject:@"00==============================="];
             [test addObject:[NSString stringWithFormat:@"00商户名称(MERCHANT NAME):\n%@",[dic objectForKey:@"merchantName"]]];
             [test addObject:[NSString stringWithFormat:@"00商户编号(MERCHANT NO):%@",[dic objectForKey:@"merchantNo"]]];
             [test addObject:[NSString stringWithFormat:@"00终端编号(TERMINAL NO):%@",[dic objectForKey:@"terminalNo"]]];
             [test addObject:[NSString stringWithFormat:@"00操作员号(OPERATOR NO):%@",[dic objectForKey:@"operator"]]];
             [test addObject:[NSString stringWithFormat:@"00发卡｀(ISSUER):%@",[dic objectForKey:@"issuer"]]];
             [test addObject:[NSString stringWithFormat:@"00收单行(ACQUIRER):%@",[dic objectForKey:@"acquirer"]]];
             [test addObject:[NSString stringWithFormat:@"00有效期(EXP DATE):%@",[dic objectForKey:@"expDate"]]];
             [test addObject:[NSString stringWithFormat:@"00卡号(CARD NO):  \n%@",[dic objectForKey:@"cardNo"]]];
             [test addObject:[NSString stringWithFormat:@"00交易类型(TRANS TYPE):  \n%@",[dic objectForKey:@"transType"]]];
             [test addObject:[NSString stringWithFormat:@"00批次号(BATCH NO):  \n%@",@"batchNo"]];
             [test addObject:[NSString stringWithFormat:@"00凭证号(VOUCHER NO):%@",[dic objectForKey:@"voucherNo"]]];
             [test addObject:[NSString stringWithFormat:@"00授权码(AUTH NO):%@",[dic objectForKey:@"authNo"]]];
             [test addObject:[NSString stringWithFormat:@"00参考号(REFER NO):%@",[dic objectForKey:@"referNO"]]];
             [test addObject:[NSString stringWithFormat:@"00日期时间(DATE TIME):  \n%@",[dic objectForKey:@"dateTime"]]];
             [test addObject:[NSString stringWithFormat:@"00金额(AMOUNT):      \n%@",[dic objectForKey:@"amount"]]];
             [test addObject:[NSString stringWithFormat:@"00备注(REFERENCE):      "]];
             [test addObject: @"21持卡人签名:\n\n\n商户存根\n- - - - - 由此线撕开 - - - - - -"] ;
             [test addObject: @"22持卡人存根\n- - - - - 由此线撕开 - - - - - -"] ;
             printf("发送指令-test完成\n");
             NSLog(@"test:>>>>>>>>%@",test);
             
             
             [m_vcom rmPrint3:test pCnt:1 pakLen:1000];
             m_recvData.text = @"cmdindex:24";*/
            break;
        }
        case 25:
        {
            //联动优势
            NSString* param = @"6D894CB8B15D89111F017515A7EC6AC39E689758FE635B90ACAEFDB16FB13B818330D3EB2C2507F3D72DC0CB9F75835F";
            NSString* pinKey = [param substringToIndex:40];
            NSString* macKey = [param substringWithRange:NSMakeRange(48,40)];
            char pin[100],mac[100],des[100];
            pin[0]=0;
            mac[0]=0;
            des[0]=0;
            strcpy(pin,HexToBin((char*)[pinKey UTF8String]));
            strcpy(mac,HexToBin((char*)[macKey UTF8String]));
            //strcpy(des,HexToBin("EEEF67F48C60D08DADF6F64BE8DD9FD3ABF2F240"));
            
            [m_vcom Request_ReNewKey:0 PinKey:pin PinKeyLen:20
                              MacKey:mac MacKeyLen:20
                              DesKey:pin DesKeyLen:20];
            
            break;
            
        }
        case 26:
        {
            // 请求的MAB
            NSString *str = @"20031000102106222003100010210622112233";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = [str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            
            [m_vcom Request_GetMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen];
            m_recvData.text = @"cmdindex:26";
            break;
        }
        case 27:
        {
            char mm[8];
            
            // MAB
            NSString *str = @"20031000102106222003100010210622112233";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = (int)[str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            
            //从plist文件中读取mac值
            //获取应用程序沙盒的Documents目录
            NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
            NSString *plistPath = [paths objectAtIndex:0];
            
            //得到完整的文件名
            NSString *filename=[plistPath stringByAppendingPathComponent:@"mac.plist"];
            NSMutableDictionary *macData = [[NSMutableDictionary alloc] initWithContentsOfFile:filename];
            NSString *strmac = [macData objectForKey:@"mac_Value"];
            
            if (NULL==strmac) {
                UIAlertView *macValueAlertView;
                macValueAlertView = [[UIAlertView alloc] initWithTitle:@"校验MAC提示"
                                                               message:@"请在使用校验MAC命令前先获取MAC"
                                                              delegate:nil
                                                     cancelButtonTitle:@"OK"
                                                     otherButtonTitles:nil];
                [macValueAlertView show];
                break;
            }
            // MAC
            //NSString *strmac = @"10a1608c31323334";
            char * tempmac =HexToBin((char *)[strmac UTF8String]);
            memcpy(mm, tempmac, 8);
            
            [m_vcom Request_CheckMac2:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen mac:mm maclen:8];
            m_recvData.text = @"cmdindex:27";
            break;
        }
        case 28:
        {
            // 数据
            char data[16]={0};
            char* st=HexToBin("85e2a87c9ed7a62802a845d65153a020");
            memcpy(data,st,16);
            // 随机数
            char randomdata[8]={0};
            char* st1=HexToBin("303132333435363738");
            memcpy(randomdata,st1,8);
            [m_vcom Request_DataEnc:1 TimeOut:60 Mode:0 ParameterRandom:randomdata ParameterRandomLen:8 data:data dataLen:16];
            m_recvData.text = @"cmdindex:28";
            break;
        }
        case 29:
        {
            //更新终端好和商户号
            [m_vcom Request_ReNewVT:"122010000201" vendorLen:15 terid:"99960000" teridLen:8];
            m_recvData.text = @"cmdindex:29";
            break;
        }
        case 30:
        {
            //转入电子签名页面
            SignViewController *SignVC=[[SignViewController alloc] initWithNibName:@"SignViewController" bundle:nil];
            [self.navigationController pushViewController:SignVC animated:NO];
            
        }
            break;
            
        case 31:
        {
            //查询SDK版本和硬件版本
            NSString * retSDKVerson = [m_vcom GetSDKVerson]; //alex
            m_recvData.text = retSDKVerson;
        }
            break;
            
        case 32:
        {
            ////PSAM卡货IC卡透传指令
            /*
             * PSAM或IC卡透传指令
             * @param mode 卡类型 0 PSAM卡 1 IC卡
             * @param Ordersindex 命令个数
             * @param orders 命令集合 (A命令长度+ A命令内容 + B命令长度 + B命令内容 +C.....)
             * @param OrdersLength 命令的长度
             * @param timer 超时时间
             * @return
             *///commandtest.get_ThroughOrders(3,Util.HexToBin("01310D3000A4040007A0000003330101063000B2010C00"));
            NSString *str = @"01310D3000A4040007A0000003330101063000B2010C00";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = [str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            [m_vcom Request_ThroughOrders:1 OrdersIndex:3 OrdersData:data OrdersLegth:datalen TimeOut:20];
        }
            break;
        default:
            
            break;
    }
    
    [m_vcom StartRec];
    [m_cmdIndex resignFirstResponder];
}

//连续刷卡
- (IBAction)readcardcont:(id)sender{
    
}

- (void)queryReturnData{
    char * retData = [m_vcom GetKsnRetData]; //alex
    //NSLog(@"Return data%s",retData);
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_RECORDDATA object:nil];
    [m_vcom release];
    [m_commStat release];
    [m_lineIn release];
    [m_recvData release];
    [m_cmdIndex release];
    [super dealloc];
}

/***********************************************
 消息通知函数
 ***********************************************/

//通知监听器刷卡器插入手机
-(void) onDevicePlugged
{
    m_lineIn.text=@"耳机插入";
}

//通知监听器刷卡器已从手机拔出
-(void) onDeviceUnPlugged
{
    m_lineIn.text=@"耳机拔出";
}

//通知监听器控制器CSwiperController正在搜索刷卡器
-(void) onWaitingForDevice
{
    
}

//通知监听器没有刷卡器硬件设备
-(void)onNoDeviceDetected
{
    
}

//通知监听器可以进行刷卡动作
-(void)onWaitingForCardSwipe
{
    
}

// 通知监听器检测到刷卡动作
-(void)onCardSwipeDetected
{
    
}

//通知监听器开始解析或读取卡号、磁道等相关信息
-(void)onDecodingStart
{
    
}

-(void)onReturnConfirm
{
    NSLog(@"用户取消");
}

/**
 *	@注释  通知电话中断结束设备准备好了
 */
-(void)onDeviceReady
{
    //NSLog(@"Device Ready");
}


-(void)onError:(int)errorCode andMsg:(NSString*)errorMsg
{
    NSLog(@"error %@",errorMsg);
}

//通知监听器控制器CSwiperController的操作被中断
-(void)onInterrupted
{
    
}

//通知监听器控制器CSwiperController的操作超时
//(超出预定的操作时间，30秒)
-(void)onTimeout
{
    
}


-(void)onDecodeCompleted:(NSString*) formatID
                  andKsn:(NSString*) ksn
            andencTracks:(NSString*) encTracks
         andTrack1Length:(int) track1Length
         andTrack2Length:(int) track2Length
         andTrack3Length:(int) track3Length
         andRandomNumber:(NSString*) randomNumber
            andMaskedPAN:(NSString*) maskedPAN
           andExpiryDate:(NSString*) expiryDate
       andCardHolderName:(NSString*) cardHolderName
                  andMac:(NSString *)mac
        andQTPlayReadBuf:(NSString*) readBuf
{
    
}


//解析卡号、磁道信息等数据出错时，回调此接口
-(void)onDecodeDrror:(int)decodeResult
{
    
}

- (void)onGetKsnCompleted:(NSString *)ksn
{
    
}
//收到数据
//len=-1，data=0表示接收的是错误的数据包
//添加返回信息的方法，更新界面
- (void)dataArrive:(vcom_Result*)vs Status:(int)_status
{
    [m_vcom StopRec];
    //
    if(_status==-3){
        //设备没有响应
        NSLog(@"通信超时");
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"通行超时" waitUntilDone:NO];
        return;
    }else if(_status == -2){
        //耳机没有插入
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"耳机没有插入" waitUntilDone:NO];
        return;
    }else if(_status==-1){
        //接收数据的格式错误
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"接收数据的格式错误" waitUntilDone:NO];
        
    }else {
        if (vs->rescode[0] == 0x0b) {
            NSLog(@"当前为打印指令！");
        }
        //操作指令正确
        if(vs->res==0){
            //设备有成功返回指令
            NSString *succStr = @"";
            NSMutableString *strTemp = [[NSMutableString alloc] initWithCapacity:0];
            //获取psam卡号
            if (vs->psamnoLen>0) {
                NSLog(@"%s", BinToHex(vs->psamno, 0, vs->psamnoLen));
                [strTemp appendString:[NSString stringWithFormat:@"%@\n psamNum:%@", succStr,[m_vcom HexValue:vs->psamno  Len:vs->psamnoLen]]];
            }
            //获取mac
            if (vs->maclen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,mac:%@" , succStr,[m_vcom HexValue:vs->mac Len:vs->maclen]]];
                
            }
            //校验mac
            bool rs = vs->macVerifyResult;
            if (rs == 1) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,校验mac结果: %d", succStr,rs]];
            }
            //打印
            
            //刷卡连续操作
            if(vs->pinEncryptionLen > 0)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n pinEncryption：%@", [m_vcom HexValue:vs->pinEncryption Len:vs->pinEncryptionLen]]];
            }
            ////磁道
            if (vs->trackPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackPlaintext:%@",[m_vcom HexValue:vs->trackPlaintext Len:vs->trackPlaintextLen]]];
                
            }
            if (vs->trackEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackEncryption:%@",[m_vcom HexValue:vs->trackEncryption Len:vs->trackEncryptionLen]]];
                
            }
            if (vs->cardPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardPlaintext:%s", vs->cardPlaintext]];
                
            }
            if (vs->cardEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardEncryption:%@", [m_vcom HexValue:vs->cardEncryption Len:vs->cardEncryptionLen]]];
                
            }
            if (vs->panLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n pan码:%@",[m_vcom HexValue:vs->pan Len:vs->panLen] ]];
            }
            if (vs->hardSerialNoLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n hardNo:%@",[m_vcom HexValue:vs->hardSerialNo Len:vs->hardSerialNoLen] ]];
            }
            if (vs->traderNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n shnoInPsam:%@",[m_vcom HexValue:vs->traderNoInPsam Len:vs->traderNoInPsamLen] ]];
                
            }
            if (vs->termialNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n zdnoInPsam:%@",[m_vcom HexValue:vs->termialNoInPsam Len:vs->termialNoInPsamLen] ]];
                
            }
            if (vs->userInputLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n userInput:%@",[m_vcom HexValue:vs->userInput Len:vs->userInputLen] ]];
            }
            
            if (vs->cdnolen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cdno:%s",vs->cdno]];
                
            }
            if (vs->track2Len > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n Track2:%@",[m_vcom HexValue:vs->Track2 Len:vs->track2Len] ]];
            }
            if (vs->track3Len > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n Track3:%@",[m_vcom HexValue:vs->Track3 Len:vs->track3Len] ]];
            }
            
            if (![strTemp isEqualToString:@""]) {
                [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:strTemp waitUntilDone:NO];
            }
        }else {
            NSLog(@"cmd exec error:%d\n",vs->res);
            switch (vs->res) {
                case 1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"通信超时" waitUntilDone:NO];
                    break;
                case 2:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"PSAM卡认证失败" waitUntilDone:NO];
                    break;
                case 3:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"Psam卡上电失败或者不存在" waitUntilDone:NO];
                    break;
                case 4:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotSupportCmdFormPosToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 10:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"用户退出" waitUntilDone:NO];
                    break;
                case 11:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"MAC校验失败" waitUntilDone:NO];
                    break;
                case 12:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端加密失败" waitUntilDone:NO];
                    break;
                case 14:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"用户按了取消健" waitUntilDone:NO];
                    break;
                case 15:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"Psam卡状态异常" waitUntilDone:NO];
                    break;
                case 0x20:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不匹配的主命令码" waitUntilDone:NO];
                    break;
                case 0x21:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不匹配的子命令码" waitUntilDone:NO];
                    break;
                case 0x42:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"没有打印机" waitUntilDone:NO];
                    break;
                case 0x50:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"获取电池电量失败" waitUntilDone:NO];
                    break;
                case 0x80:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"数据接收正确" waitUntilDone:NO];
                    break;
                    
                case 0x40:
                    [self performSelectorOnMainThread:@selector(refreshStatusNoPaperInPrinterToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xe0:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"重传数据无效" waitUntilDone:NO];
                    break;
                case 0xe1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端设置待机信息失败" waitUntilDone:NO];
                    break;
                case 0xf0:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不识别的包头" waitUntilDone:NO];
                    break;
                case 0xf1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不识别的主命令码" waitUntilDone:NO];
                    break;
                    
                case 0xf2:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotVerifySubCmdToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf3:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"该版本不支持此指令" waitUntilDone:NO];
                    break;
                    
                case 0xf4:
                    [self performSelectorOnMainThread:@selector(refreshStatusRandomLengthErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf5:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不支持的部件" waitUntilDone:NO];
                    break;
                case 0xf6:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不支持的模式" waitUntilDone:NO];
                    break;
                case 0xf7:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataLengthErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                    
                case 0xfc:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataConentErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xfd:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端ID错误" waitUntilDone:NO];
                    break;
                case 0xfe:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"MAC_TK校验失败" waitUntilDone:NO];
                    break;
                case 0xff:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"校验和错误" waitUntilDone:NO];
                    break;
                default:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:[NSString stringWithFormat:@"cmd exec error:%d\n",vs->res] waitUntilDone:NO];
                    break;
            }
            /* 失败和中间状态代码
             01
             命令执行超时
             02
             PSAM卡认证失败
             03
             Psam卡上电失败或者不存在
             04
             Psam卡操作失败
             0A
             用户退出
             0B
             MAC校验失败
             0C
             终端加密失败
             0E
             用户按了取消健
             0F
             Psam卡状态异常
             20
             不匹配的主命令码
             21
             不匹配的子命令码
             50
             获取电池电量失败
             80
             数据接收正确
             E0
             重传数据无效
             E1
             终端设置待机信息失败
             F0
             不识别的包头
             F1
             不识别的主命令码
             F2
             不识别的子命令码
             F3
             该版本不支持此指令
             F4
             随机数长度错误
             F5
             不支持的部件
             F6
             不支持的模式
             F7
             数据域长度错误
             FC
             数据域内容有误
             FD
             终端ID错误
             FE
             MAC_TK校验失败
             FF
             校验和错误
             // 打印错误
             PROTOCOL_ERR_PRT_NOPAPER     == 0X40   ;打印机缺纸
             PROTOCOL_ERR_PRT_OFF         == 0X41   ;打印机离线
             PROTOCOL_ERR_PRT_NO          == 0X42   ;没有打印机
             PROTOCOL_ERR_PRT_NOBM        == 0X43  ;没有黑标
             PROTOCOL_ERR_PRT_CLOSE       == 0X44  ;打印机关闭
             PROTOCOL_ERR_PRT_OTHER       == 0X45  ;打印机故障
             */
        }
    }
}
////////////////////////////////////////////////////////
- (void)updateMytextView:(NSString *)string
{
    m_recvData.text = string;
}
//mic插入
-(void) onMicInOut:(int) inout
{
    
}
-(void)viewDidDisappear:(BOOL)animated
{
    [m_vcom close];
}

//关闭按钮
-(IBAction)closesdk:(id)sender
{
    [m_vcom close];
    return;
}

- (void) getPanCallback : (unsigned char)status pan:(unsigned char*)pan panLen:(unsigned char)panLen
{
    
}

//命令字响应部分
-(void)refreshStatusNotSupportCmdFormPosToPhone
{
    self.m_recvData.text = @"刷卡器硬件暂不支持该命令！";
}
-(void)refreshStatusNoReponseFromPosToPhone
{
    self.m_recvData.text = @"命令超时！";
}
-(void)refreshPOSSwipeAction
{
    self.m_recvData.text = @"执行命令成功！";
}

-(void)refreshStatusNotVerifySubCmdToPhone
{
    self.m_recvData.text = @"不识别的子命令码!";
}

-(void)refreshStatusRandomLengthErrToPhone
{
    self.m_recvData.text = @"随机数长度错误!";
}

-(void)refreshStatusNoPaperInPrinterToPhone
{
    self.m_recvData.text = @"打印机缺纸!";
}
-(void)refreshStatusDataLengthErrToPhone
{
    self.m_recvData.text = @"数据域长度错误!";
}
-(void)refreshStatusDataConentErrToPhone
{
    self.m_recvData.text = @"数据域内容错误!";
}

#pragma mark - listMenuPart

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    NSDictionary *options = @{
                              RTFlyoutMenuUIOptionInnerItemSize: [NSValue valueWithCGSize:CGSizeMake(22, 22)],
                              RTFlyoutMenuUIOptionSubItemPaddings: [NSValue valueWithUIEdgeInsets:UIEdgeInsetsMake(10, 15, 10, 15)]
                              };
    RTFlyoutMenu *m = [[RTFlyoutMenu alloc] initWithDelegate:self dataSource:self position:kRTFlyoutMenuPositionTop options:options];
    m.canvasView = self.view;
    
    CGRect mf = m.frame;
    CGRect cf = self.menuContainerView.bounds;
    
    //	center menu in container view
    CGFloat newOriginX = (cf.size.width - mf.size.width) / 2;
    CGFloat newOriginY = (cf.size.height - mf.size.height) / 2;
    if (newOriginX > 0) mf.origin.x = newOriginX;
    if (newOriginY > 0) mf.origin.y = newOriginY;
    m.frame = mf;
    
    //	m.backgroundColor = [UIColor redColor];
    [self.menuContainerView addSubview:m];
    self.flyoutMenu = m;
    
    //	look & feel
    [[RTFlyoutItem appearanceWhenContainedIn:[self.menuContainerView class], nil] setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [[RTFlyoutItem appearanceWhenContainedIn:[self.menuContainerView class], nil] setTitleShadowColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
}

//	fix rotation issues
- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    
    [self recenterFlyoutMenu];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)recenterFlyoutMenu {
    
    CGRect cf = self.menuContainerView.bounds;
    CGRect mf = self.flyoutMenu.frame;
    
    //	center menu in container view
    CGFloat newOriginX = (cf.size.width - mf.size.width) / 2;
    CGFloat newOriginY = (cf.size.height - mf.size.height) / 2;
    if (newOriginX > 0) mf.origin.x = newOriginX;
    if (newOriginY > 0) mf.origin.y = newOriginY;
    
    self.flyoutMenu.frame = mf;
    
    //	TBD: re-position any open submenu
    //	re-add it to title view (because reloadData on FlyoutMenu will remove it
    [self.menuContainerView addSubview:self.flyoutMenu];
}

- (NSString *)stringFromHexString:(NSString *)hexString { //
    
    char *myBuffer = (char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (char)anInt;
    }
    NSString *unicodeString = [NSString stringWithCString:myBuffer encoding:4];
    return unicodeString;
    
    
}

#pragma mark - RTFlyoutMenuDataSource

- (NSUInteger)numberOfMainItemsInFlyoutMenu:(RTFlyoutMenu *)flyoutMenu {
    return [self.mainItems count];
}

- (NSString *)flyoutMenu:(RTFlyoutMenu *)flyoutMenu titleForMainItem:(NSUInteger)mainItemIndex {
    if (mainItemIndex >= [self.mainItems count]) return nil;
    
    return [self.mainItems objectAtIndex:mainItemIndex];
}

- (NSUInteger)flyoutMenu:(RTFlyoutMenu *)flyoutMenu numberOfItemsInSubmenu:(NSUInteger)mainItemIndex {
    if (mainItemIndex >= [self.mainItems count]) return 0;
    
    return [[self.subItems objectAtIndex:mainItemIndex] count];
}

- (NSString *)flyoutMenu:(RTFlyoutMenu *)flyoutMenu titleForSubItem:(NSUInteger)subItemIndex inMainItem:(NSUInteger)mainItemIndex {
    if (mainItemIndex >= [self.mainItems count]) return nil;
    if (subItemIndex >= [[self.subItems objectAtIndex:mainItemIndex] count]) return nil;
    
    return [[self.subItems objectAtIndex:mainItemIndex] objectAtIndex:subItemIndex];
}


#pragma mark - RTFlyoutMenuDelegate

- (void)flyoutMenu:(RTFlyoutMenu *)flyoutMenu didSelectMainItemWithIndex:(NSInteger)index {
    
    
}

- (void)flyoutMenu:(RTFlyoutMenu *)flyoutMenu didSelectSubItemWithIndex:(NSInteger)subIndex mainMenuItemIndex:(NSInteger)mainIndex {
    switch (subIndex) {
        case 0:
            m_cmdIndex.text = @"12";//获取psam卡号和硬件序列号指
            //            m_cmdIndex.text = @"3";//获取终端号商户号指令
            
            break;
        case 1:
            m_cmdIndex.text = @"29";//修改终端号商户号指令
            break;
        case 2:
            m_cmdIndex.text = @"8";//获取卡号指令
            break;
        case 3:
            m_cmdIndex.text = @"11";//获取磁道明文
            break;
        case 4:
            m_cmdIndex.text = @"10";//获取PIN指令
            break;
        case 5:
            m_cmdIndex.text = @"13";//刷卡密码连续指令
            break;
        case 6:
            //m_cmdIndex.text = @"25";//mac计算
            m_cmdIndex.text = @"25";
            
            break;
        case 7:
            m_cmdIndex.text =@"24";
            break;
        case 8://透传
            m_cmdIndex.text = @"32";
        default:
            break;
    }
}

- (void)didReloadFlyoutMenu:(RTFlyoutMenu *)flyoutMenu {
    [self recenterFlyoutMenu];
}

- (void)onError:(int)errorCode ErrorMessage:(NSString *)errorMessage
{
    NSLog(@"%d", errorCode);
}
@end
