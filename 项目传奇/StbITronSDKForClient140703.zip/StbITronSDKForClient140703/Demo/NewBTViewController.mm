
//
//  ViewController.m : implementation of the ViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import "NewBTViewController.h"
#import "SignViewController.h"
#import "RTFlyoutItem.h"


@interface NewBTViewController ()
{
    bool readOldFile;
    NSArray *cmdArr;
    
    UILabel *cmdLab;
    UIButton *sendBtn;
    UIButton *closeBtn;
    UIPickerView *pkView;
    
}

@end

@implementation NewBTViewController

@synthesize m_commStat;
@synthesize m_recvData;
@synthesize m_cmdIndex;
@synthesize m_sdkver;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title =@"蓝牙点付宝音频测试界面";
        self.view.backgroundColor = [UIColor lightGrayColor];
        readOldFile = true;
        myRandom = "12345678";
        myRandomLen = 3;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //	NSString * str = "12345678";
    
    
    
    
    cmdArr = [[NSArray alloc] initWithObjects: @"获取psam卡号", @"修改终端号商户号",@"获取卡号", @"获取磁道密文",@"获取PIN", @"刷卡密码连续指令", @"MAC计算", @"d打印", @"获取终端号商户号", @"透传测试", @"更新工作秘钥", @"ic卡刷卡", @"获取设备类型", @"参数下载", @"脚本回写",nil];
    /****************************************************************************************/
    cmdLab = [[UILabel alloc] initWithFrame:CGRectMake(10, 64+20, 280, 44)];
    cmdLab.text = [cmdArr objectAtIndex:0];
    cmdLab.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:cmdLab];
    [cmdLab release];
    
    CGRect rect = cmdLab.frame;
    sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(200, rect.origin.y+rect.size.height +10, 90, 44)];
    //    sendBtn.backgroundColor = [UIColor colorWithRed:130/255.0f green:158/255.0f blue:210/255.0f alpha:1.0f];
    [sendBtn setBackgroundImage:[UIImage imageNamed:@"bg.png"] forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [sendBtn addTarget:self action:@selector(sendCmd:) forControlEvents:UIControlEventTouchUpInside];
    [sendBtn setTitle:@"发送指令" forState:UIControlStateNormal];
    
    [self.view addSubview:sendBtn];
    [sendBtn release];
    rect = sendBtn.frame;
    closeBtn =[[UIButton alloc] initWithFrame:CGRectMake(200, sendBtn.frame.origin.y+sendBtn.frame.size.height+10, 90, 44)];
    [closeBtn setBackgroundImage:[UIImage imageNamed:@"bg.png"] forState:UIControlStateNormal];
    [closeBtn setTitle:@"退出指令" forState:UIControlStateNormal];
    [closeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [closeBtn addTarget:self action:@selector(closesdk:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:closeBtn];
    [closeBtn release];
    rect = cmdLab.frame;
    m_recvData = [[UITextView alloc] initWithFrame:CGRectMake(rect.origin.x, rect.origin.y+rect.size.height+2, 170, 180)];
    [self.view addSubview:m_recvData];
    [m_recvData release];
    //点击空白处，键盘下落
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapped:)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
    
    pkView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, m_recvData.frame.origin.y+m_recvData.frame.size.height+2, 320, 80)];
    pkView.delegate = self;
    pkView.dataSource = self;
    [self.view addSubview:pkView];
    
    m_cmdIndex = [[UITextField alloc] initWithFrame:CGRectZero];
    [self.view addSubview:m_cmdIndex];
    m_cmdIndex.text = @"12";
    m_cmdIndex.delegate = self;
    /******************************************************************************/
    //初始化对象
    m_vcom = [vcom getInstance];
    [m_vcom open];
    
    m_vcom.eventListener=self;
    //设置数据发送模式和接收模式
    [m_vcom setCommmunicatinMode:BLE_DianFB];
    [m_vcom setVloumn:95];
    [m_vcom setDebug:1];
    [m_vcom setMac:false];
    if ([self hasHeadset]) {
        m_recvData.text = @"耳机插入";
    }else{
        m_recvData.text = @"耳机未插入";
    }
    
}
/////////////////////////////////////////////////
- (void)viewTapped:(id)obj
{
    [m_recvData resignFirstResponder];
}
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [cmdArr count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [cmdArr objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    cmdLab.text = [cmdArr objectAtIndex:row];
    switch (row) {
        case 0:
            m_cmdIndex.text = @"12";//获取psam卡号和硬件序列号
            break;
            
        case 1:
            m_cmdIndex.text = @"29";//修改终端号商户号指令
            break;
        case 2:
            m_cmdIndex.text = @"8";//获取卡号指令
            break;
        case 3:
            m_cmdIndex.text = @"11";//获取磁道明文
            break;
        case 4:
            m_cmdIndex.text = @"10";//获取PIN指令
            break;
        case 5:
            m_cmdIndex.text = @"13";//刷卡密码连续指令
            break;
        case 6:
            m_cmdIndex.text = @"16";//mac计算
            
            break;
        case 7:
            m_cmdIndex.text = @"20";//打印
            break;
        case 8:
            m_cmdIndex.text = @"3";//获取终端号商户号指令
            break;
        case 9://透传测试
            m_cmdIndex.text = @"32";//透传
            break;
        case 10://更新工作秘钥
            m_cmdIndex.text = @"25";//更新工作秘钥
            break;
        case 11:
            m_cmdIndex.text = @"33";//ic卡刷卡
            break;
        case 12:
            m_cmdIndex.text = @"34";//获取设备类型
            break;
        case 13:
            m_cmdIndex.text = @"35";//参数下载
            break;
        case 14:
            m_cmdIndex.text = @"36";//脚本回写
            break;
        default:
            break;
    }
}
/////////////////////////////////////////////////
-(void)switchAction:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    BOOL isButtonOn = [switchButton isOn];
    if (isButtonOn) {
        readOldFile = YES;
    }else {
        readOldFile = NO;
    }
}
//检查micphone状态
- (BOOL)hasHeadset
{
#if TARGET_IPHONE_SIMULATOR
#warning *** Simulator mode: audio session code works only on a device
    return NO;
#else
    CFStringRef route;
    UInt32 propertySize = sizeof(CFStringRef);
    AudioSessionGetProperty(kAudioSessionProperty_AudioRoute, &propertySize, &route);
    if((route == NULL) || (CFStringGetLength(route) == 0))
    {
        // Silent Mode
        //NSLog(@"AudioRoute: SILENT, do nothing!");
    }
    else
    {
        NSString* routeStr = (NSString*)route;
        //NSLog(@"AudioRoute: %@", routeStr);
        
        NSRange headphoneRange = [routeStr rangeOfString : @"Headphone"];
        NSRange headsetRange = [routeStr rangeOfString : @"Headset"];
        if (headphoneRange.location != NSNotFound)
        {
            return YES;
        } else if(headsetRange.location != NSNotFound)
        {
            return YES;
        }
    }
    return NO;
#endif
}

//麦克风是否插入消息函数
- (void)checkmic_event:(NSNotification* )note
{
    int res=[[note object] intValue];
    
    if(res==0)
        m_recvData.text=@"耳机未插入";
    else {
        m_recvData.text=@"耳机插入";
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}
int rcnt1=0;

-(void) doRefresh:(NSString*)str
{
    m_recvData.text=str;
    rcnt1++;
    m_commStat.text=[NSString stringWithFormat:@"RECV:%d",rcnt1];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

void converttogbk1(char* uf8[],int uf8len,char gbk[20][200])
{
    int i;
    NSStringEncoding enc = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    for(i=0;i<uf8len;i++){
        NSString* obj=[NSString stringWithUTF8String:uf8[i]];
        NSData *ele = [obj dataUsingEncoding:enc];
        int elen=[ele length];
        char* pc=(char*)[ele bytes];
        memcpy(gbk[i],pc,elen);
    }
}
//发送指令测试
-(void)sendCmd:(id)sender
{
    sendBtn.userInteractionEnabled = NO;
    m_recvData.text=@"";
    int cmdindex=[m_cmdIndex.text intValue];
    [m_vcom StopRec];
    switch (cmdindex) {
        case 1:
        {
            //获取磁道明文
            [m_vcom Request_GetTrackPlaintext:60];
            //            m_recvData.text = @"cmdindex:1";
            break;
        }
        case 2:
        {
            //获取随机数
            [m_vcom Request_GetRandom:8];
            //            m_recvData.text = @"cmdindex:2";
            break;
        }
        case 3:
        {
            //获取psam卡上保存的商户号码和终端号
            [m_vcom Request_VT];
            //            m_recvData.text = @"cmdindex:3";
            //v3.2psam卡不支持该命令
            break;
        }
        case 4:
        {
            //退出指令
            [m_vcom Request_Exit];
            //            m_recvData.text = @"cmdindex:4";
            break;
        }
        case 5:
        {
            //获取电池电量
            [m_vcom Request_BatLevel];
            //            m_recvData.text = @"cmdindex:5";
            break;
        }
        case 6:
        {
            //获取打印机状态
            [m_vcom Request_PrtState];
            //            m_recvData.text = @"cmdindex:6";
            break;
        }
        case 7:
        {
            //重传指令
            [m_vcom Request_ReTrans];
            //            m_recvData.text = @"cmdindex:7";
            break;
        }
        case 8:
        {
            //获取磁卡卡号明文
            [m_vcom Request_GetCardNo:60];
            //            m_recvData.text = @"cmdindex:8";
            break;
        }
        case 9:
        {
            //获取磁道信息明文
            [m_vcom Request_GetTrackPlaintext:60];
            break;
        }
        case 10:
        {
            //银行卡口令密文
            [m_vcom Request_GetPin:0 keyIndex:0 cash:"12345" cashLen:5 random:myRandom randomLen:myRandomLen panData:"" pandDataLen:0 time:30];
            break;
        }
        case 11:
        {
            //获取磁道密文数据
            [m_vcom Request_GetDes:0 keyIndex:2 random:myRandom randomLen:myRandomLen time:30];
            break;
        }
        case 12:
        {
            //得到psam卡号码和硬件序列号
            [m_vcom Request_GetExtKsn];
            break;
        }
        case 13:
        {
            //扩展请求连续操作
            
            NSString *appendData = @"1990050000000000100000011719241217313233343531323334353834";
            char *appendDataChar = HexToBin((char *)[appendData UTF8String]);
            int appendlen = [appendData length]/2;
            NSLog(@"%d", appendlen);
            char aDataChar[100];
            memcpy(aDataChar, appendDataChar,appendlen);
            NSString *random = @"123456";
            char *numRadom = HexToBin((char *)[random UTF8String]);
            int numRadomLen = (int)[random length] / 2;
            char randomdata[3]={0};
            memcpy(randomdata, numRadom, numRadomLen);
            
            [m_vcom Request_ExtCtrlConOper:1 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:0x1c ParameterRandom:randomdata ParameterRandomLen:numRadomLen cash:"100" cashLen:3 appendData:"" appendDataLen:0 time:10];
            break;
        }
        case 14:
        {
            //获取随机数
            [m_vcom Request_GetRandom:8];
            break;
        }
        case 15:
        {
            //获取设备KSN号 和硬件版本信息
            [m_vcom Request_GetKsn];
            break;
        }
        case 16:
        {
            //获取计算mac的数据
            NSString *str = @"1990050000000000100000011719241217313233343531323334353834";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = [str length]/2;
            NSLog(@"数据长度%i",datalen);
            char data[datalen];
            memcpy(data, temp, datalen);
            [m_vcom Request_GetMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen];
            break;
        }
        case 17:
        {
            // 回显
            [m_vcom display:@"交易成功" timer:15];
            break;
        }
        case 18:
        {
            //请求mac
            char data[17]={0};
            // 请求计算mac的数据 mab
            strcpy(data,"12345678");
            
            [m_vcom Request_CheckMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen  data:data dataLen:8];
            break;
        }
        case 19:
        {
            //打印数据
            char pdata[180];
            pdata[0]=1;
            pdata[1]=00;
            pdata[2]=180;
            for(int i=3;i<183;){
                pdata[i++]='1';
                pdata[i++]='2';
                pdata[i++]='3';
            }
            
            [m_vcom Request_PrtData:1 totalPackage:1 count:1 data:pdata dataLen:183];
            break;
        }
        case 20:
        {
            //            char* test2[]={"11      商户名称：盛付通\n商户存根            请妥善保管\n", //第一份的标题
            //                "12    商户名称：盛付通切客\n持卡人存根             请妥善保管\n", //第二份的标题
            //                "00商户编号（MERCHAANT NO） 123456",
            //                "00发卡行：中国银行",
            //                "00卡号（CARD NO）622209******6620",
            //                "00交易类型（TRANS TYPE）",
            //                "00    消费（SALE）",
            //
            //                "00交易时间（DATE/TIME）",
            //                "00    2012/12/02   19:05:26",
            //                "00参考号（REFERENCE NO）P000000000324",
            //                "00交易金额（RMB）￥ 200.00",
            //                "00交易金额：1000.00元",
            //                "00备注（REFERENCE）：",
            //                "21持卡人签名\n\n\n\n\n\n\n本人确认以上交易，同意将其计入本卡账户\nI ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",              //第一份的落款
            //
            //                "21持卡人签名\n\n\n\n\n\n\n本人确认以上交易，同意将其计入本卡账户\nI ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",              //第一份的落款
            //                "22"};//第二份的落款};//第二份的落款//通讯模式变化
            //            char* test[] = {
            //				"11      商户名称：盛付通\n商户存根            请妥善保管\n", // 第一份的标题
            //				"12    商户名称：盛付通切客\n持卡人存根             请妥善保管\n", // 第二份的标题
            //				"00商户编号（MERCHAANT NO） 123456",
            //				"00终端编号（TERMINAL NO） 123456",
            //				"00发卡行：中国银行",
            //				"00卡号（CARD NO）622209******6620",
            //				"00交易类型（TRANS TYPE）",
            //				"00    消费（SALE）",
            //				"00交易时间（DATE/TIME）",
            //				"00    2012/12/02   19:05:26",
            //				"00参考号（REFERENCE NO）P000000000324",
            //				"00交易金额（RMB）￥ 200.00",
            //				"00交易金额：1000.00元",
            //				"00备注（REFERENCE）：",
            //
            //				"00交易时间（DATE/TIME）",
            //				"00    2012/12/02   19:05:26",
            //				"00参考号（REFERENCE NO）P000000000324",
            //				"00交易金额（RMB）￥ 200.00",
            //				"00交易金额：1000.00元",
            //				"00备注（REFERENCE）：",
            //
            //				"21持卡人签名\n\n\n\n\n\n\n本人确认以上交易，同意将其计入本卡账户\nI ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES", // 第一份的落款
            //				"22",// 第二份的落款
            //            };
            //
            //            int i;
            //            NSMutableArray* na=[[NSMutableArray alloc] init];
            //            //printf("print cnt=%ld\n",sizeof(test)/sizeof(char *));
            //            for(i=0;i<sizeof(test)/sizeof(char *);i++){
            //                [na addObject:[NSString stringWithUTF8String:test[i]]];
            //            }
            //            NSLog(@"na is %@", na);
            
            NSString *appName = @"yft";//[dict objectForKey:@"app_name"];
            NSString *memberNo = @"15957120196";//[dict objectForKey:@"memberNo"];
            NSString *termNo = @"12345673";//[dict objectForKey:@"termNo"];
            NSString *cardNo = @"12345678";//[dict objectForKey:@"cardNo"];
            NSString *date = @"2014-7-29 17:24";//[dict objectForKey:@"date"];
            NSString *order = @"123455678889";//[dict objectForKey:@"order"];
            NSString *money = @"123";//[dict objectForKey:@"money"];
            NSString *reason = @"";//[dict objectForKey:@"reason"];
            
            
            NSMutableArray *test=[[NSMutableArray alloc]initWithObjects:nil];
            
            [test addObject:[NSString stringWithFormat:@"11%@\n\n商户存根            请妥善保管",appName]];
            [test addObject:[NSString stringWithFormat:@"00商户编号（MERCHAANT NO）：\n%@",memberNo]];
            [test addObject:[NSString stringWithFormat:@"00终端编号（TERMINAL NO）：\n%@",termNo]];
            [test addObject:[NSString stringWithFormat:@"00卡号（CARD NUMBER）：\n%@",cardNo]];
            [test addObject:[NSString stringWithFormat:@"00交易类型（TRANS TYPE）：\n    消费（SALE）"]];
            [test addObject:[NSString stringWithFormat:@"00交易时间（DATE/TIME）：\n    %@",date]];
            [test addObject:[NSString stringWithFormat:@"00流水号（TRADE NO）：\n%@",order]];
            [test addObject:[NSString stringWithFormat:@"00交易金额（AMOUNT）： RMB %@",money]];
            [test addObject:[NSString stringWithFormat:@"00备注（REFERENCE）：%@",reason]];
            [test addObject: @"21持卡人签名（SIGNATURE）：\n\n\n\n\n\n\n本人确认以上交易，同意将其计入本卡账户\nI ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES\n- - - - - 由此线撕开 - - - - - -\n\n"] ;
            
            [test addObject:[NSString stringWithFormat:@"12%@\n\n持卡人存根            请妥善保管",appName]];
            [test addObject:[NSString stringWithFormat:@"00商户编号（MERCHAANT NO）：\n%@",memberNo]];
            [test addObject:[NSString stringWithFormat:@"00终端编号（TERMINAL NO）：\n%@",termNo]];
            [test addObject:[NSString stringWithFormat:@"00卡号（CARD NUMBER）：\n%@",cardNo]];
            [test addObject:[NSString stringWithFormat:@"00交易类型（TRANS TYPE）：\n    消费（SALE）"]];
            [test addObject:[NSString stringWithFormat:@"00交易时间（DATE/TIME）：\n    %@",date]];
            [test addObject:[NSString stringWithFormat:@"00流水号（TRADE NO）：\n%@",order]];
            [test addObject:[NSString stringWithFormat:@"00交易金额（AMOUNT）： RMB %@",money]];
            [test addObject:[NSString stringWithFormat:@"00备注（REFERENCE）：%@",reason]];
            [test addObject: @"\n- - - - - 由此线撕开 - - - - - -"];
            printf("发送指令-test完成\n");
            NSLog(@"test:>>>>>>>>%@",test);
            //            [cmManager rmPrint3:test pCnt:1 pakLen:1000];
            [m_vcom rmPrint3:test pCnt:1 pakLen:1000];
        }
            break;
            
        case 21:
        {
            //请求输入
            [m_vcom Get_Userinput:0x01 timeout:60 min:2 max:6 keyindex:0 random:myRandom randomLen:myRandomLen title:"abc" titleLen:3];
        }
            break;
            
        case 22:
        {
            //显示信息
            [m_vcom display:@"Demo Test" timer:10];
            break;
        }
        case 23:
        {
            char data[17]={0};
            char macv[8] ={0};
            // 原始请求的数据 mab + mac
            strcpy(data,"12345678");
            // 一下为Request_CheckMac 请求得到的mac值，请根据自己情况修改
            data[8]=0x35;
            data[9]=0x37;
            data[10]=0x32;
            data[11]=0x42;
            data[12]=0x45;
            data[13]=0x45;
            data[14]=0x32;
            data[15]=0x38;
            
            macv[0] = 0x11;
            macv[1] = 0xee;
            macv[2] = 0xf2;
            macv[3] = 0x70;
            macv[4] = 0xa6;
            macv[5] = 0x15;
            macv[6] = 0x68;
            macv[7] = 0x36;
            [m_vcom Request_CheckMacEx:0 keyIndex:1 random:"12345678" randomLen:myRandomLen data:data dataLen:16 mac:macv maclen:8];
            break;
        }
        case 24:
        {   //打印
            NSLog(@"打印");
            //            char *test[]={"11    掌富通\n商户存根            请妥善保管",
            //            "12    商户名称：银盛科技惠州办事处\n商户存根            请妥善保管",
            //            "13    商户名称：银盛科技惠州办事处\n商户存根            请妥善保管",
            //            "00-------------------------------",
            //            "00商户名称（MERCHANT NAME:)",
            //            "全聚德大烤鸭全聚德大烤鸭",
            //            "00商户号（MERCHANT NO.)",
            //            "500000000022697",
            //            "00终端号(TERMINAL NO.):30022784,",
            //            "00卡号 (CARD NO)",
            //            "00622559******4066",
            //            "00交易类型 (TRANS TYPE):\n消费",
            //            "00授权号(AUTH NO.): ,",
            //            "00参考号(REFER NO.):100006162843,",
            //            "00批次号(BATCH NO.):000001,",
            //            "00凭证号(VOUCHER NO.):000009,",
            //            "00交易日期(DATE):2014年03月04日,",
            //            "00交易时间(TIME):17:46:49,",
            //            "00操作员号(OPERATOR NO.):01,\n",
            //            "金额(AMOUNT):RMB 0.01,",
            //            "00备注 (REFERENCE):补打小票,",
            //            "21持卡人签名(SIGNATURE):",
            //            "本人确认以上交易，同意将其计入本卡账户",
            //            "I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
            //                "23"};
            
            
            //            char *test[]={"11            掌富通",
            //                "11商户存根              请妥善保管",
            //                "12持卡人存根          请妥善保管",
            //                "00商户名称（MERCHANT NAME:)",
            //                "00  全聚德大烤鸭大烤鸭",
            //                "00商户号（MERCHANT NO.)",
            //                "00   500000000022697",
            //                "00终端号(TERMINAL NO.):30022784",
            //                "00卡号(CARD NO.):",
            //                "00    6013 82** ***3 350",
            //                "00交易类型(TRANS TYPE):",
            //                "00    消费/SALE(S)",
            //                "00授权号(AUTH NO.): ",
            //                "00参考号(REFER NO.):100006162843",
            //                "00批次号(BATCH NO.):000001",
            //                "00凭证号(VOUCHER NO.):000009",
            //                "00交易日期(DATE):2014年03月04日",
            //                "00交易时间(TIME):17:46:49",
            //                "00操作员号(OPERATOR NO.):01",
            //                "00",
            //                "00金额(AMOUNT):RMB 0.01",
            //                "00备注(REFERENCE):补打小票",
            //                "21持卡人签名(SIGNATURE):",
            //                "00本人确认以上交易，同意将其计入本卡账户",
            //                "00--------------------------------",
            //                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
            //                "00--------------------------------",
            //                "22"};
            char *test[]={"11            掌富通",
                "11商户存根              请妥善保管",
                "12持卡人存根          请妥善保管",
                "00商户名称（MERCHANT NAME:)",
                "00  全聚德大烤鸭大烤鸭",
                "00商户号（MERCHANT NO.)",
                "00   500000000022697",
                "00终端号(TERMINAL NO.):30022784",
                "00卡号(CARD NO.):",
                "00    6013 82** ***3 350",
                "00交易类型(TRANS TYPE):",
                "00    消费/SALE(S)",
                "00授权号(AUTH NO.): ",
                "00参考号(REFER NO.):100006162843",
                "00批次号(BATCH NO.):000001",
                "00凭证号(VOUCHER NO.):000009",
                "00交易日期(DATE):2014年03月04日",
                "00交易时间(TIME):17:46:49",
                "00操作员号(OPERATOR NO.):01",
                "00",
                "00金额(AMOUNT):RMB 0.01",
                "00备注(REFERENCE):补打小票",
                "21持卡人签名(SIGNATURE):",
                "00本人确认以上交易，同意将其计入本卡账户",
                "00--------------------------------",
                "00I ACKNOWLEDGE SATISFACTORY RECEIPT OF RELATIVE GOODS/SERVICES",
                "00--------------------------------",
                "22"};
            
            int i;
            NSMutableArray* na=[[NSMutableArray alloc] init];
            //printf("print cnt=%ld\n",sizeof(test)/sizeof(char *));
            for(i=0;i<sizeof(test)/sizeof(char *);i++){
                [na addObject:[NSString stringWithUTF8String:test[i]]];
            }
            [m_vcom rmPrint3:na pCnt:1 pakLen:400];
            break;
        }
        case 25:
        {
            //联动优势
            NSString *workKey = @"89b07b35a1b3f47e4eb13bf6";
            NSString *pinKey = workKey;
            NSString *macKey = workKey;
            NSString *desKey = workKey;
            char pin[100],mac[100],des[100];
            pin[0]=0;
            mac[0]=0;
            des[0]=0;
            char *tempPin = HexToBin((char*)[pinKey UTF8String]);
            memcpy(pin, tempPin, [pinKey length]/2);//一定要拷贝否则会占用通一块内存
            int len =(int)[pinKey length]/2;
            
            char *tempMac = HexToBin((char*)[macKey UTF8String]);
            memcpy(mac, tempMac, [macKey length]/2);//一定要拷贝否则会占用通一块内存
            char *tempDes = HexToBin((char*)[macKey UTF8String]);
            memcpy(des, tempDes, [desKey length]/2);//一定要拷贝否则会占用通一块内存
            
            //    strcpy(pin,HexToBin11((char*)[pinKey UTF8String]));这是一个重大bug，全面注意。
            //    strcpy(mac,HexToBin11((char*)[macKey UTF8String]));
            //    strcpy(des,HexToBin11((char *)[desKey UTF8String]));
            
            
            [vcom Request_ReNewKey:0 PinKey:pin PinKeyLen:len
                                 MacKey:mac MacKeyLen:len
                                 DesKey:des DesKeyLen:len];
            
            break;
            
        }
        case 26:
        {
            // 请求的MAB
            NSString *str = @"20031000102106222003100010210622112233";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = [str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            
            [m_vcom Request_GetMac:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen];
            break;
        }
        case 27:
        {
            char mm[8];
            
            // MAB
            NSString *str = @"20031000102106222003100010210622112233";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = (int)[str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            
            //从plist文件中读取mac值
            //获取应用程序沙盒的Documents目录
            NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
            NSString *plistPath = [paths objectAtIndex:0];
            
            //得到完整的文件名
            NSString *filename=[plistPath stringByAppendingPathComponent:@"mac.plist"];
            NSMutableDictionary *macData = [[NSMutableDictionary alloc] initWithContentsOfFile:filename];
            NSString *strmac = [macData objectForKey:@"mac_Value"];
            
            if (NULL==strmac) {
                UIAlertView *macValueAlertView;
                macValueAlertView = [[UIAlertView alloc] initWithTitle:@"校验MAC提示"
                                                               message:@"请在使用校验MAC命令前先获取MAC"
                                                              delegate:nil
                                                     cancelButtonTitle:@"OK"
                                                     otherButtonTitles:nil];
                [macValueAlertView show];
                break;
            }
            // MAC
            //NSString *strmac = @"10a1608c31323334";
            char * tempmac =HexToBin((char *)[strmac UTF8String]);
            memcpy(mm, tempmac, 8);
            
            [m_vcom Request_CheckMac2:0 keyIndex:1 random:myRandom randomLen:myRandomLen data:data dataLen:datalen mac:mm maclen:8];
            break;
        }
        case 28:
        {
            // 数据
            char data[16]={0};
            char* st=HexToBin("85e2a87c9ed7a62802a845d65153a020");
            memcpy(data,st,16);
            // 随机数
            char randomdata[8]={0};
            char* st1=HexToBin("303132333435363738");
            memcpy(randomdata,st1,8);
            [m_vcom Request_DataEnc:1 TimeOut:60 Mode:0 ParameterRandom:randomdata ParameterRandomLen:8 data:data dataLen:16];
            break;
        }
        case 29:
        {
            //更新终端好和商户号
            [m_vcom Request_ReNewVT:"122010000201" vendorLen:15 terid:"99960000" teridLen:8];
            break;
        }
        case 30:
        {
            //转入电子签名页面
            SignViewController *SignVC=[[SignViewController alloc] initWithNibName:@"SignViewController" bundle:nil];
            [self.navigationController pushViewController:SignVC animated:NO];
            
            break;
        }
        case 31:
        {
            //查询SDK版本和硬件版本
            NSString * retSDKVerson = [m_vcom GetSDKVerson]; //alex
            break;
        }
        case 32:
        {
            ////PSAM卡货IC卡透传指令
            /*
             * PSAM或IC卡透传指令
             * @param mode 卡类型 0 PSAM卡 1 IC卡
             * @param Ordersindex 命令个数
             * @param orders 命令集合 (A命令长度+ A命令内容 + B命令长度 + B命令内容 +C.....)
             * @param OrdersLength 命令的长度
             * @param timer 超时时间
             * @return
             *///commandtest.get_ThroughOrders(3,Util.HexToBin("01310D3000A4040007A0000003330101063000B2010C00"));
            NSString *str = @"01310D3000A4040007A0000003330101063000B2010C00";
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = [str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            [m_vcom Request_ThroughOrders:1 OrdersIndex:3 OrdersData:data OrdersLegth:datalen TimeOut:20];
        }
        case 33:{//ic卡刷卡
            //ic卡刷卡命令
            
            NSString *str = @"123456";
            char *temp = HexToBin((char *)[str UTF8String]);
            char rom[100];
            memcpy(rom, temp, [str length]/2);//一定要拷贝否则会占用通一块内存
            
            
            NSString *appendData = @"0000000000000000";
            char *temp1 = HexToBin((char*)[appendData UTF8String]);
            char appendDataChar[100];
            memcpy(appendDataChar, temp1, [appendData length]/2);//一定要拷贝否则会占用通一块内存
            int appendlen =[appendData length]/2;
            
            NSString *cash = @"0";
            int cashLen = [cash length];
            char cData[100];
            cData[0] = 0;
            strcpy(cData,((char*)[cash UTF8String]));
            
            Transactioninfo *tranInfo = [[Transactioninfo alloc] init];
            NSString *ctrm = @"223B0300";
            char *temp2 = HexToBin((char*)[ctrm UTF8String]);
            char ctr[4];
            memcpy(ctr, temp2, [ctrm length]/2);
            
            [m_vcom stat_EmvSwiper:1 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:ctr ParameterRandom:"123" ParameterRandomLen:0 cash:cData cashLen:cashLen appendData:"" appendDataLen:0 time:30 Transactioninfo:tranInfo];
            
        }
            break;
        case 34:{//获取设备类型
            [m_vcom getTerminalType];
            
        }
            break;
        case 35:{//参数下载
            NSString *str = @"319F0605A0000000049F220106DF05083230323331323331DF060101DF070101DF0281F8CB26FC830B43785B2BCE37C81ED334622F9622F4C89AAE641046B2353433883F307FB7C974162DA72F7A4EC75D9D657336865B8D3023D3D645667625C9A07A6B7A137CF0C64198AE38FC238006FB2603F41F4F3BB9DA1347270F2F5D8C606E420958C5F7D50A71DE30142F70DE468889B5E3A08695B938A50FC980393A9CBCE44AD2D64F630BB33AD3F5F5FD495D31F37818C1D94071342E07F1BEC2194F6035BA5DED3936500EB82DFDA6E8AFB655B1EF3D0D7EBF86B66DD9F29F6B1D324FE8B26CE38AB2013DD13F611E7A594D675C4432350EA244CC34F3873";
            
            NSString *str1 = @"319F0608A000000333010102DF0101009F08020030DF1105D84000A800DF1205D84004F800DF130500100000009F1B0400002710DF150400000000DF160100DF170100DF14039F3704DF1801019F7B06000000080000DF1906000000050000DF2006000000100000DF2106000000010000";
            char * temp=HexToBin((char *)[str1 UTF8String]);
            int datalen = (int)[str1 length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            //        [m_vcom UpdateTerminalParameters:0 pageNum:pageNum++ data:data dataLen:datalen time:6];
            [m_vcom UpdateTerminalParameters:1 pageNum:1 data:data dataLen:datalen time:6];
            
        }
            break;
        case 36:{//脚本回写
            
            NSString *str =@"9F2608BEC5FDD8569CED7C9F2701809F101307020103A02002010A010000000000424E87069F37044C24C2199F360200149505000004E8009A031409189C01009F02060000000060005F2A02015682027C009F1A0201569F03060000000000009F3303E0E1C89F34034203009F3501229F1E0830303030303030318408A0000003330101029F090200209F4104000000029F631030313035303030300000000000000000";
            
            char * temp=HexToBin((char *)[str UTF8String]);
            int datalen = (int)[str length]/2;
            char data[datalen];
            memcpy(data, temp, datalen);
            
            NSString *resCode = @"00";
            char * temp1=(char *)[resCode UTF8String];
            int datalen1 = (int)[resCode length]/2;
            char resData[datalen1];
            memcpy(resData, temp1, datalen1);
            
            [m_vcom secondIssuance:resData data:data dataLength:datalen+datalen1 time:10];
        }
            break;
        default:
            break;
    }
    
    [m_vcom StartRec];
    [m_cmdIndex resignFirstResponder];
}

//连续刷卡
- (void)readcardcont:(id)sender{
    
}

- (void)queryReturnData{
    char * retData = [m_vcom GetKsnRetData]; //alex
    //NSLog(@"Return data%s",retData);
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NOTIFY_RECORDDATA object:nil];
    [m_vcom release];
    [m_commStat release];
    [m_recvData release];
    [m_cmdIndex release];
    [super dealloc];
}

/***********************************************
 消息通知函数
 ***********************************************/

//通知监听器刷卡器插入手机
-(void) onDevicePlugged
{
    m_recvData.text=@"耳机插入";
}

//通知监听器刷卡器已从手机拔出
-(void) onDeviceUnPlugged
{
    m_recvData.text=@"耳机拔出";
}

//通知监听器控制器CSwiperController正在搜索刷卡器
-(void) onWaitingForDevice
{
    
}

//通知监听器没有刷卡器硬件设备
-(void)onNoDeviceDetected
{
    
}

//通知监听器可以进行刷卡动作
-(void)onWaitingForCardSwipe
{
    
}

// 通知监听器检测到刷卡动作
-(void)onCardSwipeDetected
{
    
}

//通知监听器开始解析或读取卡号、磁道等相关信息
-(void)onDecodingStart
{
    
}

-(void)onReturnConfirm
{
    NSLog(@"用户取消");
}

/**
 *	@注释  通知电话中断结束设备准备好了
 */
-(void)onDeviceReady
{
    //NSLog(@"Device Ready");
}


-(void)onError:(int)errorCode andMsg:(NSString*)errorMsg
{
    NSLog(@"error %@",errorMsg);
}

//通知监听器控制器CSwiperController的操作被中断
-(void)onInterrupted
{
    
}

//通知监听器控制器CSwiperController的操作超时
//(超出预定的操作时间，30秒)
-(void)onTimeout
{
    [sendBtn setUserInteractionEnabled:YES];
    m_recvData.text = @"通信超时";
    
}


-(void)onDecodeCompleted:(NSString*) formatID
                  andKsn:(NSString*) ksn
            andencTracks:(NSString*) encTracks
         andTrack1Length:(int) track1Length
         andTrack2Length:(int) track2Length
         andTrack3Length:(int) track3Length
         andRandomNumber:(NSString*) randomNumber
            andMaskedPAN:(NSString*) maskedPAN
           andExpiryDate:(NSString*) expiryDate
       andCardHolderName:(NSString*) cardHolderName
                  andMac:(NSString *)mac
        andQTPlayReadBuf:(NSString*) readBuf
{
}


//解析卡号、磁道信息等数据出错时，回调此接口
-(void)onDecodeDrror:(int)decodeResult
{
    
}

- (void)onGetKsnCompleted:(NSString *)ksn
{
    
}
//收到数据
//len=-1，data=0表示接收的是错误的数据包
//添加返回信息的方法，更新界面
- (void)dataArrive:(vcom_Result*)vs Status:(int)_status
{
    
    [m_vcom StopRec];
    if(_status==-3){
        //设备没有响应
        NSLog(@"通信超时");
        sendBtn.userInteractionEnabled = YES;
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"通行超时" waitUntilDone:NO];
        return;
    }else if(_status == -2){
        //耳机没有插入
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"耳机没有插入" waitUntilDone:NO];
        return;
    }else if(_status==-1){
        //接收数据的格式错误
        [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"接收数据的格式错误" waitUntilDone:NO];
        
    }else {
        //操作指令正确
        if(vs->res==0){
            //设备有成功返回指令
            NSString *succStr = @"";
            NSMutableString *strTemp = [[NSMutableString alloc] initWithCapacity:0];
            //获取psam卡号
            if (vs->psamnoLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n psamNum:%s", succStr,vs->psamno]];
            }
            //获取mac结果
            if (vs->maclen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,mac:%@" , succStr,[m_vcom HexValue:vs->mac Len:vs->maclen]]];
                
            }
            //校验mac
            bool rs = vs->macVerifyResult;
            if (rs == 1) {
                [strTemp appendString:[NSString stringWithFormat:@"%@\n,校验mac结果: %d", succStr,rs]];
            }
            //打印
            
            //刷卡连续操作
            if(vs->pinEncryptionLen > 0)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n pinEncryption：%@", [m_vcom HexValue:vs->pinEncryption Len:vs->pinEncryptionLen]]];
            }
            ////磁道
            if (vs->trackPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackPlaintext:%@",[m_vcom HexValue:vs->trackPlaintext Len:vs->trackPlaintextLen]]];
                
            }
            if (vs->trackEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n trackEncryption:%@",[m_vcom HexValue:vs->trackEncryption Len:vs->trackEncryptionLen]]];
                
            }
            if (vs->cardPlaintextLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardPlaintext:%@", [m_vcom HexValue:vs->cardPlaintext Len:vs->cardPlaintextLen]]];
                
            }
            if (vs->cardEncryptionLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cardEncryption:%@", [m_vcom HexValue:vs->cardEncryption Len:vs->cardEncryptionLen]]];
                
            }
            if (vs->panLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n pan码:%@",[m_vcom HexValue:vs->pan Len:vs->panLen] ]];
            }
            if (vs->hardSerialNoLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n hardNo:%@",[m_vcom HexValue:vs->hardSerialNo Len:vs->hardSerialNoLen] ]];
            }
            if (vs->traderNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n shnoInPsam:%@",[m_vcom HexValue:vs->traderNoInPsam Len:vs->traderNoInPsamLen] ]];
                
            }
            if (vs->termialNoInPsamLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n zdnoInPsam:%@",[m_vcom HexValue:vs->termialNoInPsam Len:vs->termialNoInPsamLen] ]];
                
            }
            if (vs->userInputLen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n userInput:%@",[m_vcom HexValue:vs->userInput Len:vs->userInputLen] ]];
            }
            
            if (vs->cdnolen>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cdno:%s",vs->cdno]];
                NSString *str1=[NSString stringWithCString:vs->cdno  encoding:NSUTF8StringEncoding];
                NSLog(@"str1 is %@", str1);
                
            }
            if (vs->orderLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ordersData:%@", [m_vcom HexValue:vs->Return_orders Len:vs->orderLen]]];
            }
            /////
            
            if (vs->deviceLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n deviceKind:%@",[m_vcom HexValue:vs->deviceKind Len:1] ]];
                
            }
            if (vs->data55Len>0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n data55:%@",[m_vcom HexValue:vs->data55 Len:vs->data55Len] ]];
                
            }
            if (vs->cvmLen >0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n cvm:%@",[m_vcom HexValue:vs->cvmData Len:vs->cvmLen] ]];
            }
            if (vs->ICReturnDataLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n ICReturnData:%@",[m_vcom HexValue:vs->ICReturnData Len:vs->ICReturnDataLen] ]];
                
            }
            if (vs->loadLen > 0) {
                [strTemp appendString:[NSString stringWithFormat:@"\n loadData:%@",[m_vcom HexValue:vs->loadData Len:vs->loadLen] ]];
                
            }
            if (vs->xulieDataLen)
            {
                [strTemp appendString:[NSString stringWithFormat:@"\n xulieData:%@",[m_vcom HexValue:vs->xulieData Len:vs->xulieDataLen] ]];
                
            }
            /////
            if (![strTemp isEqualToString:@""]) {
                [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:strTemp waitUntilDone:NO];
            }
        }else {
            NSLog(@"cmd exec error:%d\n",vs->res);
            switch (vs->res) {
                case 1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"通信超时" waitUntilDone:NO];
                    break;
                case 2:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"PSAM卡认证失败" waitUntilDone:NO];
                    break;
                case 3:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"Psam卡上电失败或者不存在" waitUntilDone:NO];
                    break;
                case 4:
                    [self performSelectorOnMainThread:@selector(refreshStatusNotSupportCmdFormPosToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 10:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"用户退出" waitUntilDone:NO];
                    break;
                case 11:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"MAC校验失败" waitUntilDone:NO];
                    break;
                case 12:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端加密失败" waitUntilDone:NO];
                    break;
                case 14:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"用户按了取消健" waitUntilDone:NO];
                    break;
                case 15:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"Psam卡状态异常" waitUntilDone:NO];
                    break;
                case 0x20:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不匹配的主命令码" waitUntilDone:NO];
                    break;
                case 0x21:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不匹配的子命令码" waitUntilDone:NO];
                    break;
                case 0x42:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"没有打印机" waitUntilDone:NO];
                    break;
                case 0x50:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"获取电池电量失败" waitUntilDone:NO];
                    break;
                case 0x80:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"数据接收正确" waitUntilDone:NO];
                    break;
                    
                case 0x40:
                    [self performSelectorOnMainThread:@selector(refreshStatusNoPaperInPrinterToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xe0:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"重传数据无效" waitUntilDone:NO];
                    break;
                case 0xe1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端设置待机信息失败" waitUntilDone:NO];
                    break;
                case 0xf0:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不识别的包头" waitUntilDone:NO];
                    break;
                case 0xf1:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不识别的主命令码" waitUntilDone:NO];
                    break;
                    
                case 0xf2://242
                    [self performSelectorOnMainThread:@selector(refreshStatusNotVerifySubCmdToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf3:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"该版本不支持此指令" waitUntilDone:NO];
                    break;
                    
                case 0xf4:
                    [self performSelectorOnMainThread:@selector(refreshStatusRandomLengthErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xf5:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不支持的部件" waitUntilDone:NO];
                    break;
                case 0xf6:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"不支持的模式" waitUntilDone:NO];
                    break;
                case 0xf7:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataLengthErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                    
                case 0xfc:
                    [self performSelectorOnMainThread:@selector(refreshStatusDataConentErrToPhone) withObject:nil waitUntilDone:NO];
                    break;
                case 0xfd:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"终端ID错误" waitUntilDone:NO];
                    break;
                case 0xfe:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"MAC_TK校验失败" waitUntilDone:NO];
                    break;
                case 0xff:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:@"校验和错误" waitUntilDone:NO];
                    break;
                default:
                    [self performSelectorOnMainThread:@selector(updateMytextView:) withObject:[NSString stringWithFormat:@"cmd exec error:%d\n",vs->res] waitUntilDone:NO];
                    break;
            }
            /* 失败和中间状态代码
             01
             命令执行超时
             02
             PSAM卡认证失败
             03
             Psam卡上电失败或者不存在
             04
             Psam卡操作失败
             0A
             用户退出
             0B
             MAC校验失败
             0C
             终端加密失败
             0E
             用户按了取消健
             0F
             Psam卡状态异常
             20
             不匹配的主命令码
             21
             不匹配的子命令码
             50
             获取电池电量失败
             80
             数据接收正确
             E0
             重传数据无效
             E1
             终端设置待机信息失败
             F0
             不识别的包头
             F1
             不识别的主命令码
             F2
             不识别的子命令码
             F3
             该版本不支持此指令
             F4
             随机数长度错误
             F5
             不支持的部件
             F6
             不支持的模式
             F7
             数据域长度错误
             FC
             数据域内容有误
             FD
             终端ID错误
             FE
             MAC_TK校验失败
             FF
             校验和错误
             // 打印错误
             PROTOCOL_ERR_PRT_NOPAPER     == 0X40   ;打印机缺纸
             PROTOCOL_ERR_PRT_OFF         == 0X41   ;打印机离线
             PROTOCOL_ERR_PRT_NO          == 0X42   ;没有打印机
             PROTOCOL_ERR_PRT_NOBM        == 0X43  ;没有黑标
             PROTOCOL_ERR_PRT_CLOSE       == 0X44  ;打印机关闭
             PROTOCOL_ERR_PRT_OTHER       == 0X45  ;打印机故障
             */
        }
    }
}
////////////////////////////////////////////////////////
- (void)updateMytextView:(NSString *)string
{
    m_recvData.text = string;
    sendBtn.userInteractionEnabled = YES;
}
//mic插入
-(void) onMicInOut:(int) inout
{
    
}
-(void)viewDidDisappear:(BOOL)animated
{
    [m_vcom close];
}

//关闭按钮
-(void)closesdk:(id)sender
{
    [m_vcom close];
    return;
}

- (void) getPanCallback : (unsigned char)status pan:(unsigned char*)pan panLen:(unsigned char)panLen
{
    
}

//命令字响应部分
-(void)refreshStatusNotSupportCmdFormPosToPhone
{
    self.m_recvData.text = @"刷卡器硬件暂不支持该命令！";
    sendBtn.userInteractionEnabled = YES;
    
}
-(void)refreshStatusNoReponseFromPosToPhone
{
    self.m_recvData.text = @"命令超时！";
    sendBtn.userInteractionEnabled = YES;
    
}
-(void)refreshPOSSwipeAction
{
    self.m_recvData.text = @"执行命令成功！";
    sendBtn.userInteractionEnabled = YES;
    
}

-(void)refreshStatusNotVerifySubCmdToPhone
{
    self.m_recvData.text = @"不识别的子命令码!";
    sendBtn.userInteractionEnabled = YES;
    
}

-(void)refreshStatusRandomLengthErrToPhone
{
    self.m_recvData.text = @"随机数长度错误!";
    sendBtn.userInteractionEnabled = YES;
    
}

-(void)refreshStatusNoPaperInPrinterToPhone
{
    self.m_recvData.text = @"打印机缺纸!";
    sendBtn.userInteractionEnabled = YES;
    
}
-(void)refreshStatusDataLengthErrToPhone
{
    self.m_recvData.text = @"数据域长度错误!";
    sendBtn.userInteractionEnabled = YES;
    
}
-(void)refreshStatusDataConentErrToPhone
{
    self.m_recvData.text = @"数据域内容错误!";
    sendBtn.userInteractionEnabled = YES;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSString *)stringFromHexString:(NSString *)hexString { //
    
    char *myBuffer = (char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner * scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (char)anInt;
    }
    NSString *unicodeString = [NSString stringWithCString:myBuffer encoding:4];
    return unicodeString;
    
    
}
- (void)onError:(int)errorCode ErrorMessage:(NSString *)errorMessage
{
    NSLog(@"%d", errorCode);
}
//IC卡回写脚本执行返回结果
- (void)onICResponse:(int)result resScript:(NSString *)resuiltScript data:(NSString *)data
{
    NSLog(@"result = %d ,resScript = %@, data = %@", result, resuiltScript, data);
    
}
//参数下载回调
- (void)onLoadParam:(NSString *)param
{
    sendBtn.userInteractionEnabled = YES;
    NSLog(@"参数下载：%@",param);
}
- (void)onDeviceKind:(int)result
{
    sendBtn.userInteractionEnabled = YES;
    
    NSLog(@"设备类型：%d", result);
}
- (void)EmvOperationWaitiing
{
    NSLog(@"插入了IC卡，不要拔出IC卡");
}


@end
