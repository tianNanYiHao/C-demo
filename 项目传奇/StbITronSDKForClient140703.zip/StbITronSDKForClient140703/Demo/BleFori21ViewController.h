//
//  BleFori21ViewController.h
//  StaticLibSDKDemo
//
//  Created by My MacPro on 15/1/21.
//
//

#import <UIKit/UIKit.h>
#import "CommunicationCallBack.h"
#import "ItronCommunicationManagerBase.h"

@interface BleFori21ViewController : UIViewController<CommunicationCallBack,DeviceSearchListener>
{
    ItronCommunicationManagerBase *cmManager;

}
@property (retain, nonatomic) IBOutlet UISegmentedControl *segmentBtn;
@property (retain, nonatomic) IBOutlet UILabel *displayLab;
@property (retain, nonatomic) IBOutlet UITextView *displayTextView;
@property (retain, nonatomic) IBOutlet UITableView *devecieTable;

@property (retain, nonatomic) IBOutlet UIPickerView *cmdSelectView;
@property (retain, nonatomic) IBOutlet UILabel *BleStateLab;
- (IBAction)sendCMDBtn:(UIButton *)sender;
- (IBAction)searchDevice:(UIButton *)sender;
@end
