//
//  HYinViewController.h
//  StaticLibSDKDemo
//
//  Created by My MacPro on 15/9/8.
//
//

#import <UIKit/UIKit.h>

@interface HYinViewController : UIViewController

- (IBAction)TranscationBtin:(id)sender;
@end
