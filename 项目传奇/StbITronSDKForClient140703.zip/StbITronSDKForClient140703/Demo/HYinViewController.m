//
//  HYinViewController.m
//  StaticLibSDKDemo
//
//  Created by My MacPro on 15/9/8.
//
//

#import "HYinViewController.h"
#import "vcom.h"
#import "STAlertView.h"
@interface HYinViewController ()<CSwiperStateChangedListener>
{
    vcom* m_vcom;

}
@end

@implementation HYinViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //初始化对象
    m_vcom = [vcom getInstance];
    [m_vcom open];
    m_vcom.eventListener=self;
    [m_vcom setCommmunicatinMode:aiShua];
    [m_vcom setVloumn:95];
    [m_vcom setDebug:1];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)TranscationBtin:(id)sender {
    
    STAlertView *stAlertView = [[STAlertView alloc] initWithTitle:@"请输入金额："
                                                  message:@""
                                            textFieldHint:@"0.00"
                                           textFieldValue:nil
                                        cancelButtonTitle:@"取消"
                                        otherButtonTitles:@"确定"
                        
                                        cancelButtonBlock:^{
                                            NSLog(@"Please, give me some feedback!");
                                        } otherButtonBlock:^(NSString * result){
                                            NSLog(@" result == %@", result);
                                            [self continueSwipe:result];
                                            
                                        }];

}
- (void *)continueSwipe:(NSString *)str
{
   
    
    [m_vcom StopRec];
    

    //ic卡刷卡命令
    
    NSString *appendData = @"49900003200015141399";
    char *temp1 = HexToBin((char*)[appendData UTF8String]);
    char appendDataChar[100];
    memcpy(appendDataChar, temp1, [appendData length]/2);//一定要拷贝否则会占用通一块内存
    int appendlen =(int)[appendData length]/2;
    
    NSString *cash = @"100";
    str = [str stringByReplacingOccurrencesOfString:@"." withString:@""];
    int ca = [str intValue] * 100;
    str = [NSString stringWithFormat:@"%d",ca];
    cash = str;
    int cashLen = (int)[cash length];
    char cData[100];
    cData[0] = 0;
    strcpy(cData,((char*)[cash UTF8String]));
    
    Transactioninfo *tranInfo = [[Transactioninfo alloc] init];
    NSString *ctrm = @"87030002";
    char *temp2 = HexToBin((char*)[ctrm UTF8String]);
    char ctr[4];
    memcpy(ctr, temp2, [ctrm length]/2);
    
    [m_vcom stat_EmvSwiper:0 PINKeyIndex:1 DESKeyInex:1 MACKeyIndex:1 CtrlMode:ctr ParameterRandom:"" ParameterRandomLen:0 cash:cData cashLen:cashLen appendData:"" appendDataLen:0 time:30 Transactioninfo:tranInfo];
    [m_vcom StartRec];
}
//ic卡刷卡器回调。
-(void)onDecodeCompleted:(NSString*) formatID
                  andKsn:(NSString*) ksn
            andencTracks:(NSString*) encTracks
         andTrack1Length:(int) track1Length
         andTrack2Length:(int) track2Length
         andTrack3Length:(int) track3Length
         andRandomNumber:(NSString*) randomNumber
           andCardNumber:(NSString *)maskedPAN
                  andPAN:(NSString*) pan
           andExpiryDate:(NSString*) expiryDate
       andCardHolderName:(NSString*) cardHolderName
                  andMac:(NSString *)mac
        andQTPlayReadBuf:(NSString*) readBuf
                cardType:(int)type
              cardserial:(NSString *)serialNum
             emvDataInfo:(NSString *)data55
                 cvmData:(NSString *)cvm
{

    
}
//1.mac
- (void)getMac
{
    
}
//2.pin
- (void)getPin
{
    
}
//3.加密
- (void)encString:(NSString *)str
{
    
}
@end







