
//
//  MainViewController.h : interface for the MainViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import <UIKit/UIKit.h>
#import "vcom.h"

@interface MainViewController : UIViewController<CSwiperStateChangedListener>
{
    vcom* m_vcom;
   
}

- (IBAction)buttonClick:(id)sender;
- (IBAction)iTronSwiptbuttonClick:(id)sender;
- (IBAction)main_readid:(id)sender;
- (IBAction)btoothClick:(id)sender;
- (IBAction)newBTclick:(id)sender;//新音频点付宝


- (IBAction)hanyinTest:(id)sender;
@end
