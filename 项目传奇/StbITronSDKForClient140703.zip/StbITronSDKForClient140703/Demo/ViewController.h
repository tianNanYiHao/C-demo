
//
//  ViewController.h : interface for the ViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import <UIKit/UIKit.h>
#import "vcom.h"
#import <Foundation/Foundation.h>
#import <MessageUI/MFMailComposeViewController.h>
#import <MessageUI/MessageUI.h>
#import "RTFlyoutMenu.h"

@interface ViewController : UIViewController<CSwiperStateChangedListener,MFMailComposeViewControllerDelegate,RTFlyoutMenuDelegate, RTFlyoutMenuDataSource>
{
    vcom* m_vcom;
    id timer;
    char *myRandom;
    int myRandomLen;
}

-(IBAction)readcardcont:(id)sender;
-(IBAction)comModeChange:(id)sender;
-(IBAction)sendCmd:(id)sender;
-(IBAction)recswitch:(id)sender;
-(IBAction)closesdk:(id)sender;

@property (retain, nonatomic) IBOutlet UILabel *m_sdkver;
@property (retain, nonatomic) IBOutlet UILabel *m_commStat;
@property (retain, nonatomic) IBOutlet UILabel *m_lineIn;
@property (retain, nonatomic) IBOutlet UITextView *m_recvData;
@property (retain, nonatomic) IBOutlet UITextField *m_cmdIndex;

@end