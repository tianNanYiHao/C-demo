//
//  RTFlyoutItem.h : interface for the MainViewController class.
//  StaticLibSDK
//
//  Created by alex on 13-7-22.
//  Copyright (c) 2013年 www.itron.com.cn All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RTFlyoutItem : UIButton

//@property (nonatomic, getter = isActive) BOOL active;
@property (nonatomic) NSInteger mainItemIndex;
@property (nonatomic) NSInteger subItemIndex;

@end
